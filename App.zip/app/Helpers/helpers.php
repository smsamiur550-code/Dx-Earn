<?php

use App\Models\Setting;
use App\Models\User;
use App\Models\Referral;
use App\Models\Transaction;
use App\Models\Notification;
use Illuminate\Support\Facades\DB;

if (!function_exists('send_telegram_notification')) {
    function send_telegram_notification($chat_id, $message, $token) {
        $url = "https://api.telegram.org/bot{$token}/sendMessage";
        try {
            \Illuminate\Support\Facades\Http::post($url, [
                'chat_id' => $chat_id,
                'text' => $message,
                'parse_mode' => 'HTML'
            ]);
        } catch (\Exception $e) {
            \Log::error("Telegram notification failed: " . $e->getMessage());
        }
    }
}

if (!function_exists('clean_data')) {
    function clean_data($data) {
        if (is_array($data)) {
            return array_map('clean_data', $data);
        }
        return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('get_setting_val')) {
    function get_setting_val($name) {
        try {
            $setting = Setting::where('name', $name)->first();
            return $setting ? $setting->val : '';
        } catch (\Exception $e) {
            return '';
        }
    }
}

if (!function_exists('update_setting_val')) {
    function update_setting_val($name, $val) {
        try {
            return Setting::updateOrCreate(
                ['name' => $name],
                ['val' => $val]
            );
        } catch (\Exception $e) {
            return false;
        }
    }
}

if (!function_exists('update_balance')) {
    function update_balance($user_id, $amount, $currency, $action = 'add') {
        $allowed_currencies = ['coin', 'token', 'usd', 'referral_dollar'];
        if (!in_array($currency, $allowed_currencies)) {
            throw new \Exception("Invalid balance currency specified.");
        }

        $field_map = [
            'coin' => 'balance_coin',
            'token' => 'balance_token',
            'usd' => 'balance_dollar',
            'referral_dollar' => 'balance_referral_dollar'
        ];
        $field = $field_map[$currency];
        $operator = ($action === 'add') ? '+' : '-';

        if ($action === 'add') {
    return DB::table('users')->where('id', $user_id)->increment($field, $amount);
} else {
    return DB::table('users')->where('id', $user_id)->decrement($field, $amount);
}
    }
}

if (!function_exists('log_transaction')) {
    function log_transaction($user_id, $category, $type, $currency, $amount, $description = '') {
        try {
            return Transaction::create([
                'user_id' => $user_id,
                'category' => $category,
                'type' => $type,
                'currency' => $currency,
                'amount' => $amount,
                'description' => $description,
                'status' => 'completed',
                'created_at' => now()
            ]);
        } catch (\Exception $e) {
            \Log::error("Transaction logging failed: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('add_notification')) {
    function add_notification($user_id, $type, $message) {
        try {
            return Notification::create([
                'user_id' => $user_id,
                'type' => $type,
                'message' => $message,
                'status' => 'unread',
                'created_at' => now()
            ]);
        } catch (\Exception $e) {
            \Log::error("Notification dispatch failed: " . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('get_avatar_url')) {
    function get_avatar_url($profile_pic) {
        if (empty($profile_pic) || $profile_pic === 'default_avatar.png') {
            return asset('uploads/default_avatar.png');
        }
        if (strpos($profile_pic, 'http://') === 0 || strpos($profile_pic, 'https://') === 0) {
            return htmlspecialchars($profile_pic);
        }
        return asset('uploads/' . htmlspecialchars($profile_pic));
    }
}

if (!function_exists('get_kyc_badge')) {
    function get_kyc_badge($status) {
        $status = strtolower($status);
        switch ($status) {
            case 'approved':
                return '<span class="px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-emerald-50 text-emerald-600 border border-emerald-100 flex items-center gap-1 w-fit"><i class="fa-solid fa-circle-check"></i> Approved</span>';
            case 'pending':
                return '<span class="px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-blue-50 text-blue-500 border border-blue-100 flex items-center gap-1 w-fit animate-pulse"><i class="fa-solid fa-circle-notch fa-spin"></i> Pending</span>';
            case 'rejected':
                return '<span class="px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-rose-50 text-rose-500 border border-rose-100 flex items-center gap-1 w-fit"><i class="fa-solid fa-circle-xmark"></i> Rejected</span>';
            default:
                return '<span class="px-2.5 py-0.5 rounded-full text-[8px] font-black uppercase tracking-wider bg-slate-150 text-slate-500 border border-slate-200 flex items-center gap-1 w-fit"><i class="fa-solid fa-circle-question"></i> Unverified</span>';
        }
    }
}

if (!function_exists('get_vip_multipliers')) {
    function get_vip_multipliers($user_id) {
        try {
            $vip = DB::table('user_vip')
                ->join('vip_plans', 'user_vip.vip_id', '=', 'vip_plans.id')
                ->where('user_vip.user_id', $user_id)
                ->where('user_vip.expires_at', '>', now())
                ->select('vip_plans.faster_mining_speed', 'vip_plans.extra_mining_income', 'vip_plans.daily_bonus')
                ->first();

            if ($vip) {
                return [
                    'is_vip' => true,
                    'mining_speed_multiplier' => floatval($vip->faster_mining_speed ?: 2.0),
                    'mining_capacity_multiplier' => floatval($vip->extra_mining_income ?: 2.0),
                    'games_limit_multiplier' => 2,
                    'daily_reward_multiplier' => floatval($vip->daily_bonus ?: 2.0)
                ];
            }
        } catch (\Exception $e) {
            \Log::error("VIP Check failure: " . $e->getMessage());
        }

        return [
            'is_vip' => false,
            'mining_speed_multiplier' => 1.0,
            'mining_capacity_multiplier' => 1.0,
            'games_limit_multiplier' => 1,
            'daily_reward_multiplier' => 1.0
        ];
    }
}

if (!function_exists('generate_referral_code')) {
    function generate_referral_code($length = 8) {
        return strtoupper(substr(bin2hex(random_bytes($length)), 0, $length));
    }
}

if (!function_exists('process_referral_registration')) {
    function process_referral_registration($referee_id, $referral_code) {
        try {
            $referrer = User::where('referral_code', $referral_code)->first();

            if ($referrer && $referrer->id != $referee_id) {
                $bonus_referrer = 0.50;
                $bonus_referee  = 0.20;

                Referral::create([
                    'referrer_id' => $referrer->id,
                    'referee_id' => $referee_id,
                    'bonus_amount' => $bonus_referrer,
                    'referee_bonus' => $bonus_referee,
                    'status' => 'pending',
                    'created_at' => now()
                ]);

                $referee = User::find($referee_id);
                if ($referee) {
                    $referee->referred_by = $referral_code;
                    $referee->save();
                }
            }
        } catch (\Exception $e) {
            \Log::error("Referral registration tracking error: " . $e->getMessage());
        }
    }
}

if (!function_exists('trigger_referral_payout')) {
    function trigger_referral_payout($referee_id) {
        try {
            $referral = Referral::where('referee_id', $referee_id)->where('status', 'pending')->first();

            if ($referral) {
                DB::beginTransaction();

                update_balance($referral->referrer_id, $referral->bonus_amount, 'referral_dollar', 'add');
                log_transaction($referral->referrer_id, 'referral', 'credit', 'usd', $referral->bonus_amount, "Referral bonus approved for inviting Referee ID: " . $referee_id);
                add_notification($referral->referrer_id, 'referral', "Referral approved! " . format_dollar($referral->bonus_amount) . " credited to your network balance.");

                update_balance($referee_id, $referral->referee_bonus, 'referral_dollar', 'add');
                log_transaction($referee_id, 'referral', 'credit', 'usd', $referral->referee_bonus, "Sign-up referral bonus approved (Verified KYC)");
                add_notification($referee_id, 'referral', "Identity verified! Sign-up bonus of " . format_dollar($referral->referee_bonus) . " credited.");

                $referral->status = 'approved';
                $referral->save();

                DB::commit();
                return true;
            }
        } catch (\Exception $e) {
            DB::rollBack();
            \Log::error("Referral payout settlement crashed: " . $e->getMessage());
        }
        return false;
    }
}

if (!function_exists('compress_image_to_webp')) {
    function compress_image_to_webp($file, $target_dir, $filename_without_ext) {
        if (!file_exists($target_dir)) {
            @mkdir($target_dir, 0755, true);
        }
        
        $tmp_name = $file['tmp_name'];
        $info = getimagesize($tmp_name);
        if (!$info) return false;

        $mime = $info['mime'];
        switch ($mime) {
            case 'image/jpeg':
            case 'image/jpg':
                $image = imagecreatefromjpeg($tmp_name);
                break;
            case 'image/png':
                $image = imagecreatefrompng($tmp_name);
                imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
                break;
            case 'image/webp':
                $image = imagecreatefromwebp($tmp_name);
                break;
            default:
                return false;
        }

        if (!$image) return false;

        $output_file_name = $filename_without_ext . '.webp';
        $output_path = $target_dir . $output_file_name;

        if (imagewebp($image, $output_path, 75)) {
            imagedestroy($image);
            return $output_file_name;
        }

        imagedestroy($image);
        return false;
    }
}

if (!function_exists('format_username')) {
    function format_username($username) {
        $clean = trim($username);
        $clean = ltrim($clean, '@');
        return '@' . htmlspecialchars($clean);
    }
}

if (!function_exists('generate_withdraw_ticket')) {
    function generate_withdraw_ticket() {
        try {
            $start_val = intval(get_setting_val('withdraw_ticket_start') ?: 1000);
            $count = intval(DB::table('withdrawals')->count());
            return strval($start_val + $count + 1);
        } catch (\Exception $e) {
            return strval(mt_rand(10000, 99999));
        }
    }
}

if (!function_exists('format_dollar')) {
    function format_dollar($amount) {
        return '$' . number_format((float)$amount, 2, '.', '');
    }
}

if (!function_exists('is_ad_restricted')) {
    function is_ad_restricted($user_id) {
        try {
            $user = User::select('device_uid')->where('id', $user_id)->first();
            if (!$user || empty($user->device_uid)) {
                return false;
            }

            $linked_accounts = User::where('device_uid', $user->device_uid)->where('is_banned', 0)->count();
            return ($linked_accounts > 1);
        } catch (\Exception $e) {
            return false;
        }
    }
}

if (!function_exists('log_ad_view')) {
    function log_ad_view($user_id) {
        try {
            $user = User::select('device_uid')->where('id', $user_id)->first();
            $device_uid = $user ? ($user->device_uid ?: '') : '';

            return DB::table('ad_views')->insert([
                'user_id' => $user_id,
                'device_uid' => $device_uid,
                'created_at' => now()
            ]);
        } catch (\Exception $e) {
            \Log::error($e->getMessage());
            return false;
        }
    }
}