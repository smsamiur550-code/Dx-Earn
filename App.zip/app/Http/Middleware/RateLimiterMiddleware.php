<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class RateLimiterMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (session()->has('admin_id')) {
            return $next($request);
        }

        $ip = $request->ip();
        $key = 'rate_limit:' . md5($ip);
        
        $requests = Cache::get($key, []);
        $now = time();
        
        $requests = array_filter($requests, function ($timestamp) use ($now) {
            return $timestamp > ($now - 60);
        });

        if (count($requests) >= 60) {
            return response()->view('errors.429', [], 429)
                ->header('Retry-After', 60);
        }

        $requests[] = $now;
        Cache::put($key, $requests, 60);

        return $next($request);
    }
}