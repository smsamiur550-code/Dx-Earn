<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        if (!session()->has('admin_id')) {
            return redirect()->route('admin.login');
        }

        $currentRouteName = $request->route()->getName();
        
        if ($currentRouteName === 'admin.dashboard') {
            return $next($request);
        }

        if (session('admin_role') !== 'owner') {
            $permissions = session('admin_permissions', []);
            
            $routePermissionMap = [
                'admin.users' => 'user.php',
                'admin.chat' => 'chat.php',
                'admin.tasks' => 'task.php',
                'admin.gift' => 'gift.php',
                'admin.payment' => 'payment.php',
                'admin.withdraw' => 'withdraw.php',
                'admin.withdraw_feed' => 'withdraw2.php',
                'admin.shop' => 'shop.php',
                'admin.products' => 'products.php',
                'admin.orders' => 'orders.php',
                'admin.lottery' => 'lottery.php',
                'admin.game' => 'game.php',
                'admin.mining' => 'mining.php',
                'admin.vip' => 'vip.php',
                'admin.admin_list' => 'admin.php',
                'admin.settings' => 'settings.php',
            ];

            if (isset($routePermissionMap[$currentRouteName])) {
                $requiredPermission = $routePermissionMap[$currentRouteName];
                if (!in_array($requiredPermission, $permissions)) {
                    abort(403, 'Access Denied: You do not have permission to access this panel.');
                }
            }
        }

        return $next($request);
    }
}