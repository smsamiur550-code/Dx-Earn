<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use App\Models\User;

class UserBannedMiddleware
{
    public function handle(Request $request, Closure $next)
    {
        $userId = session('user_id');
        if ($userId) {
            $user = User::find($userId);
            if ($user && $user->is_banned == 1) {
                session()->forget('user_id');
                return redirect()->route('login')->with('error', 'This account is suspended.');
            }
        }
        return $next($request);
    }
}