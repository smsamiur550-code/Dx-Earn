<?php

namespace App\Http\Controllers\Game;

use App\Http\Controllers\Game\GameEngineController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\GameHistory;
use App\Models\UserGamePlay;
use Illuminate\Support\Facades\DB;

class GameEngineController extends Controller
{
    // Display all available games (games.php)
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        return view('games.index', compact('user'));
    }

    // --- GAME 1: LUCKY SPIN WHEEL ---
    public function spin(Request $request)
    {
        return $this->handleGameRequest($request, 1, 'spin_limit', 'consecutive_spin_plays', 'games.spin', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'claim_spin') {
                $sliceIndex = intval($request->input('slice_index', 0));
                $sliceValue = floatval(get_setting_val("spin_prize_{$sliceIndex}_val") ?: 10.00);

                DB::beginTransaction();
                try {
                    update_balance($userId, $sliceValue, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $sliceValue, "Lucky Spin Slice #$sliceIndex Win");

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 1,
                        'val' => $sliceValue,
                        'label' => "Won Slice #$sliceIndex: 🪙 " . number_format($sliceValue, 2),
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 1);
                    $newConsecutive = session('consecutive_spin_plays', 0) + 1;
                    session(['consecutive_spin_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $spinLimit = intval(get_setting_val('spin_limit') ?: 5);
                    $finalLimit = $spinLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'slice_value' => $sliceValue,
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 2: DICE MASTER ---
    public function dice(Request $request)
    {
        return $this->handleGameRequest($request, 2, 'dice_limit', 'consecutive_dice_plays', 'games.dice', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'claim_dice') {
                $dice1 = mt_rand(1, 6);
                $dice2 = mt_rand(1, 6);
                $points = $dice1 + $dice2;
                $pointValue = floatval(get_setting_val('dice_point_value') ?: 10.00);
                $earned = $points * $pointValue;

                $isDouble = ($dice1 === $dice2);
                if ($isDouble) {
                    $earned *= 2;
                }

                DB::beginTransaction();
                try {
                    update_balance($userId, $earned, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $earned, "Dice Roll Win ($dice1:$dice2)");

                    $label = "Dice Roll ($dice1:$dice2)" . ($isDouble ? " [DOUBLE]" : "");
                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 2,
                        'val' => $earned,
                        'label' => $label,
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 2);
                    $newConsecutive = session('consecutive_dice_plays', 0) + 1;
                    session(['consecutive_dice_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $diceLimit = intval(get_setting_val('dice_limit') ?: 10);
                    $finalLimit = $diceLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'dice1' => $dice1,
                        'dice2' => $dice2,
                        'earned' => $earned,
                        'is_double' => $isDouble,
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 3: SCRATCH LOTTO ---
    public function scratch(Request $request)
    {
        return $this->handleGameRequest($request, 3, 'scratch_limit', 'consecutive_scratch_plays', 'games.scratch', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'scratch') {
                $minPrize = floatval(get_setting_val('scratch_min_prize') ?: 5.00);
                $maxPrize = floatval(get_setting_val('scratch_max_prize') ?: 50.00);
                $wonAmount = mt_rand(intval($minPrize * 100), intval($maxPrize * 100)) / 100;
                $labelText = "🪙 " . number_format($wonAmount, 2);

                DB::beginTransaction();
                try {
                    update_balance($userId, $wonAmount, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $wonAmount, "Scratch Card Win: $labelText");
                    add_notification($userId, 'reward', "You scratched a card and won 🪙 " . number_format($wonAmount, 2));

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 3,
                        'val' => $wonAmount,
                        'label' => $labelText,
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 3);
                    $newConsecutive = session('consecutive_scratch_plays', 0) + 1;
                    session(['consecutive_scratch_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $scratchLimit = intval(get_setting_val('scratch_limit') ?: 5);
                    $finalLimit = $scratchLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'label' => $labelText,
                        'amount' => $wonAmount,
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 4: TREASURE BOX ---
    public function treasure(Request $request)
    {
        return $this->handleGameRequest($request, 4, 'treasure_limit', 'consecutive_treasure_plays', 'games.treasure', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'open_box') {
                $boxIndex = intval($request->input('box_index', 1));
                if ($boxIndex < 1 || $boxIndex > 9) $boxIndex = 1;
                $boxValue = floatval(get_setting_val("treasure_val_{$boxIndex}") ?: 10.00);

                DB::beginTransaction();
                try {
                    update_balance($userId, $boxValue, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $boxValue, "Treasure Box #$boxIndex Win");

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 4,
                        'val' => $boxValue,
                        'label' => "Opened Box #$boxIndex: 🪙 " . number_format($boxValue, 2),
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 4);
                    $newConsecutive = session('consecutive_treasure_plays', 0) + 1;
                    session(['consecutive_treasure_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $treasureLimit = intval(get_setting_val('treasure_limit') ?: 5);
                    $finalLimit = $treasureLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'box_value' => $boxValue,
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 5: MATH SOLVING ---
    public function math(Request $request)
    {
        return $this->handleGameRequest($request, 5, 'math_limit', 'consecutive_math_plays', 'games.math', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'submit_answer') {
                $userAnswer = intval($request->input('user_answer', 0));
                $correctAnswer = intval(session('math_answer', 0));

                // Verification check: ভুল উত্তর দিলে এরর রিটার্ন হবে (Security loophole resolved)
                if ($userAnswer !== $correctAnswer) {
                    return response()->json(['status' => 'error', 'message' => 'Wrong Answer! Please try again with a new equation.']);
                }

                $reward = floatval(get_setting_val('math_reward') ?: 10.00);

                DB::beginTransaction();
                try {
                    update_balance($userId, $reward, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $reward, "Math Solver Win");

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 5,
                        'val' => $reward,
                        'label' => "Solved Arithmetic Equation",
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 5);
                    $newConsecutive = session('consecutive_math_plays', 0) + 1;
                    session(['consecutive_math_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $mathLimit = intval(get_setting_val('math_limit') ?: 10);
                    $finalLimit = $mathLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 6: WORD GAME ---
    public function word(Request $request)
    {
        return $this->handleGameRequest($request, 6, 'word_limit', 'consecutive_word_plays', 'games.word', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'submit_word') {
                $userWord = strtoupper(trim(clean_data($request->input('user_word', ''))));
                $correctWord = strtoupper(trim(session('word_answer', '')));

                if ($userWord === $correctWord) {
                    $reward = floatval(get_setting_val('word_reward') ?: 15.00);

                    DB::beginTransaction();
                    try {
                        update_balance($userId, $reward, 'coin', 'add');
                        log_transaction($userId, 'income', 'credit', 'coin', $reward, "Word Scramble Win: " . $correctWord);

                        GameHistory::create([
                            'user_id' => $userId,
                            'game_id' => 6,
                            'val' => $reward,
                            'label' => "Solved Scrambled: " . session('word_scrambled') . " ➔ " . $correctWord,
                            'created_at' => now()
                        ]);

                        $play = $this->incrementGamePlays($userId, 6);
                        $newConsecutive = session('consecutive_word_plays', 0) + 1;
                        session(['consecutive_word_plays' => $newConsecutive]);

                        DB::commit();

                        $updatedUser = User::find($userId);
                        $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                        $wordLimit = intval(get_setting_val('word_limit') ?: 10);
                        $finalLimit = $wordLimit * $multiplierLimit;
                        $newPlays = $play->plays_today;
                        $newLimitReached = ($newPlays >= $finalLimit);
                        $midnight = strtotime('tomorrow Midnight');
                        $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                        session()->forget(['word_scrambled', 'word_answer']);

                        return response()->json([
                            'status' => 'success',
                            'correct' => true,
                            'new_balance' => number_format($updatedUser->balance_coin, 2),
                            'plays_today' => $newPlays,
                            'consecutive_plays' => $newConsecutive,
                            'session_locked' => ($newConsecutive >= 5),
                            'limit_reached' => $newLimitReached,
                            'remaining_time' => $newRemTime
                        ]);
                    } catch (\Exception $e) {
                        DB::rollBack();
                        return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                    }
                } else {
                    return response()->json(['status' => 'success', 'correct' => false, 'message' => 'Wrong Word! Try again.']);
                }
            }
            return null;
        });
    }

    // --- GAME 7: EASY QUIZ ---
    public function quiz(Request $request)
    {
        return $this->handleGameRequest($request, 7, 'quiz_limit', 'consecutive_quiz_plays', 'games.quiz', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'submit_quiz') {
                $selectedOption = intval($request->input('selected_option', 0));
                $correctOption = intval(session('quiz_answer', 0));

                if ($selectedOption === $correctOption) {
                    $reward = floatval(get_setting_val('quiz_reward') ?: 20.00);

                    DB::beginTransaction();
                    try {
                        update_balance($userId, $reward, 'coin', 'add');
                        log_transaction($userId, 'income', 'credit', 'coin', $reward, "Easy Quiz Win: " . session('quiz_question'));

                        GameHistory::create([
                            'user_id' => $userId,
                            'game_id' => 7,
                            'val' => $reward,
                            'label' => "Matched Quiz Answer for: " . session('quiz_question'),
                            'created_at' => now()
                        ]);

                        $play = $this->incrementGamePlays($userId, 7);
                        $newConsecutive = session('consecutive_quiz_plays', 0) + 1;
                        session(['consecutive_quiz_plays' => $newConsecutive]);

                        DB::commit();

                        $updatedUser = User::find($userId);
                        $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                        $quizLimit = intval(get_setting_val('quiz_limit') ?: 10);
                        $finalLimit = $quizLimit * $multiplierLimit;
                        $newPlays = $play->plays_today;
                        $newLimitReached = ($newPlays >= $finalLimit);
                        $midnight = strtotime('tomorrow Midnight');
                        $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                        session()->forget(['quiz_question', 'quiz_options', 'quiz_answer']);

                        return response()->json([
                            'status' => 'success',
                            'correct' => true,
                            'new_balance' => number_format($updatedUser->balance_coin, 2),
                            'plays_today' => $newPlays,
                            'consecutive_plays' => $newConsecutive,
                            'session_locked' => ($newConsecutive >= 5),
                            'limit_reached' => $newLimitReached,
                            'remaining_time' => $newRemTime
                        ]);
                    } catch (\Exception $e) {
                        DB::rollBack();
                        return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                    }
                } else {
                    return response()->json(['status' => 'success', 'correct' => false, 'message' => 'Wrong Answer! Please try again with a new equation.']);
                }
            }
            return null;
        });
    }

    // --- GAME 8: BRAIN GAME ---
    public function brain(Request $request)
    {
        return $this->handleGameRequest($request, 8, 'brain_limit', 'consecutive_brain_plays', 'games.brain', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'submit_sequence') {
                $userSeq = trim(clean_data($request->input('user_sequence', '')));
                $correctSeq = trim(session('brain_sequence', ''));

                if ($userSeq === $correctSeq) {
                    $reward = floatval(get_setting_val('brain_reward') ?: 20.00);

                    DB::beginTransaction();
                    try {
                        update_balance($userId, $reward, 'coin', 'add');
                        log_transaction($userId, 'income', 'credit', 'coin', $reward, "Brain Game Win: " . $correctSeq);

                        GameHistory::create([
                            'user_id' => $userId,
                            'game_id' => 8,
                            'val' => $reward,
                            'label' => "Matched Sequence: " . $correctSeq,
                            'created_at' => now()
                        ]);

                        $play = $this->incrementGamePlays($userId, 8);
                        $newConsecutive = session('consecutive_brain_plays', 0) + 1;
                        session(['consecutive_brain_plays' => $newConsecutive]);

                        DB::commit();

                        $updatedUser = User::find($userId);
                        $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                        $brainLimit = intval(get_setting_val('brain_limit') ?: 10);
                        $finalLimit = $brainLimit * $multiplierLimit;
                        $newPlays = $play->plays_today;
                        $newLimitReached = ($newPlays >= $finalLimit);
                        $midnight = strtotime('tomorrow Midnight');
                        $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                        session()->forget('brain_sequence');

                        return response()->json([
                            'status' => 'success',
                            'correct' => true,
                            'new_balance' => number_format($updatedUser->balance_coin, 2),
                            'plays_today' => $newPlays,
                            'consecutive_plays' => $newConsecutive,
                            'session_locked' => ($newConsecutive >= 5),
                            'limit_reached' => $newLimitReached,
                            'remaining_time' => $newRemTime
                        ]);
                    } catch (\Exception $e) {
                        DB::rollBack();
                        return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                    }
                } else {
                    return response()->json(['status' => 'success', 'correct' => false, 'message' => 'Wrong Sequence! Try again with a new code.']);
                }
            }
            return null;
        });
    }

    // --- GAME 9: PUZZLE BLOCK ---
    public function puzzle(Request $request)
    {
        return $this->handleGameRequest($request, 9, 'puzzle_limit', 'consecutive_puzzle_plays', 'games.puzzle', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'claim_victory') {
                $moves = intval($request->input('moves', 0));
                if ($moves < 10) {
                    return response()->json(['status' => 'error', 'message' => 'Spoofing detected: Impossible move count.']);
                }

                $reward = floatval(get_setting_val('puzzle_reward') ?: 25.00);

                DB::beginTransaction();
                try {
                    update_balance($userId, $reward, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $reward, "Puzzle Block Win (Moves: $moves)");

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 9,
                        'val' => $reward,
                        'label' => "Solved 3x3 Slide Puzzle in " . $moves . " Moves",
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 9);
                    $newConsecutive = session('consecutive_puzzle_plays', 0) + 1;
                    session(['consecutive_puzzle_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $puzzleLimit = intval(get_setting_val('puzzle_limit') ?: 10);
                    $finalLimit = $puzzleLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- GAME 10: EMOJI MATCH ---
    public function emoji(Request $request)
    {
        return $this->handleGameRequest($request, 10, 'emoji_limit', 'consecutive_emoji_plays', 'games.emoji', function(Request $request, $userId, $vip, $limitReached) {
            if ($request->input('action') === 'claim_victory') {
                $moves = intval($request->input('moves', 0));
                if ($moves < 6) {
                    return response()->json(['status' => 'error', 'message' => 'Spoofing detected: Impossible move count.']);
                }

                $reward = floatval(get_setting_val('emoji_reward') ?: 20.00);

                DB::beginTransaction();
                try {
                    update_balance($userId, $reward, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $reward, "Emoji Game Win (Moves: $moves)");

                    GameHistory::create([
                        'user_id' => $userId,
                        'game_id' => 10,
                        'val' => $reward,
                        'label' => "Matched All Emojis in " . $moves . " Moves",
                        'created_at' => now()
                    ]);

                    $play = $this->incrementGamePlays($userId, 10);
                    $newConsecutive = session('consecutive_emoji_plays', 0) + 1;
                    session(['consecutive_emoji_plays' => $newConsecutive]);

                    DB::commit();

                    $updatedUser = User::find($userId);
                    $multiplierLimit = $vip['is_vip'] ? 2 : 1;
                    $emojiLimit = intval(get_setting_val('emoji_limit') ?: 10);
                    $finalLimit = $emojiLimit * $multiplierLimit;
                    $newPlays = $play->plays_today;
                    $newLimitReached = ($newPlays >= $finalLimit);
                    $midnight = strtotime('tomorrow Midnight');
                    $newRemTime = $newLimitReached ? max(0, $midnight - time()) : 0;

                    return response()->json([
                        'status' => 'success',
                        'new_balance' => number_format($updatedUser->balance_coin, 2),
                        'plays_today' => $newPlays,
                        'consecutive_plays' => $newConsecutive,
                        'session_locked' => ($newConsecutive >= 5),
                        'limit_reached' => $newLimitReached,
                        'remaining_time' => $newRemTime
                    ]);
                } catch (\Exception $e) {
                    DB::rollBack();
                    return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
                }
            }
            return null;
        });
    }

    // --- REUSABLE PRIVATE STATE HELPERS ---
    private function handleGameRequest(Request $request, $gameId, $limitSettingKey, $consecutiveSessionKey, $viewName, callable $actionCallback)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $isHardLocked = false;
        $hardLockRemaining = 0;
        if (!empty($user->hard_lock_expires_at) && $user->hard_lock_expires_at->isFuture()) {
            $isHardLocked = true;
            $hardLockRemaining = $user->hard_lock_expires_at->timestamp - time();
        }

        $consecutivePlays = session($consecutiveSessionKey, 0);
        $isSessionLocked = ($consecutivePlays >= 5);

        $adRestricted = is_ad_restricted($userId);

        $limitVal = intval(get_setting_val($limitSettingKey) ?: 10);
        $vip = get_vip_multipliers($userId);
        $multiplierLimit = $vip['is_vip'] ? 2 : 1;
        $finalLimit = $limitVal * $multiplierLimit;

        // MVC-compliance: ব্লেড ফাইল থেকে সেশন জেনারেট করার লজিক এখানে নিয়ে আসা হলো
        if (!$isHardLocked && !$isSessionLocked) {
            // Word Game
            if ($gameId === 6 && !session()->has('word_answer')) {
                $wordPool = ["MINING", "TOKEN", "CRYPTO", "COINS", "BOOSTER", "WALLET", "LEDGER", "SWEEPSTAKES", "PREMIUM", "REWARDS"];
                $selectedWord = $wordPool[array_rand($wordPool)];
                $scrambled = str_shuffle($selectedWord);
                while ($scrambled === $selectedWord) {
                    $scrambled = str_shuffle($selectedWord);
                }
                session(['word_scrambled' => $scrambled, 'word_answer' => $selectedWord]);
            }

            // Easy Quiz Game
            if ($gameId === 7 && !session()->has('quiz_answer')) {
                $quizPool = [
                    [
                        'q' => 'Which is the core decentralized coin of DX EARN?',
                        'o' => [1 => 'DX Coin 🪙', 2 => 'Ethereum 🚀', 3 => 'Bitcoin Core ⚙️', 4 => 'Litecoin 🟡'],
                        'a' => 1
                    ],
                    [
                        'q' => 'What is the base payout currency used in the ledger?',
                        'o' => [1 => 'DX Coins ⛏️', 2 => 'Cash BDT / USD 💵', 3 => 'Utility Tokens 🪙', 4 => 'Voucher points 🎫'],
                        'a' => 2
                    ],
                    [
                        'q' => 'What happens to referral payouts when KYC is approved?',
                        'o' => [1 => 'Bonuses are lost ❌', 2 => 'Instantly approved & credited ⚡', 3 => 'Remain pending forever ⏳', 4 => 'Converted to diamonds 💎'],
                        'a' => 2
                    ],
                    [
                        'q' => 'What is the minimum wait timer of WebApp advertisements?',
                        'o' => [1 => '2 seconds', 2 => '5 seconds ⏱️', 3 => '15 seconds', 4 => '30 seconds'],
                        'a' => 2
                    ]
                ];
                $selectedQuiz = $quizPool[array_rand($quizPool)];
                session([
                    'quiz_question' => $selectedQuiz['q'],
                    'quiz_options' => $selectedQuiz['o'],
                    'quiz_answer' => $selectedQuiz['a']
                ]);
            }

            // Brain Sequence Game
            if ($gameId === 8 && !session()->has('brain_sequence')) {
                $seqArr = [];
                for ($i = 0; $i < 4; $i++) {
                    $seqArr[] = mt_rand(1, 9);
                }
                session(['brain_sequence' => implode("", $seqArr)]);
            }
        }

        $playData = UserGamePlay::where('user_id', $userId)->where('game_id', $gameId)->first();
        $playsToday = 0;

        if ($playData) {
            if ($playData->last_played->format('Y-m-d') !== date('Y-m-d')) {
                $playsToday = 0;
                $isLimitReached = false;
                $remainingTime = 0;
            } else {
                $playsToday = $playData->plays_today;
                $isLimitReached = ($playsToday >= $finalLimit);
                $remainingTime = $isLimitReached ? max(0, strtotime('tomorrow Midnight') - time()) : 0;
            }
        } else {
            $isLimitReached = false;
            $remainingTime = 0;
        }

        // Handle POST Actions
        if ($request->isMethod('post')) {
            $action = $request->input('action');

            if ($action === 'start_unlock') {
                if ($adRestricted) {
                    return response()->json(['status' => 'error', 'message' => 'Ad privileges are restricted on this device.']);
                }
                session(['ad_watch_start_time' => time()]);
                return response()->json(['status' => 'success']);
            }

            if ($action === 'verify_unlock') {
                $startTime = session('ad_watch_start_time', 0);
                $elapsed = time() - $startTime;

                if ($startTime > 0 && $elapsed >= 5) {
                    session([$consecutiveSessionKey => 0]);
                    session()->forget('ad_watch_start_time');
                    return response()->json(['status' => 'success', 'message' => 'Game successfully unlocked!']);
                } else {
                    $hardLockExpiry = now()->addMinutes(2);
                    $user->update(['hard_lock_expires_at' => $hardLockExpiry]);
                    session()->forget('ad_watch_start_time');
                    return response()->json([
                        'status' => 'hard_lock',
                        'message' => 'Spoofing detected! You are locked out of all games for 2 minutes.'
                    ]);
                }
            }

            // Fire Custom Action Callback
            $jsonResponse = $actionCallback($request, $userId, $vip, $isLimitReached);
            if ($jsonResponse) {
                return $jsonResponse;
            }
        }

        $history = GameHistory::where('user_id', $userId)
            ->where('game_id', $gameId)
            ->where('created_at', '>=', now()->subDay())
            ->orderBy('id', 'desc')
            ->limit(15)
            ->get();

        $monetagLink = get_setting_val('monetag_direct_link') ?: 'https://www.google.com';

        return view($viewName, compact(
            'user', 'isHardLocked', 'hardLockRemaining', 'playsToday', 
            'isSessionLocked', 'adRestricted', 'isLimitReached', 'remainingTime', 
            'history', 'monetagLink', 'finalLimit'
        ));
    }

    private function incrementGamePlays($userId, $gameId)
    {
        $play = UserGamePlay::where('user_id', $userId)->where('game_id', $gameId)->first();

        if ($play) {
            if ($play->last_played->format('Y-m-d') !== date('Y-m-d')) {
                $play->plays_today = 1;
            } else {
                $play->plays_today += 1;
            }
            $play->last_played = now();
            $play->save();
        } else {
            $play = UserGamePlay::create([
                'user_id' => $userId,
                'game_id' => $gameId,
                'plays_today' => 1,
                'last_played' => now()
            ]);
        }

        return $play;
    }
}