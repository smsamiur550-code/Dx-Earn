<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use App\Models\User;
use App\Models\Withdrawal;
use App\Models\Conversion;
use App\Models\Order;

class TelegramBotController extends Controller
{
    public function handleWebhook(Request $request)
    {
        $update = $request->all();
        if (!$update) {
            return response()->json(['status' => 'empty']);
        }

        $botToken = get_setting_val('bot_token');
        if (!$botToken) {
            return response()->json(['status' => 'missing_token']);
        }

        $message = $update['message'] ?? null;
        $callbackQuery = $update['callback_query'] ?? null;

        if ($message) {
            $chatId = $message['chat']['id'];
            $text = trim($message['text'] ?? '');

            if (strpos($text, '/start') === 0) {
                $startParam = '';
                $parts = explode(' ', $text);
                if (count($parts) > 1) {
                    $startParam = trim($parts[1]);
                    session(['referred_by' => $startParam]);
                }

                $welcomeText = "👋 <b>Welcome to DX EARN!</b> ⚡\n\n" .
                               "Your premier decentralized cloud mining and interactive rewards hub on Telegram.\n\n" .
                               "🚀 Click <b>Earning Now</b> below to launch the Mini App and start mining instantly!";

                $inlineKeyboard = [
                    'inline_keyboard' => [
                        [
                            ['text' => '🚀 Earning Now', 'web_app' => ['url' => route('home')]]
                        ],
                        [
                            ['text' => '📢 Join Official Group', 'url' => get_setting_val('telegram_group_link') ?: 'https://t.me/dxearn_group']
                        ],
                        [
                            ['text' => '🔍 Check Account Status', 'callback_data' => 'check_account']
                        ]
                    ]
                ];

                $this->botRequest('sendMessage', [
                    'chat_id' => $chatId,
                    'text' => $welcomeText,
                    'parse_mode' => 'HTML',
                    'reply_markup' => json_encode($inlineKeyboard)
                ], $botToken);
                return response()->json(['status' => 'started']);
            }

            $dbUser = User::where('telegram_id', $chatId)->first();

            if ($dbUser) {
                $userId = $dbUser->id;
                $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);
                
                switch ($text) {
                    case '👤 User Info':
                        $cleanKyc = strip_tags(get_kyc_badge($dbUser->kyc_status));
                        
                        $infoMsg = "👤 <b>DX EARN User Account Info</b>\n\n" .
                                    "• <b>Username:</b> " . htmlspecialchars($dbUser->username) . "\n" .
                                    "• <b>Full Name:</b> " . htmlspecialchars($dbUser->full_name) . "\n" .
                                    "• <b>KYC Status:</b> {$cleanKyc}\n\n" .
                                    "<b>Balances:</b>\n" .
                                    "🪙 <b>DX Coins:</b> " . number_format($dbUser->balance_coin, 4) . "\n" .
                                    "💵 <b>DX Tokens:</b> " . number_format($dbUser->balance_token, 4) . "\n" .
                                    "💳 <b>Main USD:</b> " . format_dollar($dbUser->balance_dollar) . " (" . number_format($dbUser->balance_dollar * $takaRate, 2) . " ৳)\n" .
                                    "🤝 <b>Referral USD:</b> " . format_dollar($dbUser->balance_referral_dollar ?? 0.00) . " (" . number_format(($dbUser->balance_referral_dollar ?? 0.00) * $takaRate, 2) . " ৳)";
                        
                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $infoMsg,
                            'parse_mode' => 'HTML'
                        ], $botToken);
                        break;

                    case '📜 History':
                        $withdrawals = Withdrawal::where('user_id', $userId)->orderBy('id', 'desc')->limit(3)->get();
                        $conversions = Conversion::where('user_id', $userId)->orderBy('id', 'desc')->limit(3)->get();

                        $histMsg = "📜 <b>Your Recent Transaction Logs</b>\n\n";
                        $histMsg .= "<b>Payouts:</b>\n";
                        if ($withdrawals->isNotEmpty()) {
                            foreach ($withdrawals as $w) {
                                $histMsg .= "• " . format_dollar($w->amount) . " (" . number_format($w->amount * $takaRate, 2) . " ৳) via " . htmlspecialchars($w->payment_method) . " [" . strtoupper($w->status) . "]\n";
                            }
                        } else {
                            $histMsg .= "No withdrawals found.\n";
                        }

                        $histMsg .= "\n<b>Conversions:</b>\n";
                        if ($conversions->isNotEmpty()) {
                            foreach ($conversions as $c) {
                                $typeLabel = $c->type === 'coin_to_token' ? 'Coins ➔ Tokens' : 'Tokens ➔ BDT';
                                $histMsg .= "• Swap: {$typeLabel} on " . date('d M Y', strtotime($c->created_at)) . "\n";
                            }
                        } else {
                            $histMsg .= "No conversions logged.\n";
                        }

                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $histMsg,
                            'parse_mode' => 'HTML'
                        ], $botToken);
                        break;

                    case '📦 Order Status':
                        $orders = Order::where('user_id', $userId)
                            ->orderBy('id', 'desc')
                            ->limit(3)
                            ->get();

                        $ordMsg = "📦 <b>Shop Orders & Sweepstakes</b>\n\n";
                        if ($orders->isNotEmpty()) {
                            foreach ($orders as $o) {
                                $ticketNum = $o->lotteryTicket ? $o->lotteryTicket->ticket_number : 'N/A';
                                $ordMsg .= "• <b>Order #" . $o->id . ":</b> " . htmlspecialchars($o->product->name ?? 'Unknown Product') . "\n" .
                                            "  Status: <b>" . strtoupper($o->status) . "</b>\n" .
                                            "  COD Due: " . number_format($o->cod_amount * $takaRate, 2) . " ৳\n" .
                                            "  Ticket: <code>" . htmlspecialchars($ticketNum) . "</code>\n\n";
                            }
                        } else {
                            $ordMsg .= "No active orders found in the directory.";
                        }

                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $ordMsg,
                            'parse_mode' => 'HTML'
                        ], $botToken);
                        break;

                    case '🤝 Referral Link':
                        $botUsername = get_setting_val('bot_username') ?: 'dxearn_bot';
                        $tgRefLink = "https://t.me/" . $botUsername . "/app?startapp=" . urlencode($dbUser->referral_code);
                        $webRefLink = route('login') . "?ref=" . urlencode($dbUser->referral_code);
                        
                        $refMsg = "🤝 <b>Spread Your Network</b>\n\n" .
                                   "Share your custom link to invite friends. Once they verify KYC, both of you earn USD cash!\n\n" .
                                   "📱 <b>Telegram Link:</b>\n<code>{$tgRefLink}</code>\n\n" .
                                   "🌐 <b>Web Portal Link:</b>\n<code>{$webRefLink}</code>";

                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $refMsg,
                            'parse_mode' => 'HTML'
                        ], $botToken);
                        break;

                    case '📞 Support':
                        $telegramChannel = get_setting_val('telegram_channel_link') ?: 'https://t.me/dxearn_channel';
                        $telegramGroup   = get_setting_val('telegram_group_link') ?: 'https://t.me/dxearn_group';
                        $whatsappGroup   = get_setting_val('whatsapp_group_link') ?: 'https://wa.me/your_number';
                        $youtubeSupport  = get_setting_val('youtube_support_link') ?: 'https://youtube.com';

                        $supMsg = "📞 <b>DX EARN Support Channels</b>\n\n" .
                                   "• <a href='{$telegramChannel}'>Telegram Channel</a> - News & Promos\n" .
                                   "• <a href='{$telegramGroup}'>Telegram Group</a> - Community Support\n" .
                                   "• <a href='{$whatsappGroup}'>WhatsApp Group</a> - Instant Help\n" .
                                   "• <a href='{$youtubeSupport}'>YouTube Guide</a> - Watch tutorials";

                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $supMsg,
                            'parse_mode' => 'HTML',
                            'disable_web_page_preview' => true
                        ], $botToken);
                        break;

                    case '👑 VIP Status':
                        $vipData = $dbUser->vip;

                        if ($vipData && $vipData->expires_at->isFuture()) {
                            $vipMsg = "👑 <b>VIP Node Activated!</b>\n\n" .
                                       "• <b>Booster Card:</b> " . htmlspecialchars($vipData->plan->name ?? 'Unknown') . "\n" .
                                       "• <b>Speed Multiplier:</b> 2.0x\n" .
                                       "• <b>Mining Capacity:</b> 2.0x\n" .
                                       "• <b>Daily Games Limit:</b> 2.0x\n" .
                                       "• <b>Expiry Date:</b> " . $vipData->expires_at->format('d M Y, h:i A');
                        } else {
                            $vipMsg = "👑 <b>VIP Status: INACTIVE</b>\n\n" .
                                       "Upgrade your mining storage and triple your daily limits! Buy a VIP pass inside the wallet section today.";
                        }

                        $this->botRequest('sendMessage', [
                            'chat_id' => $chatId,
                            'text' => $vipMsg,
                            'parse_mode' => 'HTML'
                        ], $botToken);
                        break;
                }
            }
        }

        if ($callbackQuery) {
            $chatId = $callbackQuery['message']['chat']['id'];
            $data = $callbackQuery['data'];

            if ($data === 'check_account') {
                $dbUser = User::where('telegram_id', $chatId)->first();

                if ($dbUser) {
                    $replyKeyboard = [
                        'keyboard' => [
                            [['text' => '👤 User Info'], ['text' => '📜 History']],
                            [['text' => '📦 Order Status'], ['text' => '🤝 Referral Link']],
                            [['text' => '📞 Support'], ['text' => '👑 VIP Status']]
                        ],
                        'resize_keyboard' => true,
                        'one_time_keyboard' => false
                    ];

                    $this->botRequest('sendMessage', [
                        'chat_id' => $chatId,
                        'text' => "✅ <b>Account Verified!</b>\n\nUse the custom menu buttons below to interact with your decentralized cloud node directly.",
                        'parse_mode' => 'HTML',
                        'reply_markup' => json_encode($replyKeyboard)
                    ], $botToken);
                } else {
                    $this->botRequest('sendMessage', [
                        'chat_id' => $chatId,
                        'text' => "⚠️ <b>Account Not Found!</b>\n\nYou haven't registered on our mini-app yet. Please tap <b>Earning Now</b> inside the Bot or start again to set up your account.",
                        'parse_mode' => 'HTML'
                    ], $botToken);
                }

                $this->botRequest('answerCallbackQuery', [
                    'callback_query_id' => $callbackQuery['id']
                ], $botToken);
            }
        }

        return response()->json(['status' => 'handled']);
    }

    private function botRequest($method, $data, $token)
    {
        $url = "https://api.telegram.org/bot{$token}/{$method}";
        try {
            Http::timeout(10)->post($url, $data);
        } catch (\Exception $e) {
            \Log::error("Bot request failed: " . $e->getMessage());
        }
    }
}