<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $searchQuery = clean_data($request->query('search', ''));
        
        if (!empty($searchQuery)) {
            $usersListData = User::where('username', 'LIKE', "%$searchQuery%")
                ->orWhere('full_name', 'LIKE', "%$searchQuery%")
                ->orderBy('id', 'desc')
                ->limit(50)
                ->get();
        } else {
            $usersListData = User::orderBy('id', 'desc')->limit(50)->get();
        }

        return view('admin.user', compact('usersListData', 'searchQuery'));
    }

    public function update(Request $request)
    {
        $targetUid = intval($request->input('user_id', 0));
        $newCoin = floatval($request->input('balance_coin', 0));
        $newToken = floatval($request->input('balance_token', 0));
        $newDollar = floatval($request->input('balance_dollar', 0));
        $newReferralDollar = floatval($request->input('balance_referral_dollar', 0));
        $newKyc = clean_data($request->input('kyc_status', 'unverified'));
        $isBanned = intval($request->input('is_banned', 0));

        $user = User::find($targetUid);
        if (!$user) {
            return back()->with('error', 'User account not found.');
        }

        \DB::beginTransaction();
        try {
            $user->update([
                'balance_coin' => $newCoin,
                'balance_token' => $newToken,
                'balance_dollar' => $newDollar,
                'balance_referral_dollar' => $newReferralDollar,
                'kyc_status' => $newKyc,
                'is_banned' => $isBanned
            ]);

            \DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'User Modified!',
                'message' => "User ID #$targetUid details modified successfully! 👤",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.users');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->with('error', 'Update failed: ' . $e->getMessage());
        }
    }
}