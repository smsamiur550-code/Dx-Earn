<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\PaymentRequest;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class PaymentController extends Controller
{
    public function index(Request $request)
    {
        $currentSubTab = clean_data($request->query('sub_tab', 'pending'));

        $depositsList = PaymentRequest::join('users', 'payment_requests.user_id', '=', 'users.id')
            ->where('payment_requests.status', $currentSubTab)
            ->select('payment_requests.*', 'users.username', 'users.kyc_status')
            ->orderBy('payment_requests.id', 'desc')
            ->limit(40)
            ->get();

        return view('admin.payment', compact('currentSubTab', 'depositsList'));
    }

    public function audit(Request $request)
    {
        $paymentId = intval($request->input('payment_id'));
        $action = clean_data($request->input('payment_action'));

        $payment = PaymentRequest::find($paymentId);

        if (!$payment) {
            return back()->with('error', 'Payment request details could not be found.');
        }

        if ($payment->status !== 'pending') {
            return back()->with('error', 'This transaction has already been audited.');
        }

        $user = User::find($payment->user_id);
        if (!$user) {
            return back()->with('error', 'Associated user account not found.');
        }

        DB::beginTransaction();
        try {
            $meta = json_decode($payment->meta_data, true) ?: [];
            $botToken = get_setting_val('bot_token') ?: '';

            if ($action === 'approve') {
                $payment->status = 'approved';
                $payment->save();

                if ($payment->payment_type === 'coin_to_token') {
                    $tokens = floatval($meta['tokens'] ?? 0);
                    update_balance($user->id, $tokens, 'token', 'add');
                    log_transaction($user->id, 'income', 'credit', 'token', $tokens, "Approved Coin conversion request #$paymentId");
                } else {
                    $amount = floatval($payment->amount);
                    update_balance($user->id, $amount, 'usd', 'add');
                    log_transaction($user->id, 'income', 'credit', 'usd', $amount, "Approved direct deposit request #$paymentId");
                }

                $successMsg = "Payment request #$paymentId approved successfully!";

                if (!empty($user->telegram_id) && !empty($botToken)) {
                    $msg = "<b>DX EARN Deposit Approved!</b> 💳\n\nHello, your conversion deposit request of <b>$ " . number_format($payment->amount, 2) . "</b> has been successfully <b>APPROVED</b> and credited!";
                    send_telegram_notification($user->telegram_id, $msg, $botToken);
                }
            } else {
                if ($payment->payment_type === 'coin_to_token') {
                    $amountCoin = floatval($meta['amount_coin'] ?? 0);
                    if ($amountCoin > 0) {
                        $refundAmount = $amountCoin * 0.90;
                        update_balance($user->id, $refundAmount, 'coin', 'add');
                        log_transaction($user->id, 'income', 'credit', 'coin', $refundAmount, "Refunded 90% Coins from rejected conversion request #$paymentId (10% penalty deducted)");
                    }
                }

                $payment->status = 'rejected';
                $payment->save();

                $successMsg = "Payment request #$paymentId rejected and marked cancelled. 90% coins refunded.";

                if (!empty($user->telegram_id) && !empty($botToken)) {
                    $msg = "<b>DX EARN Conversion Rejected</b> ⚠️\n\nHello, your conversion request #{$paymentId} was <b>REJECTED</b>. 90% of your Coins have been refunded. 10% penalty was applied.";
                    send_telegram_notification($user->telegram_id, $msg, $botToken);
                }
            }

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Audit Complete!',
                'message' => $successMsg,
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.payment', ['sub_tab' => $currentSubTab ?? 'pending']);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to audit payment: ' . $e->getMessage());
        }
    }
}