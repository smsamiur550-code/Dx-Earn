<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\GiftCode;

class GiftController extends Controller
{
    public function index()
    {
        $gifts = GiftCode::orderBy('id', 'desc')->limit(40)->get();
        return view('admin.gift', compact('gifts'));
    }

    public function create(Request $request)
    {
        $rewardAmount = floatval($request->input('reward_amount', 0));
        if ($rewardAmount <= 0) {
            return back()->with('error', 'Please enter a valid reward amount greater than 0.');
        }

        $uniqueCodeFound = false;
        $maxAttempts = 15;
        $attempt = 0;
        $code = "";

        while (!$uniqueCodeFound && $attempt < $maxAttempts) {
            $code = 'DX-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 7));
            if (!GiftCode::where('code', $code)->exists()) {
                $uniqueCodeFound = true;
            }
            $attempt++;
        }

        if ($uniqueCodeFound) {
            try {
                GiftCode::create([
                    'code' => $code,
                    'coin_amount' => $rewardAmount,
                    'created_at' => now()
                ]);

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Promo Code Created!',
                    'message' => "Promo code #$code generated successfully! 🎁",
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('admin.gift');
            } catch (\Exception $e) {
                return back()->with('error', 'Failed to generate promo code: ' . $e->getMessage());
            }
        } else {
            return back()->with('error', 'Failed to secure a unique random code.');
        }
    }

    public function delete(Request $request)
    {
        $giftId = intval($request->input('gift_id'));
        try {
            GiftCode::where('id', $giftId)->delete();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Promo Code Deleted!',
                'message' => "Promo code removed successfully. 🧹",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.gift');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete promo code: ' . $e->getMessage());
        }
    }
}