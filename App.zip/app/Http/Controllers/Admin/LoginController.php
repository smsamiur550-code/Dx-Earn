<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cookie;
use App\Models\Admin;

class LoginController extends Controller
{
    protected string $secureKey = 'secure_admin_salt_key_dxearn_999';

    public function showLogin()
    {
        if (session()->has('admin_id')) {
            return redirect()->route('admin.dashboard');
        }

        $rememberCookie = Cookie::get('dx_admin_remember');
        if ($rememberCookie) {
            $parts = explode(':', $rememberCookie, 2);
            if (count($parts) === 2) {
                list($cookieUser, $cookieHash) = $parts;
                $expectedHash = hash_hmac('sha256', $cookieUser, $this->secureKey);
                
                if (hash_equals($expectedHash, $cookieHash)) {
                    $ownerUsername = get_setting_val('admin_username') ?: 'admin';
                    if ($cookieUser === $ownerUsername) {
                        session([
                            'admin_id' => $cookieUser,
                            'admin_role' => 'owner',
                            'admin_permissions' => []
                        ]);
                        return redirect()->route('admin.dashboard');
                    } else {
                        $subAdmin = Admin::where('username', $cookieUser)->where('is_active', 1)->first();
                        if ($subAdmin) {
                            session([
                                'admin_id' => $subAdmin->username,
                                'admin_role' => 'admin',
                                'admin_permissions' => json_decode($subAdmin->permissions, true) ?: []
                            ]);
                            return redirect()->route('admin.dashboard');
                        }
                    }
                }
            }
        }

        return view('admin.login');
    }

    public function login(Request $request)
    {
        $lockoutUntil = intval(get_setting_val('admin_lockout_until') ?: 0);
        $currentTime = time();

        if ($lockoutUntil > $currentTime) {
            $secondsRemaining = $lockoutUntil - $currentTime;
            return back()->with('error', "🔒 Security Lockout Active! Please wait {$secondsRemaining} seconds before retrying.");
        }

        $username = clean_data($request->input('username', ''));
        $password = $request->input('password', '');

        if (empty($username) || empty($password)) {
            return back()->with('error', 'Username and password are required.');
        }

        $ownerUsername = get_setting_val('admin_username') ?: 'admin';
        $ownerPassHash = get_setting_val('admin_password_hash');

        if (empty($ownerPassHash)) {
            $ownerPassHash = Hash::make('admin123');
            update_setting_val('admin_username', 'admin');
            update_setting_val('admin_password_hash', $ownerPassHash);
        }

        $isOwnerValid = false;
        if ($username === $ownerUsername && Hash::check($password, $ownerPassHash)) {
            $isOwnerValid = true;
        }

        if ($isOwnerValid) {
            update_setting_val('admin_failed_attempts', 0);
            update_setting_val('admin_lockout_until', 0);

            session([
                'admin_id' => $username,
                'admin_role' => 'owner',
                'admin_permissions' => []
            ]);

            $this->setAdminRememberCookie($username);
            return redirect()->route('admin.dashboard');
        } else {
            $subAdmin = Admin::where('username', $username)->where('is_active', 1)->first();

            if ($subAdmin && Hash::check($password, $subAdmin->password)) {
                update_setting_val('admin_failed_attempts', 0);
                update_setting_val('admin_lockout_until', 0);

                session([
                    'admin_id' => $subAdmin->username,
                    'admin_role' => 'admin',
                    'admin_permissions' => json_decode($subAdmin->permissions, true) ?: []
                ]);

                $this->setAdminRememberCookie($username);
                return redirect()->route('admin.dashboard');
            } else {
                $failedAttempts = intval(get_setting_val('admin_failed_attempts') ?: 0);
                $failedAttempts++;
                update_setting_val('admin_failed_attempts', $failedAttempts);

                if ($failedAttempts >= 5) {
                    update_setting_val('admin_lockout_until', time() + 60);
                    update_setting_val('admin_failed_attempts', 0);
                    return back()->with('error', '🚨 Brute Force Lockout! Too many failed attempts. Gateway locked for 60 seconds.');
                } else {
                    $remainingAttempts = 5 - $failedAttempts;
                    return back()->with('error', "Invalid administrator credentials! ({$remainingAttempts} attempts remaining)");
                }
            }
        }
    }

    public function logout()
    {
        session()->forget(['admin_id', 'admin_role', 'admin_permissions']);
        Cookie::queue(Cookie::forget('dx_admin_remember', '/admin/'));
        return redirect()->route('admin.login');
    }

    private function setAdminRememberCookie($username)
    {
        $cookieValue = $username . ':' . hash_hmac('sha256', $username, $this->secureKey);
        Cookie::queue('dx_admin_remember', $cookieValue, 86400 * 30, '/admin/', null, true, true);
    }
}