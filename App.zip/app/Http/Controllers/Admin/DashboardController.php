<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Withdrawal;
use App\Models\PaymentRequest;
use App\Models\Order;
use App\Models\LotteryTicket;
use App\Models\Setting;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class DashboardController extends Controller
{
    // Admin Dashboard Home (admin/index.php)
    public function index()
    {
        try {
            $totalUsers = User::count();
            $activeUsers = User::where('is_banned', 0)->count();
            $bannedUsers = User::where('is_banned', 1)->count();

            $totalCoins = floatval(User::sum('balance_coin'));
            $totalTokens = floatval(User::sum('balance_token'));

            $totalWithdraw = floatval(Withdrawal::where('status', 'approved')->sum('amount'));
            $pendingWithdraw = Withdrawal::where('status', 'pending')->count();

            $pendingPayments = PaymentRequest::where('status', 'pending')->count();
            $pendingOrders = Order::where('status', 'pending')->count();

            $completedOrders = Order::where('status', 'completed')->count();
            $activeLotteryTickets = LotteryTicket::count();
            
            $totalGiftCodeClaims = DB::table('user_gift_claims')->count();
            $completedTasksToday = DB::table('user_tasks')->whereDate('completed_at', now()->toDateString())->count();

            $totalPendingRequests = $pendingWithdraw + $pendingPayments + $pendingOrders;

            // Generate weekly analytics growth chart data
            $growthLabels = [];
            $growthData = [];
            $growthRows = User::where('created_at', '>=', now()->subDays(7))
                ->select(DB::raw('DATE(created_at) as date'), DB::raw('COUNT(*) as count'))
                ->groupBy('date')
                ->orderBy('date', 'asc')
                ->get();

            foreach ($growthRows as $row) {
                $growthLabels[] = date('d M', strtotime($row->date));
                $growthData[] = intval($row->count);
            }

            if (empty($growthLabels)) {
                $growthLabels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                $growthData = [0, 0, 0, 0, 0, 0, max(1, $totalUsers)];
            }

            $revenueData = [];
            $revRows = Withdrawal::where('status', 'approved')
                ->where('requested_at', '>=', now()->subDays(7))
                ->select(DB::raw('DATE(requested_at) as date'), DB::raw('SUM(amount) as sum'))
                ->groupBy('date')
                ->orderBy('date', 'asc')
                ->get();

            foreach ($revRows as $row) {
                $revenueData[] = floatval($row->sum);
            }

            if (empty($revenueData)) {
                $revenueData = [0, 0, 0, 0, 0, 0, max(1, $totalWithdraw)];
            }

            if (count($revenueData) < count($growthLabels)) {
                $revenueData = array_pad($revenueData, count($growthLabels), 0);
            }

            return view('admin.index', compact(
                'totalUsers', 'activeUsers', 'bannedUsers', 'totalCoins', 'totalTokens',
                'totalWithdraw', 'pendingWithdraw', 'pendingPayments', 'pendingOrders',
                'completedOrders', 'activeLotteryTickets', 'totalGiftCodeClaims',
                'completedTasksToday', 'totalPendingRequests', 'growthLabels', 'growthData', 'revenueData'
            ));

        } catch (\Exception $e) {
            return view('admin.index')->with('error', "Database metrics error: " . $e->getMessage());
        }
    }

    // Global settings editor (admin/settings.php)
    public function showSettings()
    {
        $google_client_id = get_setting_val('google_client_id') ?: '';
        $google_client_secret = get_setting_val('google_client_secret') ?: '';
        $google_redirect_url = get_setting_val('google_redirect_url') ?: '';
        $monetag_direct_link = get_setting_val('monetag_direct_link') ?: '';
        $live_market_link = get_setting_val('live_market_link') ?: '';
        $coin_to_token_rate = floatval(get_setting_val('coin_to_token_rate') ?: 0.1000);
        $token_to_dollar_rate = floatval(get_setting_val('token_to_dollar_rate') ?: 0.25);
        $min_withdraw = floatval(get_setting_val('min_withdraw') ?: 5.00);
        $usd_to_bdt_rate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        // Refer bonus settings
        $ref_bonus_referrer = floatval(get_setting_val('ref_bonus_referrer') ?: 0.50);
        $ref_bonus_referee = floatval(get_setting_val('ref_bonus_referee') ?: 0.20);

        // Customizations settings
        $coin_symbol = get_setting_val('coin_symbol') ?: '🪙';
        $token_symbol = get_setting_val('token_symbol') ?: '🟡';
        $btn_name_games = get_setting_val('btn_name_games') ?: 'Games';
        $btn_name_mining = get_setting_val('btn_name_mining') ?: 'Mining';

        $sliders = DB::table('homepage_sliders')->orderBy('id', 'desc')->get();

        return view('admin.settings', compact(
            'google_client_id', 'google_client_secret', 'google_redirect_url',
            'monetag_direct_link', 'live_market_link', 'coin_to_token_rate',
            'token_to_dollar_rate', 'min_withdraw', 'usd_to_bdt_rate',
            'ref_bonus_referrer', 'ref_bonus_referee', 'coin_symbol', 'token_symbol',
            'btn_name_games', 'btn_name_mining', 'sliders'
        ));
    }

    public function saveGlobalSettings(Request $request)
    {
        DB::beginTransaction();
        try {
            update_setting_val('google_client_id', clean_data($request->input('google_client_id', '')));
            update_setting_val('google_client_secret', clean_data($request->input('google_client_secret', '')));
            update_setting_val('google_redirect_url', clean_data($request->input('google_redirect_url', '')));
            update_setting_val('monetag_direct_link', clean_data($request->input('monetag_direct_link', '')));
            update_setting_val('live_market_link', clean_data($request->input('live_market_link', '')));
            update_setting_val('coin_to_token_rate', floatval($request->input('coin_to_token_rate', 0.1000)));
            update_setting_val('token_to_dollar_rate', floatval($request->input('token_to_dollar_rate', 0.25)));
            update_setting_val('min_withdraw', floatval($request->input('min_withdraw', 5.00)));
            update_setting_val('usd_to_bdt_rate', floatval($request->input('usd_to_bdt_rate', 120.00)));
            
            update_setting_val('ref_bonus_referrer', floatval($request->input('ref_bonus_referrer', 0.50)));
            update_setting_val('ref_bonus_referee', floatval($request->input('ref_bonus_referee', 0.20)));
            
            update_setting_val('coin_symbol', clean_data($request->input('coin_symbol', '🪙')));
            update_setting_val('token_symbol', clean_data($request->input('token_symbol', '🟡')));
            update_setting_val('btn_name_games', clean_data($request->input('btn_name_games', 'Games')));
            update_setting_val('btn_name_mining', clean_data($request->input('btn_name_mining', 'Mining')));

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Settings Saved!',
                'message' => 'Global configurations updated successfully! ⚙️',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.settings');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }

    public function addSlider(Request $request)
    {
        $title = clean_data($request->input('title', ''));
        $desc = clean_data($request->input('desc_text', ''));
        $grad = clean_data($request->input('grad', 'from-blue-500 to-indigo-600'));
        $redirectUrl = clean_data($request->input('redirect_url', ''));

        if (empty($title) || empty($desc)) {
            return back()->with('error', 'Title and Description are required to create a new slider card.');
        }

        try {
            DB::table('homepage_sliders')->insert([
                'grad' => $grad,
                'title' => $title,
                'desc_text' => $desc,
                'redirect_url' => $redirectUrl
            ]);

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Slider Added!',
                'message' => 'New homepage promo slider added successfully! 🚀',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.settings');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to add slider: ' . $e->getMessage());
        }
    }

    public function deleteSlider(Request $request)
    {
        $sliderId = intval($request->input('slider_id', 0));
        try {
            DB::table('homepage_sliders')->where('id', $sliderId)->delete();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Slider Removed!',
                'message' => 'Slider item deleted successfully. 🧹',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.settings');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to remove slider: ' . $e->getMessage());
        }
    }
}