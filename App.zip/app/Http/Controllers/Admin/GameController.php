<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GameController extends Controller
{
    public function index()
    {
        $dice_limit = intval(get_setting_val('dice_limit') ?: 10);
        $dice_point_value = floatval(get_setting_val('dice_point_value') ?: 10.00);

        $scratch_limit = intval(get_setting_val('scratch_limit') ?: 5);
        $scratch_min_prize = floatval(get_setting_val('scratch_min_prize') ?: 5.00);
        $scratch_max_prize = floatval(get_setting_val('scratch_max_prize') ?: 50.00);

        $spin_limit = intval(get_setting_val('spin_limit') ?: 5);
        $spin_reward = floatval(get_setting_val('spin_reward') ?: 10.00);
        $spin_prize_0_val = floatval(get_setting_val('spin_prize_0_val') ?: 5.00);
        $spin_prize_1_val = floatval(get_setting_val('spin_prize_1_val') ?: 10.00);
        $spin_prize_2_val = floatval(get_setting_val('spin_prize_2_val') ?: 15.00);
        $spin_prize_3_val = floatval(get_setting_val('spin_prize_3_val') ?: 50.00);
        $spin_prize_4_val = floatval(get_setting_val('spin_prize_4_val') ?: 20.00);
        $spin_prize_5_val = floatval(get_setting_val('spin_prize_5_val') ?: 25.00);
        $spin_prize_6_val = floatval(get_setting_val('spin_prize_6_val') ?: 100.00);
        $spin_prize_7_val = floatval(get_setting_val('spin_prize_7_val') ?: 30.00);

        $treasure_limit = intval(get_setting_val('treasure_limit') ?: 5);
        $treasure_val_1 = floatval(get_setting_val('treasure_val_1') ?: 10.00);
        $treasure_val_2 = floatval(get_setting_val('treasure_val_2') ?: 20.00);
        $treasure_val_3 = floatval(get_setting_val('treasure_val_3') ?: 30.00);
        $treasure_val_4 = floatval(get_setting_val('treasure_val_4') ?: 50.00);
        $treasure_val_5 = floatval(get_setting_val('treasure_val_5') ?: 80.00);
        $treasure_val_6 = floatval(get_setting_val('treasure_val_6') ?: 100.00);
        $treasure_val_7 = floatval(get_setting_val('treasure_val_7') ?: 150.00);
        $treasure_val_8 = floatval(get_setting_val('treasure_val_8') ?: 200.00);
        $treasure_val_9 = floatval(get_setting_val('treasure_val_9') ?: 500.00);

        $math_limit = intval(get_setting_val('math_limit') ?: 10);
        $math_reward = floatval(get_setting_val('math_reward') ?: 10.00);

        $word_limit = intval(get_setting_val('word_limit') ?: 10);
        $word_reward = floatval(get_setting_val('word_reward') ?: 15.00);

        $quiz_limit = intval(get_setting_val('quiz_limit') ?: 10);
        $quiz_reward = floatval(get_setting_val('quiz_reward') ?: 20.00);

        $brain_limit = intval(get_setting_val('brain_limit') ?: 10);
        $brain_reward = floatval(get_setting_val('brain_reward') ?: 20.00);

        $puzzle_limit = intval(get_setting_val('puzzle_limit') ?: 10);
        $puzzle_reward = floatval(get_setting_val('puzzle_reward') ?: 25.00);

        $emoji_limit = intval(get_setting_val('emoji_limit') ?: 10);
        $emoji_reward = floatval(get_setting_val('emoji_reward') ?: 20.00);

        return view('admin.game', compact(
            'dice_limit', 'dice_point_value', 'scratch_limit', 'scratch_min_prize', 'scratch_max_prize',
            'spin_limit', 'spin_reward', 'spin_prize_0_val', 'spin_prize_1_val', 'spin_prize_2_val',
            'spin_prize_3_val', 'spin_prize_4_val', 'spin_prize_5_val', 'spin_prize_6_val', 'spin_prize_7_val',
            'treasure_limit', 'treasure_val_1', 'treasure_val_2', 'treasure_val_3', 'treasure_val_4',
            'treasure_val_5', 'treasure_val_6', 'treasure_val_7', 'treasure_val_8', 'treasure_val_9',
            'math_limit', 'math_reward', 'word_limit', 'word_reward', 'quiz_limit', 'quiz_reward',
            'brain_limit', 'brain_reward', 'puzzle_limit', 'puzzle_reward', 'emoji_limit', 'emoji_reward'
        ));
    }

    public function saveGameConfig(Request $request)
    {
        try {
            update_setting_val('dice_point_value', floatval($request->input('dice_point_value', 10.00)));
            update_setting_val('dice_limit', intval($request->input('dice_limit', 10)));

            update_setting_val('scratch_limit', intval($request->input('scratch_limit', 5)));
            update_setting_val('scratch_min_prize', floatval($request->input('scratch_min_prize', 5.00)));
            update_setting_val('scratch_max_prize', floatval($request->input('scratch_max_prize', 50.00)));

            update_setting_val('spin_limit', intval($request->input('spin_limit', 25)));
            update_setting_val('spin_reward', floatval($request->input('spin_reward', 10.00)));
            for ($i = 0; $i <= 7; $i++) {
                update_setting_val("spin_prize_{$i}_val", floatval($request->input("spin_prize_{$i}_val", 5.00)));
            }

            update_setting_val('treasure_limit', intval($request->input('treasure_limit', 5)));
            for ($i = 1; $i <= 9; $i++) {
                update_setting_val("treasure_val_{$i}", floatval($request->input("treasure_val_{$i}", 10.00)));
            }

            update_setting_val('math_limit', intval($request->input('math_limit', 10)));
            update_setting_val('math_reward', floatval($request->input('math_reward', 10.00)));

            update_setting_val('word_limit', intval($request->input('word_limit', 10)));
            update_setting_val('word_reward', floatval($request->input('word_reward', 15.00)));

            update_setting_val('quiz_limit', intval($request->input('quiz_limit', 10)));
            update_setting_val('quiz_reward', floatval($request->input('quiz_reward', 20.00)));

            update_setting_val('brain_limit', intval($request->input('brain_limit', 10)));
            update_setting_val('brain_reward', floatval($request->input('brain_reward', 20.00)));

            update_setting_val('puzzle_limit', intval($request->input('puzzle_limit', 10)));
            update_setting_val('puzzle_reward', floatval($request->input('puzzle_reward', 25.00)));

            update_setting_val('emoji_limit', intval($request->input('emoji_limit', 10)));
            update_setting_val('emoji_reward', floatval($request->input('emoji_reward', 20.00)));

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Configs Saved!',
                'message' => 'Interactive mini games parameters configured successfully. 🕹️',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.game');
        } catch (\Exception $e) {
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }
}