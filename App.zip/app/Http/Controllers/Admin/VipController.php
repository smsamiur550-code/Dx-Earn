<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\VipPlan;

class VipController extends Controller
{
    public function index()
    {
        $vipPlans = VipPlan::orderBy('price', 'asc')->get();
        return view('admin.vip', compact('vipPlans'));
    }

    public function saveVipPlan(Request $request)
    {
        $planId = intval($request->input('product_id', 0)); // Maps with legacy form variable
        if ($planId === 0) {
            $planId = intval($request->input('plan_id', 0));
        }
        $name = clean_data($request->input('name', ''));
        $price = floatval($request->input('price', 0));
        $duration = intval($request->input('duration_days', 0));
        $desc = clean_data($request->input('description', ''));

        if (empty($name) || $price <= 0 || $duration < 0) {
            return back()->with('error', 'Please provide valid product name, price, and stock levels.');
        }

        try {
            VipPlan::updateOrCreate(
                ['id' => $planId],
                [
                    'name' => $name,
                    'price' => $price,
                    'duration_days' => $duration,
                    'benefits' => $desc,
                    'extra_mining_income' => 2.00,
                    'faster_mining_speed' => 2.00,
                    'daily_bonus' => 2.00
                ]
            );

            $msg = $planId > 0 ? "Product parameters saved successfully!" : "New product published successfully!";
            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Product Saved!',
                'message' => $msg . ' 👑',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.vip');
        } catch (\Exception $e) {
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }

    public function deletePlan(Request $request)
    {
        $planId = intval($request->input('plan_id', 0));
        try {
            VipPlan::where('id', $planId)->delete();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Product Terminated!',
                'message' => "Product deleted permanently from inventory. 🧹",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.vip');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete plan: ' . $e->getMessage());
        }
    }
}