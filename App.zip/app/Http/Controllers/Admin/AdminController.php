<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function index()
    {
        $admins = Admin::orderBy('id', 'desc')->get();
        $availablePermissions = [
            'index.php' => '📊 Dashboard',
            'user.php' => '👥 Members List',
            'chat.php' => '💬 Live Support Chat',
            'task.php' => '📝 Missions Hub',
            'gift.php' => '🎁 Promo Codes',
            'payment.php' => '💳 Deposits Audit',
            'withdraw.php' => '💵 Payout Audit',
            'withdraw2.php' => '⚙️ Voucher Feed',
            'shop.php' => '🛍️ Shop Config',
            'products.php' => '📦 Product Inventory',
            'orders.php' => '🚚 Shop Orders',
            'lottery.php' => '🎫 Weekly Draw',
            'game.php' => '🕹️ Games Settings',
            'mining.php' => '⛏️ Mining Nodes',
            'vip.php' => '👑 VIP Cards Setup'
        ];

        return view('admin.admin', compact('admins', 'availablePermissions'));
    }

    public function handleAction(Request $request)
    {
        $action = clean_data($request->input('action', ''));

        if ($action === 'create') {
            $username = clean_data($request->input('username', ''));
            $password = $request->input('password', '');
            $perms = $request->input('permissions', []);
            $permsJson = json_encode($perms);

            if (empty($username) || empty($password)) {
                return back()->with('error', 'Please provide both sub-admin username and password credentials.');
            }

            if (Admin::where('username', $username)->exists()) {
                return back()->with('error', 'Username is already registered as a sub-admin.');
            }

            try {
                Admin::create([
                    'username' => $username,
                    'password' => Hash::make($password),
                    'permissions' => $permsJson,
                    'is_active' => 1,
                    'created_at' => now()
                ]);

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Sub-Admin Created!',
                    'message' => "Successfully registered @$username as sub-admin! 🛡️",
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('admin.admin_list');
            } catch (\Exception $e) {
                return back()->with('error', 'Creation failed: ' . $e->getMessage());
            }
        }

        if ($action === 'edit') {
            $subId = intval($request->input('admin_id', 0));
            $password = $request->input('password', '');
            $perms = $request->input('permissions', []);
            $permsJson = json_encode($perms);
            $isActive = intval($request->input('is_active', 1));

            $admin = Admin::find($subId);
            if (!$admin) {
                return back()->with('error', 'Sub-admin record not found.');
            }

            try {
                $updateData = [
                    'permissions' => $permsJson,
                    'is_active' => $isActive
                ];

                if (!empty($password)) {
                    $updateData['password'] = Hash::make($password);
                }

                $admin->update($updateData);

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Sub-Admin Updated!',
                    'message' => "Successfully updated sub-admin configurations! ⚙️",
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('admin.admin_list');
            } catch (\Exception $e) {
                return back()->with('error', 'Modification failed: ' . $e->getMessage());
            }
        }

        if ($action === 'delete') {
            $subId = intval($request->input('delete_id', 0));
            try {
                Admin::where('id', $subId)->delete();

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Sub-Admin Deleted!',
                    'message' => "Successfully removed sub-admin from database. 🧹",
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('admin.admin_list');
            } catch (\Exception $e) {
                return back()->with('error', 'Deletion failed: ' . $e->getMessage());
            }
        }

        return redirect()->route('admin.admin_list');
    }
}