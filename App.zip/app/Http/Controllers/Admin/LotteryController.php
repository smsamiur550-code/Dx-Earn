<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\LotteryTicket;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class LotteryController extends Controller
{
    public function index()
    {
        $nextDrawTimeVal = get_setting_val('next_lottery_draw_time') ?: 'next Sunday 20:00:00';
        $ticketPriceVal   = floatval(get_setting_val('lottery_ticket_price') ?: 50.00);
        $prize1Val = floatval(get_setting_val('lottery_prize_1_amount') ?: 100000.00);

        $activeTicketsCount = LotteryTicket::whereIn('status', ['approved', 'pending'])->count();

        return view('admin.lottery', compact('nextDrawTimeVal', 'ticketPriceVal', 'prize1Val', 'activeTicketsCount'));
    }

    public function saveSchedule(Request $request)
    {
        $nextDrawTime = clean_data($request->input('next_lottery_draw_time', ''));
        $ticketPrice = floatval($request->input('lottery_ticket_price', 50.00));

        DB::beginTransaction();
        try {
            update_setting_val('next_lottery_draw_time', $nextDrawTime);
            update_setting_val('lottery_ticket_price', $ticketPrice);
            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Schedule Saved!',
                'message' => 'Sweepstakes schedule and ticket pricing saved successfully. ⏰',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.lottery');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }

    public function savePrizes(Request $request)
    {
        $prize1Val = floatval($request->input('prize_1_amount', 100000.00));

        DB::beginTransaction();
        try {
            update_setting_val('lottery_prize_1_amount', $prize1Val);
            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Jackpot Saved!',
                'message' => 'Weekly sweepstakes jackpot prize pool configured successfully! 🎁',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.lottery');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to save prize configuration: ' . $e->getMessage());
        }
    }

    public function drawLottery()
    {
        DB::beginTransaction();
        try {
            $winner = LotteryTicket::whereIn('status', ['pending', 'approved'])
                ->inRandomOrder()
                ->first();

            if ($winner) {
                $winnerUid = $winner->user_id;
                $prizeAmount = floatval(get_setting_val('lottery_prize_1_amount') ?: 100000.00);

                $winner->status = 'winner';
                $winner->prize_amount = $prizeAmount;
                $winner->save();

                update_balance($winnerUid, $prizeAmount, 'coin', 'add');
                log_transaction($winnerUid, 'income', 'credit', 'coin', $prizeAmount, "Winner of Weekly Jackpot ticket: " . $winner->ticket_number);
                add_notification($winnerUid, 'lottery', "Congratulations! You won the Weekly Jackpot Draw of 🪙 " . number_format($prizeAmount, 2));

                LotteryTicket::where('status', '!=', 'winner')->update(['status' => 'lost']);

                update_setting_val('last_lottery_draw_time', now()->toDateTimeString());
                DB::commit();

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Draw Concluded!',
                    'message' => 'Winner selected with ticket #' . $winner->ticket_number . '! 🪙 ' . number_format($prizeAmount) . ' credited successfully! 🏆',
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('admin.lottery');
            } else {
                throw new \Exception("No active approved/pending lottery tickets found in the pool to run the draw.");
            }
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', $e->getMessage());
        }
    }
}