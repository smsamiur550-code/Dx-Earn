<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MiningController extends Controller
{
    public function index()
    {
        $miningDurationHours = floatval(get_setting_val('mining_base_duration_hours') ?: 4.0);
        $miningYieldHourly   = floatval(get_setting_val('mining_base_yield_hourly') ?: 200.00);
        $miningBoostAdWait  = intval(get_setting_val('mining_boost_ad_wait_seconds') ?: 10);
        $miningBoostMult     = floatval(get_setting_val('mining_boost_multiplier') ?: 2.0);
        $miningBoostDuration = floatval(get_setting_val('mining_boost_duration_hours') ?: 2.0);
        $miningBoostCooldown = floatval(get_setting_val('mining_boost_cooldown_hours') ?: 4.0);

        return view('admin.mining', compact(
            'miningDurationHours', 'miningYieldHourly', 'miningBoostAdWait',
            'miningBoostMult', 'miningBoostDuration', 'miningBoostCooldown'
        ));
    }

    public function saveMiningConfig(Request $request)
    {
        try {
            update_setting_val('mining_base_duration_hours', floatval($request->input('mining_base_duration_hours', 4.0)));
            update_setting_val('mining_base_yield_hourly', floatval($request->input('mining_base_yield_hourly', 200.00)));
            
            update_setting_val('mining_boost_ad_wait_seconds', intval($request->input('mining_boost_ad_wait_seconds', 10)));
            update_setting_val('mining_boost_duration_hours', floatval($request->input('mining_boost_duration_hours', 2.0)));
            update_setting_val('mining_boost_cooldown_hours', floatval($request->input('mining_boost_cooldown_hours', 4.0)));
            update_setting_val('mining_boost_multiplier', floatval($request->input('mining_boost_multiplier', 2.0)));

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Mining Configured!',
                'message' => 'Cloud mining hashing node parameters configured successfully! ⛏️',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.mining');
        } catch (\Exception $e) {
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }
}