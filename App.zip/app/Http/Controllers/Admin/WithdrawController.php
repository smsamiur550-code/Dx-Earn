<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Withdrawal;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class WithdrawController extends Controller
{
    public function index(Request $request)
    {
        $currentSubTab = clean_data($request->query('sub_tab', 'pending'));

        $withdrawals = Withdrawal::join('users', 'withdrawals.user_id', '=', 'users.id')
            ->where('withdrawals.status', $currentSubTab)
            ->select('withdrawals.*', 'users.username')
            ->orderBy('withdrawals.id', 'desc')
            ->get();

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('admin.withdraw', compact('currentSubTab', 'withdrawals', 'takaRate'));
    }

    public function audit(Request $request)
    {
        $orderId = intval($request->input('order_id', 0)); // Matches legacy audit request variables
        if ($orderId === 0) {
            $orderId = intval($request->input('withdrawal_id', 0));
        }
        $action = clean_data($request->input('withdraw_action', ''));
        $currentSubTab = clean_data($request->input('sub_tab', 'pending'));

        $withdrawal = Withdrawal::find($orderId);

        if (!$withdrawal) {
            return back()->with('error', 'Withdrawal request details could not be found.');
        }

        if ($withdrawal->status !== 'pending') {
            return back()->with('error', 'This cashout request has already been processed.');
        }

        $user = User::find($withdrawal->user_id);
        if (!$user) {
            return back()->with('error', 'Associated user account not found.');
        }

        DB::beginTransaction();
        try {
            $botToken = get_setting_val('bot_token') ?: '';

            if ($action === 'approve') {
                $withdrawal->status = 'approved';
                $withdrawal->save();

                log_transaction($user->id, 'withdraw', 'debit', 'usd', $withdrawal->amount, "Approved cashout of $ " . $withdrawal->amount . " via " . $paymentMethod = $withdrawal->payment_method);
                add_notification($user->id, 'withdraw', "Your withdrawal request of $ " . $withdrawal->amount . " has been approved successfully! 🚀");

                $successMsg = "Withdrawal request #" . $withdrawal->id . " approved successfully!";

                if (!empty($user->telegram_id) && !empty($botToken)) {
                    $msg = "<b>DX EARN Withdrawal Approved!</b> 💵\n\nYour cashout request of <b>$ " . number_format($withdrawal->amount, 2) . "</b> has been successfully <b>APPROVED</b>.";
                    send_telegram_notification($user->telegram_id, $msg, $botToken);
                }
            } else {
                $withdrawal->status = 'cancelled';
                $withdrawal->save();

                $currencyKey = ($withdrawal->withdrawal_type === 'referral_usd') ? 'referral_dollar' : 'usd';
                update_balance($user->id, $withdrawal->amount, $currencyKey, 'add');

                log_transaction($user->id, 'income', 'credit', $currencyKey, $payment ?? $withdrawal->amount, "Refunded cancelled cashout of $ " . $withdrawal->amount);
                add_notification($user->id, 'withdraw', "Your withdrawal of $ " . $payment ?? $withdrawal->amount . " has been cancelled. 100% funds refunded to your balance. 🔄");

                $successMsg = "Withdrawal request #" . $paymentId = $withdrawal->id . " cancelled and 100% refunded successfully!";

                if (!empty($user->telegram_id) && !empty($botToken)) {
                    $msg = "<b>DX EARN Withdrawal Cancelled</b> ⚠️\n\nYour withdrawal request of <b>$ " . number_format($payment ?? $withdrawal->amount, 2) . "</b> has been <b>CANCELLED</b>. 100% of your funds have been returned to your wallet.";
                    send_telegram_notification($user->telegram_id, $msg, $botToken);
                }
            }

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Audit Complete!',
                'message' => $successMsg,
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.withdraw', ['sub_tab' => $currentSubTab]);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Operation failed: ' . $e->getMessage());
        }
    }

    public function feedIndex(Request $request)
    {
        $limit = 50;
        $page = max(1, intval($request->query('page', 1)));
        $offset = ($page - 1) * $limit;

        $totalRows = Withdrawal::count();
        $totalPages = ceil($totalRows / $limit);

        $feedWithdrawals = Withdrawal::join('users', 'withdrawals.user_id', '=', 'users.id')
            ->select('withdrawals.*', 'users.username')
            ->orderBy('withdrawals.id', 'desc')
            ->offset($offset)
            ->limit($limit)
            ->get();

        $feedStatusVal = get_setting_val('live_feed_status') ?: '1';
        $ticketStartVal = intval(get_setting_val('withdraw_ticket_start') ?: 1);

        return view('admin.withdraw2', compact('feedWithdrawals', 'totalRows', 'limit', 'page', 'totalPages', 'feedStatusVal', 'ticketStartVal'));
    }

    public function generateFake()
    {
        try {
            $randUser = User::where('is_banned', 0)->inRandomOrder()->first();
            if (!$randUser) {
                return back()->with('error', 'No active users found to map the simulated transaction.');
            }

            $fakeAmount = mt_rand(5, 50) + (mt_rand(0, 99) / 100);
            $gateways = ['Binance Pay', 'Trust Wallet', 'Free Fire Diamond Topup 🎮'];
            $fakeGateway = $gateways[array_rand($gateways)];

            if ($fakeGateway === 'Free Fire Diamond Topup 🎮') {
                $fakeAccount = 'Player UID: ' . mt_rand(10000000, 99999999);
            } else {
                $fakeAccount = 'mock_' . bin2hex(random_bytes(8));
            }

            $ticketNumber = generate_withdraw_ticket();

            Withdrawal::create([
                'user_id' => $randUser->id,
                'amount' => $fakeAmount,
                'payment_method' => $fakeGateway,
                'account_number' => $fakeAccount,
                'status' => 'approved',
                'withdrawal_type' => 'main_usd',
                'ticket_number' => $ticketNumber,
                'requested_at' => now()->subMinutes(mt_rand(5, 1440))
            ]);

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Simulated Payout Injected!',
                'message' => 'A mock cashout has been generated and successfully logged into the live feed registry! 🎲',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.withdraw_feed');
        } catch (\Exception $e) {
            return back()->with('error', 'Mock Generation Failed: ' . $e->getMessage());
        }
    }

    public function saveFeedSettings(Request $request)
    {
        $feedStatus = clean_data($request->input('live_feed_status', '1'));
        $ticketStart = intval($request->input('withdraw_ticket_start', 1));

        DB::beginTransaction();
        try {
            update_setting_val('live_feed_status', $feedStatus);
            update_setting_val('withdraw_ticket_start', $ticketStart);
            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Configs Saved!',
                'message' => 'Payout feed and ticket configurations updated successfully! ⚙️',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.withdraw_feed');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to save settings: ' . $e->getMessage());
        }
    }
}