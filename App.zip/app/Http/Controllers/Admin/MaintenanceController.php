<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MaintenanceController extends Controller
{
    public function index()
    {
        $cleanup_enabled_val = intval(get_setting_val('cleanup_enabled') ?? 1);
        $cleanup_ad_views_val = intval(get_setting_val('cleanup_ad_views_days') ?: 7);
        $cleanup_game_history_val = intval(get_setting_val('cleanup_game_history_days') ?: 1);
        $cleanup_mining_val = intval(get_setting_val('cleanup_mining_days') ?: 7);
        $cleanup_game_plays_val = intval(get_setting_val('cleanup_game_plays_days') ?: 1);
        $cleanup_gift_claims_val = intval(get_setting_val('cleanup_gift_claims_days') ?: 30);
        $cleanup_tasks_val = intval(get_setting_val('cleanup_tasks_days') ?: 30);
        $cleanup_chats_val = intval(get_setting_val('cleanup_chats_days') ?: 30);
        $cleanup_tickets_val = intval(get_setting_val('cleanup_tickets_days') ?: 30);

        return view('admin.maintenance', compact(
            'cleanup_enabled_val', 'cleanup_ad_views_val', 'cleanup_game_history_val',
            'cleanup_mining_val', 'cleanup_game_plays_val', 'cleanup_gift_claims_val',
            'cleanup_tasks_val', 'cleanup_chats_val', 'cleanup_tickets_val'
        ));
    }

    public function saveCleanupSettings(Request $request)
    {
        $cleanup_enabled = $request->has('cleanup_enabled') ? 1 : 0;
        $cleanup_ad_views = intval($request->input('cleanup_ad_views_days', 7));
        $cleanup_game_history = intval($request->input('cleanup_game_history_days', 1));
        $cleanup_mining = intval($request->input('cleanup_mining_days', 7));
        $cleanup_game_plays = intval($request->input('cleanup_game_plays_days', 1));
        $cleanup_gift_claims = intval($request->input('cleanup_gift_claims_days', 30));
        $cleanup_tasks = intval($request->input('cleanup_tasks_days', 30));
        $cleanup_chats = intval($request->input('cleanup_chats_days', 30));
        $cleanup_tickets = intval($request->input('cleanup_tickets_days', 30));

        DB::beginTransaction();
        try {
            update_setting_val('cleanup_enabled', $cleanup_enabled);
            update_setting_val('cleanup_ad_views_days', $cleanup_ad_views);
            update_setting_val('cleanup_game_history_days', $cleanup_game_history);
            update_setting_val('cleanup_mining_days', $cleanup_mining);
            update_setting_val('cleanup_game_plays_days', $cleanup_game_plays);
            update_setting_val('cleanup_gift_claims_days', $cleanup_gift_claims);
            update_setting_val('cleanup_tasks_days', $cleanup_tasks);
            update_setting_val('cleanup_chats_days', $cleanup_chats);
            update_setting_val('cleanup_tickets_days', $cleanup_tickets);

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Cleanup Saved!',
                'message' => 'Database auto-delete interval configurations saved successfully! 💾',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.maintenance', ['tab' => 'cleanup']);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Failed to save cleanup settings: ' . $e->getMessage());
        }
    }

    public function cleanOrphans()
    {
        try {
            $exempted = ['default_avatar.png', 'index.html', '.', '..'];
            $usedImages = [];

            // Fetch references across tables
            $usedImages = array_merge($usedImages, DB::table('users')->whereNotNull('profile_pic')->pluck('profile_pic')->map(fn($v) => basename($v))->toArray());
            
            $kycImages = DB::table('kyc')->select('front_img', 'back_img', 'selfie_img')->get();
            foreach ($kycImages as $k) {
                if (!empty($k->front_img)) $usedImages[] = basename($k->front_img);
                if (!empty($k->back_img)) $usedImages[] = basename($k->back_img);
                if (!empty($k->selfie_img)) $usedImages[] = basename($k->selfie_img);
            }

            $usedImages = array_merge($usedImages, DB::table('payment_requests')->whereNotNull('screenshot_pic')->pluck('screenshot_pic')->map(fn($v) => basename($v))->toArray());

            $productImages = DB::table('products')->select('image', 'company_logo')->get();
            foreach ($productImages as $p) {
                if (!empty($p->image)) $usedImages[] = basename($p->image);
                if (!empty($p->company_logo)) $usedImages[] = basename($p->company_logo);
            }

            $usedImages = array_unique($usedImages);

            $directories = [
                public_path('uploads/'),
                public_path('uploads/kyc_docs/'),
                public_path('uploads/payments/')
            ];

            $deletedCount = 0;
            foreach ($directories as $dir) {
                if (file_exists($dir)) {
                    $files = scandir($dir);
                    foreach ($files as $file) {
                        if (!in_array($file, $exempted) && !in_array($file, $usedImages)) {
                            $targetFile = $dir . $file;
                            if (is_file($targetFile)) {
                                @unlink($targetFile);
                                $deletedCount++;
                            }
                        }
                    }
                }
            }

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Media Cleaned!',
                'message' => "Removed $deletedCount orphan/unreferenced media image files from hosting storage. 🧹",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.maintenance', ['tab' => 'media']);
        } catch (\Exception $e) {
            return back()->with('error', 'Clean failed: ' . $e->getMessage());
        }
    }
}