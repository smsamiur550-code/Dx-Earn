<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = Task::orderBy('id', 'desc')->get();
        $dailyTaskLimitVal = intval(get_setting_val('daily_task_limit') ?: 10);
        $taskWaitSecondsVal = intval(get_setting_val('task_wait_seconds') ?: 5);

        return view('admin.task', compact('tasks', 'dailyTaskLimitVal', 'taskWaitSecondsVal'));
    }

    public function saveTask(Request $request)
    {
        $taskId = intval($request->input('task_id', 0));
        $name = clean_data($request->input('name', ''));
        $link = clean_data($request->input('link', ''));
        $reward = floatval($request->input('reward_amount', 0));
        $type = clean_data($request->input('task_type', 'Telegram'));

        if (empty($name) || empty($link) || $reward <= 0) {
            return back()->with('error', 'Please fill in all task requirements correctly.');
        }

        try {
            Task::updateOrCreate(
                ['id' => $taskId],
                [
                    'name' => $name,
                    'link' => $link,
                    'reward_amount' => $reward,
                    'task_type' => $type
                ]
            );

            $msg = $taskId > 0 ? "Micro task updated successfully!" : "New Micro task published successfully!";
            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Task Saved!',
                'message' => $msg . ' 📝',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.tasks');
        } catch (\Exception $e) {
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }

    public function saveSettings(Request $request)
    {
        $limit = intval($request->input('daily_task_limit', 10));
        $seconds = intval($request->input('task_wait_seconds', 5));

        try {
            update_setting_val('daily_task_limit', $limit);
            update_setting_val('task_wait_seconds', $seconds);

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Missions Configured!',
                'message' => 'Global task limits updated successfully! ⚙️',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.tasks');
        } catch (\Exception $e) {
            return back()->with('error', 'Settings save failed: ' . $e->getMessage());
        }
    }

    public function deleteTask(Request $request)
    {
        $taskId = intval($request->input('task_id', 0));
        try {
            Task::where('id', $taskId)->delete();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Task Deleted!',
                'message' => 'Missions task deleted permanently from database. 🧹',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.tasks');
        } catch (\Exception $e) {
            return back()->with('error', 'Deletion failed: ' . $e->getMessage());
        }
    }
}