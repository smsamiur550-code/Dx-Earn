<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;
use App\Models\Order;
use App\Models\LotteryTicket;
use Illuminate\Support\Facades\DB;

class ShopController extends Controller
{
    public function shopIndex()
    {
        return redirect()->route('admin.settings');
    }

    public function productIndex()
    {
        $categories = Category::orderBy('name', 'asc')->get();
        $products = Product::leftJoin('categories', 'products.category_id', '=', 'categories.id')
            ->select('products.*', 'categories.name as category_name')
            ->orderBy('products.id', 'desc')
            ->get();

        return view('admin.products', compact('categories', 'products'));
    }

    public function addCategory(Request $request)
    {
        $catName = clean_data($request->input('category_name', ''));
        if (!empty($catName)) {
            try {
                Category::create(['name' => $catName]);
                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Category Added!',
                    'message' => "Category '$catName' added successfully! 🏷️",
                    'is_game' => false,
                    'auto_close' => 0
                ]);
            } catch (\Exception $e) {
                return back()->with('error', 'Failed to add category: ' . $e->getMessage());
            }
        }
        return redirect()->route('admin.products');
    }

    public function deleteCategory(Request $request)
    {
        $catId = intval($request->input('category_id', 0));
        try {
            Category::where('id', $catId)->delete();
            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Category Deleted!',
                'message' => 'Category deleted successfully! 🧹',
                'is_game' => false,
                'auto_close' => 0
            ]);
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete category: ' . $e->getMessage());
        }
        return redirect()->route('admin.products');
    }

    public function saveProduct(Request $request)
    {
        $productId = intval($request->input('product_id', 0));
        $name = clean_data($request->input('name', ''));
        $price = floatval($request->input('price', 0));
        $stock = intval($request->input('stock', 0));
        $desc = clean_data($request->input('description', ''));
        $catId = intval($request->input('category_id', 0));
        $compName = clean_data($request->input('company_name', ''));
        
        if ($catId <= 0) $catId = null;
        $country = "Bangladesh";

        if (empty($name) || $price <= 0 || $stock < 0) {
            return back()->with('error', 'Please provide valid product name, price, and stock levels.');
        }

        $imageName = "";
        $logoName = "";
        $targetDir = public_path('uploads/');

        if ($request->hasFile('product_img') && $request->file('product_img')->isValid()) {
            $prodImg = $request->file('product_img');
            $ext = strtolower($prodImg->getClientOriginalExtension());
            if (in_array($ext, ['png', 'jpg', 'jpeg', 'webp'])) {
                $fileStruct = [
                    'tmp_name' => $prodImg->getRealPath(),
                    'mime' => $prodImg->getMimeType()
                ];
                $newFilenameWithoutExt = 'prod_' . time() . '_' . mt_rand(100, 999);
                $imageName = compress_image_to_webp($fileStruct, $targetDir, $newFilenameWithoutExt);
            }
        }

        if ($request->hasFile('company_logo_file') && $request->file('company_logo_file')->isValid()) {
            $logoImg = $request->file('company_logo_file');
            $ext = strtolower($logoImg->getClientOriginalExtension());
            if (in_array($ext, ['png', 'jpg', 'jpeg', 'webp'])) {
                $fileStruct = [
                    'tmp_name' => $logoImg->getRealPath(),
                    'mime' => $logoImg->getMimeType()
                ];
                $newFilenameWithoutExt = 'comp_' . time() . '_' . mt_rand(100, 999);
                $logoName = compress_image_to_webp($fileStruct, $targetDir, $newFilenameWithoutExt);
            }
        }

        DB::beginTransaction();
        try {
            if ($productId > 0) {
                $product = Product::findOrFail($productId);
                $updateData = [
                    'name' => $name,
                    'price' => $price,
                    'stock' => $stock,
                    'description' => $desc,
                    'category_id' => $catId,
                    'country' => $country,
                    'company_name' => $compName
                ];

                if (!empty($imageName)) {
                    if ($product->image && file_exists($targetDir . $product->image)) {
                        @unlink($targetDir . $product->image);
                    }
                    $updateData['image'] = $imageName;
                }

                if (!empty($logoName)) {
                    if ($product->company_logo && file_exists($targetDir . $product->company_logo)) {
                        @unlink($targetDir . $product->company_logo);
                    }
                    $updateData['company_logo'] = $logoName;
                }

                $product->update($updateData);
                $successMsg = "Product parameters saved successfully!";
            } else {
                if (empty($imageName)) {
                    throw new \Exception("Please upload a main product photo.");
                }
                
                Product::create([
                    'name' => $name,
                    'image' => $imageName,
                    'price' => $price,
                    'stock' => $stock,
                    'description' => $desc,
                    'category_id' => $catId,
                    'country' => $country,
                    'company_name' => $compName,
                    'company_logo' => $logoName ?: null
                ]);
                $successMsg = "New product published successfully!";
            }

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Product Saved!',
                'message' => $successMsg . ' 📦',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.products');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Save failed: ' . $e->getMessage());
        }
    }

    public function deleteProduct(Request $request)
    {
        $productId = intval($request->input('product_id', 0));
        $targetDir = public_path('uploads/');
        
        try {
            $product = Product::findOrFail($productId);
            if ($product->image && file_exists($targetDir . $product->image)) {
                @unlink($targetDir . $product->image);
            }
            if ($product->company_logo && file_exists($targetDir . $product->company_logo)) {
                @unlink($targetDir . $product->company_logo);
            }

            $product->delete();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Product Terminated!',
                'message' => "Product deleted permanently from inventory. 🧹",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.products');
        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete product: ' . $e->getMessage());
        }
    }

    public function ordersIndex(Request $request)
    {
        $currentSubTab = clean_data($request->query('sub_tab', 'pending'));

        $orders = Order::join('products', 'orders.product_id', '=', 'products.id')
            ->join('users', 'orders.user_id', '=', 'users.id')
            ->leftJoin('lottery_tickets', 'orders.id', '=', 'lottery_tickets.order_id')
            ->where('orders.status', $currentSubTab)
            ->select('orders.*', 'products.name as product_name', 'products.image as product_image', 'users.username', 'lottery_tickets.ticket_number')
            ->orderBy('orders.id', 'desc')
            ->get();

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('admin.orders', compact('currentSubTab', 'orders', 'takaRate'));
    }

    public function auditOrder(Request $request)
    {
        $orderId = intval($request->input('order_id', 0));
        $newStatus = clean_data($request->input('order_status', ''));
        $currentSubTab = clean_data($request->input('sub_tab', 'pending'));

        $order = Order::find($orderId);
        if (!$order) {
            return back()->with('error', 'Order details not found.');
        }

        DB::beginTransaction();
        try {
            $order->status = $newStatus;
            $order->save();

            if ($newStatus === 'completed') {
                LotteryTicket::where('order_id', $orderId)->update(['status' => 'approved']);
            }

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Order Updated!',
                'message' => "Order ID #$orderId has been successfully marked as " . strtoupper($newStatus) . "! Tickets remain Active/Approved. 🚚",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.orders', ['sub_tab' => $currentSubTab]);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Moderation declined: ' . $e->getMessage());
        }
    }

    public function deleteOrder(Request $request)
    {
        $orderId = intval($request->input('order_id', 0));
        $currentSubTab = clean_data($request->input('sub_tab', 'pending'));

        DB::beginTransaction();
        try {
            Order::where('id', $orderId)->delete();
            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Order Deleted!',
                'message' => "Order reference ID #$orderId deleted permanently from registry. 🧹",
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('admin.orders', ['sub_tab' => $currentSubTab]);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Delete failed: ' . $e->getMessage());
        }
    }
}