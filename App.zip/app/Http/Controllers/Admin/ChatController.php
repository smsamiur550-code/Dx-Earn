<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Chat;
use Illuminate\Support\Facades\DB;

class ChatController extends Controller
{
    public function index()
    {
        return view('admin.chat');
    }

    public function listChats()
    {
        try {
            // Raw MySQL query translation to fetch unique user conversations
            $chats = DB::select("
                SELECT u.id, u.username, u.full_name, u.profile_pic,
                       (SELECT message FROM chat WHERE sender_id = u.id ORDER BY id DESC LIMIT 1) AS last_msg,
                       (SELECT DATE_FORMAT(created_at, '%h:%i %p') FROM chat WHERE sender_id = u.id ORDER BY id DESC LIMIT 1) AS last_time,
                       (SELECT COUNT(*) FROM chat WHERE sender_id = u.id AND is_admin = 0 AND is_seen = 0) AS unread_count
                FROM users u
                WHERE u.id IN (SELECT DISTINCT sender_id FROM chat)
                ORDER BY (SELECT MAX(id) FROM chat WHERE sender_id = u.id) DESC
            ");

            return response()->json(['success' => true, 'chats' => $chats]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function fetchMessages(Request $request)
    {
        $targetUid = intval($request->query('user_id', 0));
        try {
            Chat::where('sender_id', $targetUid)
                ->where('is_admin', 0)
                ->update(['is_seen' => 1]);

            $messages = Chat::where('sender_id', $targetUid)
                ->orderBy('id', 'asc')
                ->get()
                ->map(function ($msg) {
                    return [
                        'id' => $msg->id,
                        'message' => $msg->message,
                        'is_admin' => $msg->is_admin,
                        'is_seen' => $msg->is_seen,
                        'msg_time' => $msg->created_at->format('h:i A')
                    ];
                });

            return response()->json(['success' => true, 'messages' => $messages]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function sendMessage(Request $request)
    {
        $targetUid = intval($request->input('user_id', 0));
        $message = clean_data($request->input('message', ''));

        if ($targetUid <= 0 || empty($message)) {
            return response()->json(['success' => false, 'message' => 'Invalid parameters.']);
        }

        try {
            Chat::create([
                'sender_id' => $targetUid,
                'message' => $message,
                'is_admin' => 1,
                'is_seen' => 0,
                'created_at' => now()
            ]);

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            return response()->json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
}