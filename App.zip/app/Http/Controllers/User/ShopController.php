<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;
use App\Models\Order;
use App\Models\LotteryTicket;
use Illuminate\Support\Facades\DB;

class ShopController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $countries = [
            "Austria", "Azerbaijan", "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Argentina", "Armenia", "Australia", "Bangladesh",
            "Bahamas", "Bahrain", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bhutan", "Bolivia", "Brazil", "Brunei", "Bulgaria",
            "Cambodia", "Cameroon", "Canada", "Chad", "Chile", "China", "Colombia", "Comoros", "Congo", "Costa Rica", "Croatia", "Cuba", "Cyprus",
            "Denmark", "Djibouti", "Dominica", "Ecuador", "Egypt", "Estonia", "Ethiopia", "Fiji", "Finland", "France", "Gabon", "Gambia", "Germany",
            "Haiti", "Honduras", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Italy", "Ivory Coast",
            "Japan", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia",
            "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Mexico", "Monaco", "Mongolia", "Morocco", "Mozambique", "Myanmar",
            "Namibia", "Nepal", "Netherlands", "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Korea", "Norway", "Oman", "Pakistan",
            "Qatar", "Romania", "Russia", "Rwanda", "Samoa", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Singapore", "Slovakia",
            "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Togo", "Tonga", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu", "Uganda", "Ukraine",
            "United Arab Emirates", "United Kingdom", "United States", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Yemen", "Zambia"
        ];

        $userCountry = $user->shop_country ?: session('shop_country', '');
        $showCountryModal = empty($userCountry) || request()->has('change_country');
        $isRestricted = (!empty($userCountry) && strtolower($userCountry) !== 'bangladesh' && !$showCountryModal);

        $categories = Category::orderBy('name', 'asc')->get();
        $products = Product::where('stock', '>', 0)->orderBy('id', 'desc')->limit(40)->get();

        $sliderImages = [];
        $slideDir = public_path('uploads/shop_slides/');
        if (file_exists($slideDir)) {
            $files = @scandir($slideDir);
            if ($files) {
                foreach ($files as $file) {
                    if (in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)), ['png', 'jpg', 'jpeg', 'webp'])) {
                        $sliderImages[] = asset('uploads/shop_slides/' . $file);
                    }
                }
            }
        }

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('user.shop', compact('user', 'countries', 'userCountry', 'showCountryModal', 'isRestricted', 'categories', 'products', 'sliderImages', 'takaRate'));
    }

    public function saveCountry(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $selectedCountry = clean_data($request->input('selected_country', 'Bangladesh'));
        $user->update(['shop_country' => $selectedCountry]);
        session(['shop_country' => $selectedCountry]);

        return redirect()->route('shop');
    }

    public function viewProduct($id)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $product = Product::findOrFail($id);

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);
        $tokenPerTaka = floatval(get_setting_val('token_per_currency_bangladesh') ?: 4.0);

        $deliveryInside = floatval(get_setting_val('delivery_inside_dhaka') ?: 60.00);
        $deliveryOutside = floatval(get_setting_val('delivery_outside_dhaka') ?: 120.00);

        $allow20 = (get_setting_val('shop_allow_discount_20') !== '0');
        $allow30 = (get_setting_val('shop_allow_discount_30') !== '0');
        $allow40 = (get_setting_val('shop_allow_discount_40') !== '0');

        $productPriceBdt = $product->price * $takaRate;

        $relatedProducts = Product::where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)
            ->where('stock', '>', 0)
            ->orderByRaw('RAND()')
            ->limit(4)
            ->get();

        return view('user.view', compact(
            'user', 'product', 'takaRate', 'tokenPerTaka', 'deliveryInside', 
            'deliveryOutside', 'allow20', 'allow30', 'allow40', 
            'productPriceBdt', 'relatedProducts'
        ));
    }

    public function checkout(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $pid = intval($request->input('product_id', 0));
        $product = Product::findOrFail($pid);

        $name = clean_data($request->input('name', ''));
        $phone = clean_data($request->input('phone', ''));
        $address = clean_data($request->input('address', ''));
        $deliveryLoc = clean_data($request->input('delivery_loc', 'inside'));
        $discountPercent = intval($request->input('discount_percent', 20));

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);
        $tokenPerTaka = floatval(get_setting_val('token_per_currency_bangladesh') ?: 4.0);

        $deliveryInside = floatval(get_setting_val('delivery_inside_dhaka') ?: 60.00);
        $deliveryOutside = floatval(get_setting_val('delivery_outside_dhaka') ?: 120.00);

        $shippingFee = ($deliveryLoc === 'inside') ? $deliveryInside : $deliveryOutside;
        $productPriceBdt = $product->price * $takaRate;

        $discountRatio = $discountPercent / 100;
        $discountBdt = $productPriceBdt * $discountRatio;
        $requiredTokens = $discountBdt * $tokenPerTaka;
        $codDueBdt = ($productPriceBdt - $discountBdt) + $shippingFee;

        if (empty($name) || empty($phone) || empty($address)) {
            return back()->with('error', 'Please fill in all recipient delivery details.');
        }

        if ($product->stock <= 0) {
            return back()->with('error', 'This product is currently out of stock.');
        }

        if ($user->balance_token < $requiredTokens) {
            return back()->with('error', "Insufficient DX Tokens. You need " . number_format($requiredTokens, 2) . " Tokens to claim the " . $discountPercent . "% discount.");
        }

        DB::beginTransaction();
        try {
            update_balance($userId, $requiredTokens, 'token', 'deduct');

            $product->decrement('stock');

            $order = Order::create([
                'user_id' => $userId,
                'product_id' => $pid,
                'name' => $name,
                'phone' => $phone,
                'address' => $address,
                'total_price' => $product->price,
                'coin_deducted' => $requiredTokens,
                'coin_percentage' => $discountPercent,
                'discount_cash' => $discountBdt / $takaRate,
                'delivery_charge' => $shippingFee / $takaRate,
                'delivery_location' => ($deliveryLoc === 'inside' ? 'Inside Dhaka' : 'Outside Dhaka'),
                'cod_amount' => $codDueBdt / $takaRate,
                'status' => 'pending',
                'created_at' => now()
            ]);

            $ticketNumber = 'DXTKT-' . strtoupper(substr(bin2hex(random_bytes(6)), 0, 8));
            
            LotteryTicket::create([
                'user_id' => $userId,
                'order_id' => $order->id,
                'ticket_number' => $ticketNumber,
                'status' => 'approved',
                'prize_amount' => 0.00,
                'created_at' => now()
            ]);

            log_transaction($userId, 'purchase', 'debit', 'token', $requiredTokens, "Directly purchased product ID: " . $pid);

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Order Placed!',
                'message' => 'Your checkout is complete! You claimed a ' . $discountPercent . '% discount using ' . number_format($requiredTokens, 2) . ' Tokens. Standard Cash On Delivery (COD) of ' . number_format($codDueBdt, 2) . ' ৳ is due upon arrival. 🚚',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('shop.orders');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Order placement failed: ' . $e->getMessage());
        }
    }

    public function showOrders()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        $orders = Order::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->limit(50)
            ->get();

        return view('user.order', compact('user', 'takaRate', 'orders'));
    }
}