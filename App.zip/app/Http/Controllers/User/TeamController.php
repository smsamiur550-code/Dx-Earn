<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Referral;

class TeamController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        if ($user->kyc_status === 'approved') {
            try {
                trigger_referral_payout($userId);
            } catch (\Exception $e) {
                \Log::error($e->getMessage());
            }
        }

        try {
            $pendingApprovedReferees = Referral::join('users', 'referrals.referee_id', '=', 'users.id')
                ->where('referrals.referrer_id', $userId)
                ->where('referrals.status', 'pending')
                ->where('users.kyc_status', 'approved')
                ->pluck('referrals.referee_id')
                ->toArray();

            if (!empty($pendingApprovedReferees)) {
                foreach ($pendingApprovedReferees as $refId) {
                    trigger_referral_payout($refId);
                }
                $user = User::findOrFail($userId);
            }
        } catch (\Exception $e) {
            \Log::error($e->getMessage());
        }

        $referrals = Referral::join('users', 'referrals.referee_id', '=', 'users.id')
            ->where('referrals.referrer_id', $userId)
            ->select('referrals.*', 'users.username', 'users.full_name', 'users.kyc_status', 'users.profile_pic')
            ->orderBy('referrals.id', 'desc')
            ->get();

        $tgRefLink = "https://t.me/" . (get_setting_val('bot_username') ?: 'dxearn_bot') . "/app?startapp=" . urlencode($user->referral_code);
        $webRefLink = route('login') . "?ref=" . urlencode($user->referral_code);

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('user.reffer', compact('user', 'referrals', 'tgRefLink', 'webRefLink', 'takaRate'));
    }
}