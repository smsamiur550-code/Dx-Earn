<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Kyc;
use App\Models\Notification;
use App\Models\Chat;
use App\Models\Setting;
use Illuminate\Support\Facades\DB;

class ProfileController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $hasUnreadNotifications = Notification::where('user_id', $userId)->where('status', 'unread')->exists();
        $hasUnreadChats = Chat::where('sender_id', $userId)->where('is_admin', 1)->where('is_seen', 0)->exists();

        $liveMarketLink = get_setting_val('live_market_link') ?: "https://s.tradingview.com/widgetembed/?frameElementId=tradingview_chart&symbol=BINANCE%3ABTCUSDT&interval=D&hidesidetoolbar=1&symboledit=0&saveimage=0&toolbarbg=ffffff&studies=%5B%5D&theme=light&style=1&timezone=Etc%2FUTC&studies_overrides=%7B%7D&overrides=%7B%7D&enabled_features=%5B%5D&disabled_features=%5B%5D&locale=en&utm_source=localhost&utm_medium=widget&utm_campaign=chart&utm_term=BINANCE%3ABTCUSDT";

        $sliders = DB::table('homepage_sliders')->orderBy('id', 'desc')->limit(5)->get();
        if ($sliders->isEmpty()) {
            $sliders = collect([
                (object)[
                    'grad' => 'from-blue-600 via-indigo-650 to-purple-700',
                    'title' => '🚀 DX EARN CLOUD MINING',
                    'desc' => 'Activate your virtual hashing node now and mint coins daily!',
                    'redirect_url' => route('mining'),
                    'image_path' => null
                ],
                (object)[
                    'grad' => 'from-emerald-500 via-teal-600 to-emerald-700',
                    'title' => '⚡ TURBO CHARGE SPEED',
                    'desc' => 'Unlock premium VIP Cards to multiply mining clock speeds instantly.',
                    'redirect_url' => route('vip'),
                    'image_path' => null
                ],
                (object)[
                    'grad' => 'from-rose-500 via-pink-650 to-rose-700',
                    'title' => '🎁 CLAIM HOURLY BONUSES',
                    'desc' => 'Visit our Bonus Center daily to claim up to 10,000 DX Coins.',
                    'redirect_url' => route('reward'),
                    'image_path' => null
                ]
            ]);
        }

        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('index', compact('user', 'hasUnreadNotifications', 'hasUnreadChats', 'liveMarketLink', 'sliders', 'takaRate'));
    }

    public function showProfile()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('profile', compact('user', 'takaRate'));
    }

    public function showSettings(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $activeTab = clean_data($request->query('tab', 'profile'));

        return view('user.settings', compact('user', 'activeTab'));
    }

    public function updateProfile(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $fullName = clean_data($request->input('full_name', ''));
        $email = clean_data($request->input('email', ''));

        if ($user->profile_edited == 1) {
            return back()->with('error', 'Your profile settings are locked and cannot be changed further.');
        }

        if (empty($fullName) || empty($email)) {
            return back()->with('error', 'Full Name and Email fields are required.');
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return back()->with('error', 'Please enter a valid email address.');
        }

        $emailExists = User::where('email', $email)->where('id', '!=', $userId)->exists();
        if ($emailExists) {
            return back()->with('error', 'This email address is already associated with another active account.');
        }

        $user->update([
            'full_name' => $fullName,
            'email' => $email,
            'profile_edited' => 1
        ]);

        session()->flash('popup_data', [
            'type' => 'success',
            'title' => 'Profile Locked!',
            'message' => 'Your legal details have been verified and locked successfully. 🎉',
            'is_game' => false,
            'auto_close' => 0
        ]);

        return redirect()->route('settings', ['tab' => 'profile']);
    }

    public function submitKyc(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $fullName = clean_data($request->input('full_name', ''));
        $nidNumber = clean_data($request->input('nid_number', ''));
        $dob = clean_data($request->input('dob', ''));

        if (empty($fullName) || empty($nidNumber) || empty($dob)) {
            return back()->with('error', 'Please fill in all KYC verification details.');
        }

        $kycImages = ['front_img', 'back_img', 'selfie_img'];
        foreach ($kycImages as $img) {
            if (!$request->hasFile($img) || !$request->file($img)->isValid()) {
                return back()->with('error', "The " . str_replace('_', ' ', $img) . " file is missing or invalid.");
            }
        }

        $nidExists = Kyc::where('nid_number', $nidNumber)->where('user_id', '!=', $userId)->where('status', '!=', 'rejected')->exists();
        if ($nidExists) {
            return back()->with('error', 'This ID number is already associated with another active account.');
        }

        DB::beginTransaction();
        try {
            $frontFile = $request->file('front_img');
            $backFile = $request->file('back_img');
            $selfieFile = $request->file('selfie_img');

            $targetDir = public_path('uploads/kyc_docs/');
            
            $frontName = compress_image_to_webp([
                'tmp_name' => $frontFile->getRealPath(),
                'mime' => $frontFile->getMimeType()
            ], $targetDir, 'kyc_' . $userId . '_front_' . bin2hex(random_bytes(8)) . '_' . time());

            $backName = compress_image_to_webp([
                'tmp_name' => $backFile->getRealPath(),
                'mime' => $backFile->getMimeType()
            ], $targetDir, 'kyc_' . $userId . '_back_' . bin2hex(random_bytes(8)) . '_' . time());

            $selfieName = compress_image_to_webp([
                'tmp_name' => $selfieFile->getRealPath(),
                'mime' => $selfieFile->getMimeType()
            ], $targetDir, 'kyc_' . $userId . '_selfie_' . bin2hex(random_bytes(8)) . '_' . time());

            if (!$frontName || !$backName || !$selfieName) {
                throw new \Exception("Document processing failed. Please ensure file types are supported.");
            }

            Kyc::updateOrCreate(
                ['user_id' => $userId],
                [
                    'nid_number' => $nidNumber,
                    'full_name' => $fullName,
                    'dob' => $dob,
                    'front_img' => $frontName,
                    'back_img' => $backName,
                    'selfie_img' => $selfieName,
                    'status' => 'pending',
                    'submitted_at' => now()
                ]
            );

            $user->update([
                'kyc_status' => 'pending',
                'kyc_submitted_at' => now()
            ]);

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'KYC Submitted!',
                'message' => 'Your identity documents have been submitted for review. 🎉',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('settings', ['tab' => 'kyc']);
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Submission failed: ' . $e->getMessage());
        }
    }

    public function showPrivacy()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        return view('user.privacy', compact('user'));
    }

    public function leaderboard()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        // Fetch top 50 users based on balance_coin (score)
        $rankings = User::where('is_banned', 0)
            ->orderBy('balance_coin', 'desc')
            ->limit(50)
            ->get()
            ->map(function ($u) {
                $u->score = $u->balance_coin;
                return $u;
            });

        return view('user.leaderboard', compact('user', 'takaRate', 'rankings'));
    }
}