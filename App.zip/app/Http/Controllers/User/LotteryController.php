<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\LotteryTicket;
use Illuminate\Support\Facades\DB;

class LotteryController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $lastDrawTime = get_setting_val('last_lottery_draw_time');
        if (!empty($lastDrawTime)) {
            $drawTimestamp = strtotime($lastDrawTime);
            if ((time() - $drawTimestamp) >= 86400) {
                LotteryTicket::where('user_id', $userId)
                    ->where('status', '!=', 'winner')
                    ->delete();
            }
        }

        $nextDrawTimestamp = strtotime(get_setting_val('next_lottery_draw_time') ?: 'next Sunday 20:00:00');
        $secondsRemaining = max(0, $nextDrawTimestamp - time());

        $myTickets = LotteryTicket::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->get();

        $weeklyWinners = LotteryTicket::join('users', 'lottery_tickets.user_id', '=', 'users.id')
            ->where('lottery_tickets.status', 'winner')
            ->where('lottery_tickets.created_at', '>=', now()->subDays(7))
            ->select('lottery_tickets.*', 'users.username', 'users.full_name', 'users.profile_pic')
            ->orderBy('lottery_tickets.id', 'desc')
            ->get();

        $topHolders = LotteryTicket::join('users', 'lottery_tickets.user_id', '=', 'users.id')
            ->select('users.username', 'users.full_name', 'users.profile_pic', DB::raw('COUNT(lottery_tickets.id) as ticket_count'))
            ->groupBy('lottery_tickets.user_id', 'users.username', 'users.full_name', 'users.profile_pic')
            ->orderBy('ticket_count', 'desc')
            ->limit(50)
            ->get();

        $prizeAmount = floatval(get_setting_val('lottery_prize_1_amount') ?: 100000.00);

        return view('user.lottery', compact('user', 'secondsRemaining', 'myTickets', 'weeklyWinners', 'topHolders', 'prizeAmount'));
    }
}