<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Chat;

class SupportController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $telegramChannel = get_setting_val('telegram_channel_link') ?: 'https://t.me/dxearn_channel';
        $telegramGroup   = get_setting_val('telegram_group_link') ?: 'https://t.me/dxearn_group';
        $whatsappGroup   = get_setting_val('whatsapp_group_link') ?: 'https://wa.me/your_number';
        $youtubeSupport  = get_setting_val('youtube_support_link') ?: 'https://youtube.com';

        $faqsRaw = get_setting_val('system_faqs');
        $systemFaqs = $faqsRaw ? json_decode($faqsRaw, true) : [];

        if (!is_array($systemFaqs) || empty($systemFaqs)) {
            $systemFaqs = [
                [
                    'q' => 'How does the mining system operate?',
                    'a' => 'Simply head over to the Mining section and click "Start Mining". Your node will start hashing coins immediately until your storage capacity becomes full.'
                ],
                [
                    'q' => 'How can I complete identity verification?',
                    'a' => 'Go to Profile > Identity Verification. Fill in your legal full name, date of birth, and ID number, then upload clear photos of your document front, back, and a live capture selfie. Approval is automated in 10 minutes!'
                ],
                [
                    'q' => 'What is the utility token exchange rate?',
                    'a' => 'Your earned DX mining coins can be converted into DX Utility Tokens at a base conversion rate. These tokens can then be utilized to buy permanent booster items or convert into USD.'
                ],
                [
                    'q' => 'How does the 1-Level referral bonus system work?',
                    'a' => 'Share your custom invite link with friends. When they sign up and successfully complete their KYC verification, the referral bonus is instantly approved and credited!'
                ]
            ];
        }

        return view('user.support', compact('user', 'telegramChannel', 'telegramGroup', 'whatsappGroup', 'youtubeSupport', 'systemFaqs'));
    }

    public function showChat()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        return view('user.chat', compact('user'));
    }

    public function fetchMessages()
    {
        $userId = session('user_id');

        try {
            Chat::where('sender_id', $userId)
                ->where('is_admin', 1)
                ->where('is_seen', 0)
                ->update(['is_seen' => 1]);

            $messages = Chat::where('sender_id', $userId)
                ->orderBy('id', 'asc')
                ->get()
                ->map(function ($msg) {
                    return [
                        'id' => $msg->id,
                        'message' => $msg->message,
                        'is_admin' => $msg->is_admin,
                        'is_seen' => $msg->is_seen,
                        'msg_time' => $msg->created_at->format('h:i A')
                    ];
                });

            return response()->json(['status' => 'success', 'messages' => $messages]);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function sendMessage(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $messageText = clean_data($request->input('message', ''));

        if (empty($messageText)) {
            return response()->json(['status' => 'error', 'message' => 'Empty Message']);
        }

        try {
            Chat::create([
                'sender_id' => $userId,
                'message' => $messageText,
                'is_admin' => 0,
                'is_seen' => 0,
                'created_at' => now()
            ]);

            $botToken = get_setting_val('bot_token');
            $adminTgId = get_setting_val('admin_telegram_id');
            if ($botToken && $adminTgId) {
                $alertMsg = "💬 <b>New Chat Message!</b>\n\n" .
                             "From: @{$user->username} (ID: {$userId})\n" .
                             "Message: <i>" . htmlspecialchars($messageText) . "</i>";
                send_telegram_notification($adminTgId, $alertMsg, $botToken);
            }

            return response()->json(['status' => 'success']);
        } catch (\Exception $e) {
            return response()->json(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }
}