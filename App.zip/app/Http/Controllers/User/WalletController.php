<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Transaction;
use App\Models\PaymentRequest;
use App\Models\Conversion;
use App\Models\Withdrawal;

class WalletController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        $transactions = Transaction::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->limit(15)
            ->get();

        return view('user.wallet', compact('user', 'takaRate', 'transactions'));
    }

    public function showConvert()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $coinName = get_setting_val('coin_name') ?: 'DX Coin';
        $tokenName = get_setting_val('token_name') ?: 'DX Token';

        $rateCoinToToken = floatval(get_setting_val('coin_to_token_rate') ?: 0.1000);
        $minConvert = floatval(get_setting_val('min_convert') ?: 100.00);
        $maxConvert = floatval(get_setting_val('max_convert') ?: 10000.00);
        $convertFeePercent = floatval(get_setting_val('convert_fee') ?: 1.50);
        $rateTokenToDollar = floatval(get_setting_val('token_to_dollar_rate') ?: 0.25);
        $tokenToDollarEnabled = (get_setting_val('token_to_dollar_enabled') === '1');
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('user.convert', compact(
            'user', 'coinName', 'tokenName', 'rateCoinToToken', 'minConvert', 
            'maxConvert', 'convertFeePercent', 'rateTokenToDollar', 
            'tokenToDollarEnabled', 'takaRate'
        ));
    }

    public function coinToToken(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $amountCoin = floatval($request->input('amount_coin', 0));
        $convertFeePercent = floatval(get_setting_val('convert_fee') ?: 1.50);
        $feeAmount = ($amountCoin * $convertFeePercent) / 100;
        $netAmountCoin = $amountCoin - $feeAmount;
        
        $rateCoinToToken = floatval(get_setting_val('coin_to_token_rate') ?: 0.1000);
        $tokensCredited = $netAmountCoin * $rateCoinToToken;

        $minConvert = floatval(get_setting_val('min_convert') ?: 100.00);
        $maxConvert = floatval(get_setting_val('max_convert') ?: 10000.00);
        $coinName = get_setting_val('coin_name') ?: 'DX Coin';

        if ($amountCoin < $minConvert || $amountCoin > $maxConvert) {
            return back()->with('error', "Amount must be between 🪙 " . number_format($minConvert, 2) . " and 🪙 " . number_format($maxConvert, 2) . " " . $coinName);
        }

        if ($user->balance_coin < $amountCoin) {
            return back()->with('error', "Insufficient 🪙 " . $coinName . " balance for this conversion.");
        }

        return redirect()->route('payment', [
            'type' => 'coin_to_token',
            'amount' => $amountCoin,
            'fee' => $feeAmount,
            'tokens' => $tokensCredited
        ]);
    }

    public function tokenToDollar(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $tokenToDollarEnabled = (get_setting_val('token_to_dollar_enabled') === '1');
        if (!$tokenToDollarEnabled) {
            return back()->with('error', 'Token to Dollar Conversion is currently locked by admin.');
        }

        $amountToken = floatval($request->input('amount_token', 0));
        $rateTokenToDollar = floatval(get_setting_val('token_to_dollar_rate') ?: 0.25);
        $dollarsCredited = $amountToken * $rateTokenToDollar;
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        if ($amountToken <= 0) {
            return back()->with('error', 'Please enter a valid amount of tokens to convert.');
        }

        if ($user->balance_token < $amountToken) {
            return back()->with('error', 'Insufficient Token Balance.');
        }

        \DB::beginTransaction();
        try {
            update_balance($userId, $amountToken, 'token', 'deduct');
            update_balance($userId, $dollarsCredited, 'usd', 'add');

            Conversion::create([
                'user_id' => $userId,
                'amount_from' => $amountToken,
                'amount_to' => $dollarsCredited,
                'type' => 'token_to_dollar',
                'status' => 'completed',
                'rate' => $rateTokenToDollar,
                'created_at' => now()
            ]);

            log_transaction($userId, 'income', 'credit', 'usd', $dollarsCredited, "Converted " . number_format($amountToken, 2) . " Tokens to BDT");

            \DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Conversion Complete!',
                'message' => 'Successfully converted ' . number_format($amountToken, 2) . ' Tokens to ' . number_format($dollarsCredited * $takaRate, 2) . ' ৳! 🎉',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('convert');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->with('error', 'Conversion failed: ' . $e->getMessage());
        }
    }

    public function showPayment(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $paymentWalletUsdt = get_setting_val('admin_wallet_usdt') ?: "T9yD14Nj9j7xAB4dbGeiX9h8unkKHxuWwb (TRC20)";
        $paymentWalletBinance = get_setting_val('admin_wallet_binance') ?: "528906322 (Binance Pay ID)";
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        $type = clean_data($request->query('type', ''));
        $amount = floatval($request->query('amount', 0));
        $fee = floatval($request->query('fee', 0));
        $tokens = floatval($request->query('tokens', 0));

        if (empty($type) || $amount <= 0) {
            return redirect()->route('convert');
        }

        return view('user.payment', compact('user', 'paymentWalletUsdt', 'paymentWalletBinance', 'takaRate', 'type', 'amount', 'fee', 'tokens'));
    }

    public function submitProof(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $type = clean_data($request->input('type', ''));
        $amount = floatval($request->input('amount', 0));
        $fee = floatval($request->input('fee', 0));
        $tokens = floatval($request->input('tokens', 0));

        if (empty($type) || $amount <= 0) {
            return redirect()->route('convert');
        }

        if (!$request->hasFile('screenshot') || !$request->file('screenshot')->isValid()) {
            return back()->with('error', 'Please upload a valid payment proof screenshot of the conversion fee.');
        }

        $screenshot = $request->file('screenshot');
        $ext = strtolower($screenshot->getClientOriginalExtension());

        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            return back()->with('error', 'Unsupported image format. Upload JPG, PNG, or WEBP only.');
        }

        if ($screenshot->getSize() > 5 * 1024 * 1024) {
            return back()->with('error', 'File size must be under 5MB.');
        }

        $targetDir = public_path('uploads/payments/');
        $newFilenameWithoutExt = 'pay_' . $userId . '_' . time() . '_' . mt_rand(100, 999);
        
        $fileStruct = [
            'tmp_name' => $screenshot->getRealPath(),
            'mime' => $screenshot->getMimeType()
        ];

        $newFilename = compress_image_to_webp($fileStruct, $targetDir, $newFilenameWithoutExt);

        if ($newFilename) {
            \DB::beginTransaction();
            try {
                update_balance($userId, $amount, 'coin', 'deduct');

                $metaArray = [
                    'tokens' => $tokens,
                    'amount_coin' => $amount,
                    'description' => "Convert 🪙 " . number_format($amount, 2) . " Coins to 💵 " . number_format($tokens, 2) . " Tokens"
                ];

                PaymentRequest::create([
                    'user_id' => $userId,
                    'payment_type' => 'coin_to_token',
                    'amount' => 1.00,
                    'screenshot_pic' => $newFilename,
                    'meta_data' => json_encode($metaArray),
                    'status' => 'pending',
                    'created_at' => now()
                ]);

                \DB::commit();

                session()->flash('popup_data', [
                    'type' => 'success',
                    'title' => 'Proof Submitted!',
                    'message' => 'Your conversion fee payment proof has been uploaded. Admin will credit tokens upon review! 🔄',
                    'is_game' => false,
                    'auto_close' => 0
                ]);

                return redirect()->route('convert');
            } catch (\Exception $e) {
                \DB::rollBack();
                return back()->with('error', 'Transaction failed: ' . $e->getMessage());
            }
        } else {
            return back()->with('error', 'Failed to save screenshot image.');
        }
    }

    public function history()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        $withdrawals_ledger = Withdrawal::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->limit(50)
            ->get();

        $conversions_ledger = Conversion::where('user_id', $userId)
            ->orderBy('id', 'desc')
            ->limit(50)
            ->get();

        return view('user.history', compact('user', 'takaRate', 'withdrawals_ledger', 'conversions_ledger'));
    }
}