<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Withdrawal;

class WithdrawController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $minWithdraw = floatval(get_setting_val('min_withdraw') ?: 5.00);
        $isKycApproved = ($user->kyc_status === 'approved');
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        $diamondPackagesRaw = get_setting_val('diamond_packages');
        $diamondPackages = $diamondPackagesRaw ? json_decode($diamondPackagesRaw, true) : [];
        if (empty($diamondPackages)) {
            $diamondPackages = [
                ['id' => 1, 'diamonds' => 100, 'price' => 1.00],
                ['id' => 2, 'diamonds' => 310, 'price' => 3.00],
                ['id' => 3, 'diamonds' => 520, 'price' => 5.00],
                ['id' => 4, 'diamonds' => 1060, 'price' => 10.00]
            ];
        }

        return view('user.withdraw', compact('user', 'minWithdraw', 'isKycApproved', 'takaRate', 'diamondPackages'));
    }

    public function requestWithdraw(Request $request)
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        if ($user->kyc_status !== 'approved') {
            return back()->with('error', '🚨 Withdraw Blocked: KYC Identity Verification is required to withdraw funds.');
        }

        $paymentMethod = clean_data($request->input('payment_method', ''));
        $accountNumber = clean_data($request->input('account_number', ''));
        $withdrawType = clean_data($request->input('withdraw_type', 'main_usd'));
        $ffPackageId = intval($request->input('ff_package_id', 0));
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);
        $minWithdraw = floatval(get_setting_val('min_withdraw') ?: 5.00);
        $amountUsd = 0;

        $diamondPackagesRaw = get_setting_val('diamond_packages');
        $diamondPackages = $diamondPackagesRaw ? json_decode($diamondPackagesRaw, true) : [];
        if (empty($diamondPackages)) {
            $diamondPackages = [
                ['id' => 1, 'diamonds' => 100, 'price' => 1.00],
                ['id' => 2, 'diamonds' => 310, 'price' => 3.00],
                ['id' => 3, 'diamonds' => 520, 'price' => 5.00],
                ['id' => 4, 'diamonds' => 1060, 'price' => 10.00]
            ];
        }

        if ($paymentMethod === 'Free Fire Diamond Topup 🎮') {
            $selectedPack = null;
            foreach ($diamondPackages as $pack) {
                if ($pack['id'] === $ffPackageId) {
                    $selectedPack = $pack;
                    break;
                }
            }
            if ($selectedPack) {
                $amountUsd = floatval($selectedPack['price']);
                $accountNumber = "Player UID: " . $accountNumber . " (" . $selectedPack['diamonds'] . " Diamonds)";
            } else {
                return back()->with('error', 'Invalid Free Fire Diamond package selected.');
            }
        } else {
            $amountBdt = floatval($request->input('amount_bdt', 0));
            $amountUsd = $amountBdt / $takaRate;
        }

        $availableBalanceUsd = ($withdrawType === 'referral_usd') ? floatval($user->balance_referral_dollar) : floatval($user->balance_dollar);

        if (empty($paymentMethod) || empty($accountNumber)) {
            return back()->with('error', 'Please fill in all withdrawal details.');
        }

        if ($amountUsd < $minWithdraw && $paymentMethod !== 'Free Fire Diamond Topup 🎮') {
            return back()->with('error', 'The minimum allowable cashout limit is ' . number_format($minWithdraw * $takaRate, 2) . ' ৳ (' . format_dollar($minWithdraw) . ' USD)');
        }

        if ($availableBalanceUsd < $amountUsd) {
            return back()->with('error', 'Insufficient wallet balance.');
        }

        \DB::beginTransaction();
        try {
            $currencyKey = ($withdrawType === 'referral_usd') ? 'referral_dollar' : 'usd';
            update_balance($userId, $amountUsd, $currencyKey, 'deduct');

            $ticketNumber = generate_withdraw_ticket();

            Withdrawal::create([
                'user_id' => $userId,
                'amount' => $amountUsd,
                'payment_method' => $paymentMethod,
                'account_number' => $accountNumber,
                'status' => 'pending',
                'withdrawal_type' => $withdrawType,
                'ticket_number' => $ticketNumber,
                'requested_at' => now()
            ]);

            log_transaction($userId, 'withdraw', 'debit', 'usd', $amountUsd, "Withdraw requested via " . $paymentMethod);

            \DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Withdrawal Requested!',
                'message' => 'Your withdrawal request of ' . number_format($amountUsd * $takaRate, 2) . ' ৳ has been submitted. Ticket: #' . $ticketNumber . ' 💸',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('withdraw');
        } catch (\Exception $e) {
            \DB::rollBack();
            return back()->with('error', 'Withdrawal failed: ' . $e->getMessage());
        }
    }

    public function liveFeed()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);
        $takaRate = floatval(get_setting_val('usd_to_bdt_rate') ?: 120.00);

        return view('user.withdraw2', compact('user', 'takaRate'));
    }
}