<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\DailyReward;
use App\Models\VipPlan;
use App\Models\UserVip;
use App\Models\GiftCode;
use App\Models\UserGiftClaim;
use App\Models\Task;
use App\Models\UserTask;
use App\Models\Mining;
use Illuminate\Support\Facades\DB;
use Exception;

class RewardController extends Controller
{
    // --- DAILY REWARD STREAK ---
    public function showReward()
    {
        $userId = session('user_id');
        $user = User::find($userId);

        $rewardsData = DailyReward::firstOrCreate(
            ['user_id' => $userId],
            [
                'streak' => 0,
                'last_claim_date' => null,
                'total_claimed' => 0,
                'cycle_start' => now()->toDateString(),
                'streak_mask' => '0000000'
            ]
        );

        $dayPayouts = [
            1 => floatval(get_setting_val('daily_reward_day_1') ?: 150.00),
            2 => floatval(get_setting_val('daily_reward_day_2') ?: 250.00),
            3 => floatval(get_setting_val('daily_reward_day_3') ?: 400.00),
            4 => floatval(get_setting_val('daily_reward_day_4') ?: 600.00),
            5 => floatval(get_setting_val('daily_reward_day_5') ?: 850.00), // Raw PHP $pdo helper fixed
            6 => floatval(get_setting_val('daily_reward_day_6') ?: 1200.00),
            7 => floatval(get_setting_val('daily_reward_day_7') ?: 2000.00)
        ];

        $today = date('Y-m-d');
        $cycleStart = $rewardsData ? $rewardsData->cycle_start->format('Y-m-d') : $today;
        $streakMask = $rewardsData->streak_mask ?? '0000000';

        $daysDiff = floor((strtotime($today) - strtotime($cycleStart)) / 86400);
        if ($daysDiff >= 7 || $daysDiff < 0) {
            $cycleStart = $today;
            $streakMask = '0000000';
            $rewardsData->update([
                'cycle_start' => $today,
                'streak_mask' => '0000000'
            ]);
            $daysDiff = 0;
        }

        $currentDayOfCycle = intval($daysDiff) + 1;
        $isClaimedToday = (substr($streakMask, $currentDayOfCycle - 1, 1) === '1');

        $vip = get_vip_multipliers($userId);
        $multiplier = $vip['is_vip'] ? 2.0 : 1.0;

        $claimableAmount = $dayPayouts[$currentDayOfCycle] * $multiplier;

        $secondsRemaining = 0;
        if ($isClaimedToday) {
            $midnight = strtotime('tomorrow Midnight');
            $secondsRemaining = max(0, $midnight - time());
        }

        return view('user.reward', compact(
            'user', 'rewardsData', 'dayPayouts', 'streakMask', 
            'currentDayOfCycle', 'isClaimedToday', 'multiplier', 
            'claimableAmount', 'secondsRemaining'
        ));
    }

    public function claimDailyReward(Request $request)
    {
        $userId = session('user_id');
        $rewardsData = DailyReward::where('user_id', $userId)->firstOrFail();

        $today = date('Y-m-d');
        $streakMask = $rewardsData->streak_mask ?? '0000000';
        $cycleStart = $rewardsData->cycle_start ? $rewardsData->cycle_start->format('Y-m-d') : $today;
        
        $daysDiff = floor((strtotime($today) - strtotime($cycleStart)) / 86400);
        $currentDayOfCycle = intval($daysDiff) + 1;
        $isClaimedToday = (substr($streakMask, $current_day_of_cycle - 1, 1) === '1');

        if ($isClaimedToday) {
            return redirect()->back()->with('error', "You have already claimed today's reward! Return tomorrow.");
        }

        $vip = get_vip_multipliers($userId);
        $multiplier = $vip['is_vip'] ? 2.0 : 1.0;

        $dayPayouts = [
            1 => floatval(get_setting_val('daily_reward_day_1') ?: 150.00),
            2 => floatval(get_setting_val('daily_reward_day_2') ?: 250.00),
            3 => floatval(get_setting_val('daily_reward_day_3') ?: 400.00),
            4 => floatval(get_setting_val('daily_reward_day_4') ?: 600.00),
            5 => floatval(get_setting_val('daily_reward_day_5') ?: 850.00),
            6 => floatval(get_setting_val('daily_reward_day_6') ?: 1200.00),
            7 => floatval(get_setting_val('daily_reward_day_7') ?: 2000.00)
        ];

        $claimableAmount = $dayPayouts[$currentDayOfCycle] * $multiplier;

        DB::beginTransaction();
        try {
            $newMask = $streakMask;
            $newMask[$currentDayOfCycle - 1] = '1';

            update_balance($userId, $claimableAmount, 'coin', 'add');
            log_transaction($userId, 'income', 'credit', 'coin', $claimableAmount, "Day " . $currentDayOfCycle . " Daily Bonus Claim");
            add_notification($userId, 'reward', "Day " . $currentDayOfCycle . " Daily Bonus claimed successfully!");

            $extraGranted = 0;
            if ($newMask === '1111111') {
                $extraBonusConfig = floatval(get_setting_val('daily_reward_7day_extra') ?: 5000.00);
                $finalExtra = $extraBonusConfig * $multiplier;
                update_balance($userId, $finalExtra, 'coin', 'add');
                log_transaction($userId, 'income', 'credit', 'coin', $finalExtra, "7-Day Full Streak Extra Bonus");
                add_notification($userId, 'reward', "Congratulations! You claimed all 7 days and earned an extra streak reward of 🪙 " . number_format($finalExtra));
                $extraGranted = $finalExtra;
            }

            $activeStreakCount = substr_count($newMask, '1');
            $rewardsData->update([
                'last_claim_date' => $today,
                'total_claimed' => $rewardsData->total_claimed + 1,
                'streak_mask' => $newMask,
                'streak' => $activeStreakCount
            ]);

            DB::commit();

            $popupMsg = 'Successfully claimed 🪙 ' . number_format($claimableAmount) . ' coins!';
            if ($extraGranted > 0) {
                $popupMsg .= ' Plus, you earned an extra full streak bonus of 🪙 ' . number_format($extraGranted) . ' coins! 🎉';
            }

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Daily Reward Claimed!',
                'message' => $popupMsg . ' 🎉',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('reward');
        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->route('reward')->with('error', 'Claim failed: ' . $e->getMessage());
        }
    }

    // VIP Booster Shop View & Buy Action
    public function showVip()
    {
        $userId = session('user_id');
        $user = User::find($userId);
        $vipPlans = VipPlan::orderBy('price', 'asc')->get();

        $activeVip = UserVip::where('user_id', $userId)
            ->where('expires_at', '>', now())
            ->first();

        return view('user.vip', compact('user', 'vipPlans', 'activeVip'));
    }

    public function buyVipPlan(Request $request)
    {
        $userId = session('user_id');
        $planId = intval($request->input('plan_id', 0));

        $plan = VipPlan::find($planId);
        if (!$plan) {
            return redirect()->route('vip')->with('error', 'Booster plan details not found.');
        }

        $user = User::find($userId);
        if ($user->balance_token < $plan->price) {
            return redirect()->route('vip')->with('error', '🚨 Insufficient token balance to purchase this booster plan.');
        }

        DB::beginTransaction();
        try {
            update_balance($userId, $plan->price, 'token', 'deduct');

            $existingVip = UserVip::where('user_id', $userId)
                ->where('expires_at', '>', now())
                ->first();

            if ($existingVip) {
                $newExpiresAt = $existingVip->expires_at->addDays($plan->duration_days);
                $existingVip->expires_at = $newExpiresAt;
                $existingVip->vip_id = $plan->id;
                $existingVip->save();
            } else {
                UserVip::where('user_id', $userId)->delete();
                $newExpiresAt = now()->addDays($plan->duration_days);
                UserVip::create([
                    'user_id' => $userId,
                    'vip_id' => $plan->id,
                    'expires_at' => $newExpiresAt,
                    'created_at' => now()
                ]);
            }

            log_transaction($userId, 'vip', 'debit', 'token', $plan->price, "Purchased VIP pass: " . $plan->name);
            add_notification($userId, 'vip', "VIP Booster pass " . $plan->name . " activated successfully!");

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Booster Stacked!',
                'message' => 'Booster activated successfully! Your stack duration has been extended to ' . $newExpiresAt->format('d M Y') . ' 👑',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('vip');

        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->route('vip')->with('error', 'Booster purchase failed: ' . $e->getMessage());
        }
    }

    // Gift Cards Promo Redeem
    public function showGift()
    {
        $userId = session('user_id');
        $user = User::find($userId);

        $redeemHistory = DB::table('user_gift_claims')
            ->join('gift_codes', 'user_gift_claims.code_id', '=', 'gift_codes.id')
            ->where('user_gift_claims.user_id', $userId)
            ->where('user_gift_claims.claimed_at', '>', now()->subDay())
            ->select('user_gift_claims.claimed_at', 'gift_codes.code', 'gift_codes.coin_amount as reward_amount')
            ->orderBy('user_gift_claims.id', 'desc')
            ->limit(15)
            ->get();

        return view('user.gift', compact('user', 'redeemHistory'));
    }

    public function redeemGiftCode(Request $request)
    {
        $userId = session('user_id');
        $rawInput = $request->input('gift_code', '');
        $inputCode = strtoupper(trim($rawInput));
        $inputCode = ltrim($inputCode, '#');

        if (empty($inputCode)) {
            return redirect()->route('gift')->with('error', 'Please enter a promo code first.');
        }

        $codeData = GiftCode::whereRaw('UPPER(code) = ?', [$inputCode])->first();
        if (!$codeData) {
            return redirect()->route('gift')->with('error', '🚨 Claim Failed: This promo code does not exist. Check spelling or try another code.');
        }

        $dupRecord = UserGiftClaim::where('user_id', $userId)
            ->where('code_id', $codeData->id)
            ->exists();

        if ($dupRecord) {
            return redirect()->route('gift')->with('error', '🚨 Claim Failed: You have already redeemed this promo code once!');
        }

        DB::beginTransaction();
        try {
            $reward = floatval($codeData->coin_amount);
            update_balance($userId, $reward, 'coin', 'add');

            UserGiftClaim::create([
                'user_id' => $userId,
                'code_id' => $codeData->id,
                'claimed_at' => now()
            ]);

            log_transaction($userId, 'income', 'credit', 'coin', $reward, "Claimed Gift Promo Code: " . $inputCode);
            add_notification($userId, 'gift', "You successfully claimed promo code rewards of 🪙 " . number_format($reward, 2));

            // Clean older claims keeping last 10
            $idsToKeep = UserGiftClaim::where('user_id', $userId)
                ->orderBy('id', 'desc')
                ->limit(10)
                ->pluck('id');
            UserGiftClaim::where('user_id', $userId)
                ->whereNotIn('id', $idsToKeep)
                ->delete();

            DB::commit();

            session()->flash('popup_data', [
                'type' => 'success',
                'title' => 'Promo Code Claimed!',
                'message' => 'You successfully claimed promo code rewards of 🪙 ' . number_format($reward, 2) . '! 🎉',
                'is_game' => false,
                'auto_close' => 0
            ]);

            return redirect()->route('gift');

        } catch (Exception $e) {
            DB::rollBack();
            return redirect()->route('gift')->with('error', '🚨 Claim Failed (System Error): ' . $e->getMessage());
        }
    }

    // --- MISSIONS HUB ---
    public function showTasks()
    {
        $userId = session('user_id');
        $user = User::find($userId);

        $completedTodayCount = UserTask::where('user_id', $userId)
            ->whereDate('completed_at', now()->toDateString())
            ->count();

        $dailyTaskLimit = intval(get_setting_val('daily_task_limit') ?: 10);
        $isLimitReached = ($completedTodayCount >= $dailyTaskLimit);

        $allTasks = Task::leftJoin('user_tasks', function ($join) use ($userId) {
                $join->on('tasks.id', '=', 'user_tasks.task_id')
                     ->where('user_tasks.user_id', '=', $userId);
            })
            ->whereNull('user_tasks.id')
            ->select('tasks.*')
            ->orderBy('tasks.id', 'desc')
            ->get();

        return view('user.task', compact('user', 'completedTodayCount', 'dailyTaskLimit', 'isLimitReached', 'allTasks'));
    }

    public function startTask(Request $request)
    {
        $userId = session('user_id');
        if (is_ad_restricted($userId)) {
            return response()->json(['success' => false, 'message' => 'Ad privileges are restricted on this device due to multi-account usage.']);
        }

        $taskId = intval($request->query('task_id', 0));
        if ($taskId > 0) {
            $activeTasks = session('active_tasks', []);
            $activeTasks[$taskId] = time();
            session(['active_tasks' => $activeTasks]);

            return response()->json(['success' => true]);
        }

        return response()->json(['success' => false, 'message' => 'Invalid task configuration.']);
    }

    public function claimTask(Request $request)
    {
        $userId = session('user_id');
        $taskId = intval($request->input('task_id'));

        $completedTodayCount = UserTask::where('user_id', $userId)
            ->whereDate('completed_at', now()->toDateString())
            ->count();

        $dailyTaskLimit = intval(get_setting_val('daily_task_limit') ?: 10);
        $isLimitReached = ($completedTodayCount >= $dailyTaskLimit);

        if (is_ad_restricted($userId)) {
            return back()->with('error', '🚨 Ad privileges are restricted on this device due to multi-account usage.');
        }

        if ($isLimitReached) {
            return back()->with('error', "🚨 Daily Task Limit Reached! You can only complete a maximum of {$dailyTaskLimit} tasks per day.");
        }

        $taskAlreadyDone = UserTask::where('user_id', $userId)->where('task_id', $taskId)->exists();
        if ($taskAlreadyDone) {
            return back()->with('error', 'Task already completed!');
        }

        $task = Task::find($taskId);
        if (!$task) {
            return back()->with('error', 'Task data could not be located.');
        }

        $isVideo = in_array(strtolower($task->task_type), ['youtube', 'yt', 'video']);
        $requiredDuration = $isVideo ? 45 : 5;

        $activeTasks = session('active_tasks', []);
        $sessionStartTime = $activeTasks[$taskId] ?? 0;
        $elapsedSeconds = time() - $sessionStartTime;

        if ($sessionStartTime === 0 || $elapsedSeconds < $requiredDuration) {
            return back()->with('error', '🚨 Verification Spoofing Detected! You must finish the countdown before claiming.');
        }

        DB::beginTransaction();
        try {
            $reward = floatval($task->reward_amount);
            update_balance($userId, $reward, 'coin', 'add');

            UserTask::create([
                'user_id' => $userId,
                'task_id' => $taskId,
                'completed_at' => now()
            ]);

            log_transaction($userId, 'income', 'credit', 'coin', $reward, "Completed Task: " . $task->name);

            if ($isVideo) {
                log_ad_view($userId);
            }

            unset($activeTasks[$taskId]);
            session(['active_tasks' => $activeTasks]);

            DB::commit();

            return redirect()->route('task', ['success' => 1, 'amt' => $reward]);
        } catch (Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Claim processing error: ' . $e->getMessage());
        }
    }

    // --- CLOUD MINING NODE ---
    public function showMining()
    {
        $userId = session('user_id');
        $user = User::find($userId);

        $mining = Mining::firstOrCreate(
            ['user_id' => $userId],
            [
                'time_level' => 1,
                'income_level' => 1,
                'speed_level' => 1,
                'mining_start_time' => null,
                'last_claim_time' => null,
                'boost_expires_at' => null,
                'last_boost_time' => null
            ]
        );

        $vip = get_vip_multipliers($userId);

        $boostMultiplier = 1.0;
        $isBoosted = false;
        $boostExpirySec = 0;
        if (!empty($mining->boost_expires_at) && strtotime($mining->boost_expires_at) > time()) {
            $isBoosted = true;
            $boostMultiplier = floatval(get_setting_val('mining_boost_multiplier') ?: 2.0);
            $boostExpirySec = strtotime($mining->boost_expires_at) - time();
        }

        $baseDurationHours = floatval(get_setting_val('mining_base_duration_hours') ?: 4);
        $baseDuration = $baseDurationHours * 3600;

        $speedMult = 1.0 * ($vip['mining_speed_multiplier'] ?? 1.0) * $boostMultiplier;
        $totalDuration = $baseDuration * ($vip['mining_capacity_multiplier'] ?? 1.0);

        $baseRateHourly = floatval(get_setting_val('mining_base_yield_hourly') ?: 200.0000);
        $coinRateSec = $baseRateHourly / 3600;

        $isActive = !empty($mining->mining_start_time);
        $pendingCoins = 0.0000;
        $progressPercent = 0;
        $secondsRemaining = 0;
        $isStorageFull = false;

        if ($isActive) {
            $startTimestamp = strtotime($mining->mining_start_time);
            $currentTimestamp = time();
            $elapsedVirtualSeconds = ($currentTimestamp - $startTimestamp) * $speedMult;

            if ($elapsedVirtualSeconds >= $totalDuration) {
                $isStorageFull = true;
                $elapsedVirtualSeconds = $totalDuration;
            }

            $pendingCoins = $elapsedVirtualSeconds * $coinRateSec;
            $progressPercent = ($elapsedVirtualSeconds / $totalDuration) * 100;

            $remainingVirtualSeconds = $totalDuration - $elapsedVirtualSeconds;
            $secondsRemaining = max(0, ceil($remainingVirtualSeconds / $speedMult));

            if (($vip['is_vip'] ?? false) && $isStorageFull) {
                DB::beginTransaction();
                try {
                    update_balance($userId, $pendingCoins, 'coin', 'add');
                    log_transaction($userId, 'income', 'credit', 'coin', $pendingCoins, "Auto-claimed VIP mining session gains");
                    add_notification($userId, 'gift', "VIP Auto-Claim: 🪙 " . number_format($pendingCoins, 4) . " auto-credited!");

                    $mining->update([
                        'mining_start_time' => now(),
                        'last_claim_time' => now()
                    ]);

                    DB::commit();

                    $isStorageFull = false;
                    $pendingCoins = 0.0000;
                    $progressPercent = 0;
                    $secondsRemaining = $totalDuration;
                } catch (Exception $e) {
                    DB::rollBack();
                }
            }
        }

        $claimsHistory = DB::table('transactions')
            ->where('user_id', $userId)
            ->where('category', 'income')
            ->where('description', 'like', '%mining%')
            ->where('created_at', '>=', now()->subDay())
            ->orderBy('id', 'desc')
            ->limit(15)
            ->get();

        $monetagLink = get_setting_val('monetag_direct_link') ?: 'https://www.google.com';
        $adWaitSec = intval(get_setting_val('mining_boost_ad_wait_seconds') ?: 10);
        $boostMultiplierConfig = floatval(get_setting_val('mining_boost_multiplier') ?: 2.0);

        $boostCooldownHours = floatval(get_setting_val('mining_boost_cooldown_hours') ?: 4.0);
        $boostCooldownSec = $boostCooldownHours * 3600;
        $lastBoostTimeTs = !empty($mining->last_boost_time) ? strtotime($mining->last_boost_time) : 0;
        $cooldownRemainingSec = max(0, $boostCooldownSec - (time() - $lastBoostTimeTs));

        return view('mining', compact(
            'user', 'mining', 'isBoosted', 'boostExpirySec', 'speedMult', 
            'totalDuration', 'baseRateHourly', 'isActive', 'pendingCoins', 
            'progressPercent', 'secondsRemaining', 'isStorageFull', 'claimsHistory', 
            'monetagLink', 'adWaitSec', 'boostMultiplierConfig', 'cooldownRemainingSec'
        ));
    }

    public function startMining()
    {
        $userId = session('user_id');
        $mining = Mining::where('user_id', $userId)->firstOrFail();

        if (empty($mining->mining_start_time)) {
            $mining->update([
                'mining_start_time' => now(),
                'last_claim_time' => null
            ]);
            return redirect()->route('mining')->with('success', 'Mining session activated!');
        }

        return redirect()->route('mining');
    }

    public function claimMining()
    {
        $userId = session('user_id');
        $mining = Mining::where('user_id', $userId)->firstOrFail();

        if (empty($mining->mining_start_time)) {
            return redirect()->route('mining');
        }

        $vip = get_vip_multipliers($userId);
        
        $boostMultiplier = 1.0;
        if (!empty($mining->boost_expires_at) && strtotime($mining->boost_expires_at) > time()) {
            $boostMultiplier = floatval(get_setting_val('mining_boost_multiplier') ?: 2.0);
        }

        $baseDurationHours = floatval(get_setting_val('mining_base_duration_hours') ?: 4);
        $baseDuration = $baseDurationHours * 3600;

        $speedMult = 1.0 * ($vip['mining_speed_multiplier'] ?? 1.0) * $boostMultiplier;
        $totalDuration = $baseDuration * ($vip['mining_capacity_multiplier'] ?? 1.0);

        $baseRateHourly = floatval(get_setting_val('mining_base_yield_hourly') ?: 200.0000);
        $coinRateSec = $baseRateHourly / 3600;

        $startTimestamp = strtotime($mining->mining_start_time);
        $elapsedVirtualSeconds = (time() - $startTimestamp) * $speedMult;

        if ($elapsedVirtualSeconds >= $totalDuration) {
            $elapsedVirtualSeconds = $totalDuration;
        }

        $pendingCoins = $elapsedVirtualSeconds * $coinRateSec;

        if ($pendingCoins > 0) {
            DB::beginTransaction();
            try {
                update_balance($userId, $pendingCoins, 'coin', 'add');
                log_transaction($userId, 'income', 'credit', 'coin', $pendingCoins, "Claimed mining session gains");

                $mining->update([
                    'mining_start_time' => now(),
                    'last_claim_time' => now()
                ]);

                DB::commit();

                return redirect()->route('mining')->with('success', "Claimed 🪙 " . number_format($pendingCoins, 4) . " successfully! New session restarted automatically.");
            } catch (Exception $e) {
                DB::rollBack();
                return redirect()->route('mining')->with('error', 'Claim failed: ' . $e->getMessage());
            }
        }

        return redirect()->route('mining');
    }

    public function startBoost()
    {
        $userId = session('user_id');
        if (is_ad_restricted($userId)) {
            return response()->json(['status' => 'error', 'message' => 'Multiple account ad restriction active.']);
        }

        session(['boost_start_time' => time()]);
        return response()->json(['status' => 'success']);
    }

    public function claimBoost()
    {
        $userId = session('user_id');
        if (is_ad_restricted($userId)) {
            return response()->json(['status' => 'error', 'message' => 'Multiple account ad restriction active.']);
        }

        $mining = Mining::where('user_id', $userId)->firstOrFail();
        $startTime = session('boost_start_time', 0);
        $adWait = intval(get_setting_val('mining_boost_ad_wait_seconds') ?: 10);
        $cooldownHours = floatval(get_setting_val('mining_boost_cooldown_hours') ?: 4.0);
        $cooldownSec = $cooldownHours * 3600;
        $lastBoost = !empty($mining->last_boost_time) ? strtotime($mining->last_boost_time) : 0;

        if (time() - $lastBoost < $cooldownSec) {
            return response()->json(['status' => 'error', 'message' => 'Boost is on cooldown.']);
        }

        if (time() - $startTime >= $adWait) {
            $durationHours = floatval(get_setting_val('mining_boost_duration_hours') ?: 2.0);
            $expiryTime = now()->addSeconds($durationHours * 3600);

            $mining->update([
                'boost_expires_at' => $expiryTime,
                'last_boost_time' => now()
            ]);

            log_ad_view($userId);
            session()->forget('boost_start_time');

            return response()->json(['status' => 'success', 'message' => 'Boost activated successfully!']);
        } else {
            return response()->json(['status' => 'error', 'message' => 'You must wait for the ad timer to finish!']);
        }
    }
}