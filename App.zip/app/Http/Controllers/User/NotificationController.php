<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Notification;

class NotificationController extends Controller
{
    public function index()
    {
        $userId = session('user_id');
        $user = User::findOrFail($userId);

        $notifications = Notification::where('user_id', $userId)
            ->whereIn('type', ['kyc', 'reward', 'vip', 'lottery', 'shop', 'mining', 'referral', 'gift', 'login'])
            ->orderBy('id', 'desc')
            ->limit(50)
            ->get();

        Notification::where('user_id', $userId)
            ->where('status', 'unread')
            ->whereIn('type', ['kyc', 'reward', 'vip', 'lottery', 'shop', 'mining', 'referral', 'gift', 'login'])
            ->update(['status' => 'read']);

        return view('user.notification', compact('user', 'notifications'));
    }
}