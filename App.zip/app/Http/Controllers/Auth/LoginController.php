<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Cookie;
use App\Models\User;
use Exception;

class LoginController extends Controller
{
    protected string $secureKey = 'secure_user_salt_cookie_dxearn_777';

    public function showLogin()
    {
        if (session()->has('user_id')) {
            return redirect()->route('home');
        }

        $rememberCookie = Cookie::get('dx_user_remember');
        if ($rememberCookie) {
            $parts = explode(':', $rememberCookie, 2);
            if (count($parts) === 2) {
                list($cookieUid, $cookieHash) = $parts;
                $expectedHash = hash_hmac('sha256', $cookieUid, $this->secureKey);
                if (hash_equals($expectedHash, $cookieHash)) {
                    $user = User::find($cookieUid);
                    if ($user && $user->is_banned == 0) {
                        session(['user_id' => $user->id]);
                        return redirect()->route('home');
                    }
                }
            }
        }

        return view('auth.login');
    }

    public function googleLogin(Request $request)
    {
        $idToken = $request->input('credential');
        if (empty($idToken)) {
            return response()->json(['status' => 'error', 'message' => 'Credentials missing.'], 400);
        }

        try {
            $response = Http::get("https://oauth2.googleapis.com/tokeninfo", [
                'id_token' => $idToken
            ]);

            if ($response->failed()) {
                return response()->json(['status' => 'error', 'message' => 'Invalid Google credential token.'], 401);
            }

            $payload = $response->json();
            if (!isset($payload['email'])) {
                return response()->json(['status' => 'error', 'message' => 'Email scope missing.'], 400);
            }

            $email = clean_data($payload['email']);
            $fullName = clean_data($payload['name'] ?? '');
            $photoUrl = clean_data($payload['picture'] ?? '');
            $deviceUid = $request->cookie('device_uid', '');

            $user = User::where('email', $email)->first();

            if ($user) {
                if ($user->is_banned == 1) {
                    return response()->json(['status' => 'error', 'message' => 'This account is suspended.'], 403);
                }

                $user->device_uid = $deviceUid;
                $user->save();

                session(['user_id' => $user->id]);
                $this->setUserRememberCookie($user->id);

                return response()->json(['status' => 'success']);
            } else {
                $baseUsername = '@' . preg_replace('/[^a-zA-Z0-9_]/', '', explode('@', $email)[0]);
                $username = $baseUsername;
                
                while (User::where('username', $username)->exists()) {
                    $username = $baseUsername . mt_rand(10, 99);
                }

                $localFilename = 'default_avatar.png';
                if (!empty($photoUrl)) {
                    $imgResponse = Http::timeout(10)->get($photoUrl);
                    if ($imgResponse->successful()) {
                        $tempFile = tempnam(sys_get_temp_dir(), 'g_pic');
                        file_put_contents($tempFile, $imgResponse->body());
                        
                        $fileStruct = [
                            'tmp_name' => $tempFile,
                            'mime' => $imgResponse->header('Content-Type')
                        ];
                        
                        $targetDir = public_path('uploads/');
                        $newFn = 'g_avatar_' . md5($email) . '_' . time();
                        $compressed = compress_image_to_webp($fileStruct, $targetDir, $newFn);
                        if ($compressed) {
                            $localFilename = $compressed;
                        }
                        @unlink($tempFile);
                    }
                }

                $referredBy = session('referred_by', $request->input('ref', ''));

                $user = User::create([
                    'username' => $username,
                    'password' => Hash::make(mt_rand(100000, 999999)),
                    'full_name' => $fullName,
                    'email' => $email,
                    'profile_pic' => $localFilename,
                    'referral_code' => generate_referral_code(),
                    'referred_by' => $referredBy,
                    'is_banned' => 0,
                    'kyc_status' => 'unverified',
                    'device_uid' => $deviceUid,
                    'created_at' => now()
                ]);

                session(['user_id' => $user->id]);
                $this->setUserRememberCookie($user->id);

                if (!empty($referredBy)) {
                    process_referral_registration($user->id, $referredBy);
                }

                return response()->json(['status' => 'success']);
            }

        } catch (Exception $e) {
            return response()->json(['status' => 'error', 'message' => 'Internal server error: ' . $e->getMessage()], 500);
        }
    }

    public function telegramLogin(Request $request)
    {
        $initData = $request->input('initData');
        $referredBy = $request->input('referred_by', '');
        $deviceUid = $request->cookie('device_uid', '');

        $botToken = get_setting_val('bot_token');
        if (empty($botToken)) {
            return response()->json(['status' => 'error', 'message' => 'System configuration error.'], 500);
        }

        $tgUser = $this->validateTelegramInitData($initData, $botToken);
        if (!$tgUser) {
            return response()->json(['status' => 'error', 'message' => 'Authentication failed. Secure signature is invalid or expired.'], 401);
        }

        $tgId = clean_data($tgUser['id'] ?? '');
        $username = clean_data($tgUser['username'] ?? '');
        $firstName = clean_data($tgUser['first_name'] ?? '');
        $lastName = clean_data($tgUser['last_name'] ?? '');
        $photoUrl = clean_data($tgUser['photo_url'] ?? '');

        if (empty($tgId)) {
            return response()->json(['status' => 'error', 'message' => 'Invalid Telegram ID payload.'], 400);
        }

        $user = User::where('telegram_id', $tgId)->first();

        if (!$user) {
            $username = trim($username);
            if (empty($username)) {
                $username = 'tg_' . $tgId;
            }
            $username = '@' . ltrim($username, '@');

            while (User::where('username', $username)->exists()) {
                $username = $username . mt_rand(10, 99);
            }

            $localFilename = 'default_avatar.png';
            if (!empty($photoUrl)) {
                $imgResponse = Http::timeout(10)->get($photoUrl);
                if ($imgResponse->successful()) {
                    $tempFile = tempnam(sys_get_temp_dir(), 'tg_pic');
                    file_put_contents($tempFile, $imgResponse->body());

                    $fileStruct = [
                        'tmp_name' => $tempFile,
                        'mime' => $imgResponse->header('Content-Type')
                    ];

                    $targetDir = public_path('uploads/');
                    $newFn = 'tg_avatar_' . $tgId . '_' . time();
                    $compressed = compress_image_to_webp($fileStruct, $targetDir, $newFn);
                    if ($compressed) {
                        $localFilename = $compressed;
                    }
                    @unlink($tempFile);
                }
            }

            $fullName = trim($firstName . ' ' . $lastName);
            if (empty($fullName)) {
                $fullName = $username;
            }

            $user = User::create([
                'username' => $username,
                'password' => Hash::make(mt_rand(100000, 999999)),
                'full_name' => $fullName,
                'profile_pic' => $localFilename,
                'referral_code' => generate_referral_code(),
                'referred_by' => $referredBy,
                'telegram_id' => $tgId,
                'balance_coin' => 0.00,
                'balance_token' => 0.00,
                'balance_dollar' => 0.00,
                'is_banned' => 0,
                'kyc_status' => 'unverified',
                'device_uid' => $deviceUid,
                'created_at' => now()
            ]);

            session(['user_id' => $user->id]);
            $this->setUserRememberCookie($user->id);

            if (!empty($referredBy)) {
                process_referral_registration($user->id, $referredBy);
            }

        } else {
            if ($user->is_banned == 1) {
                return response()->json(['status' => 'error', 'message' => 'This account is suspended.'], 403);
            }
            
            $user->update(['device_uid' => $deviceUid]);
            session(['user_id' => $user->id]);
            $this->setUserRememberCookie($user->id);
        }

        return response()->json(['success' => true, 'status' => 'success']);
    }

    public function logout() 
    {
        session()->forget('user_id');
        Cookie::queue(Cookie::forget('dx_user_remember'));
        return redirect()->route('login');
    }

    private function validateTelegramInitData($initData, $botToken) 
    {
        if (empty($initData) || empty($botToken)) {
            return false;
        }
        
        parse_str($initData, $data);
        if (!isset($data['hash'])) {
            return false;
        }
        
        $checkHash = $data['hash'];
        unset($data['hash']);
        
        $dataCheckArr = [];
        foreach ($data as $key => $value) {
            $dataCheckArr[] = $key . '=' . $value;
        }
        sort($dataCheckArr);
        $dataCheckString = implode("\n", $dataCheckArr);
        
        $secretKey = hash_hmac('sha256', $botToken, 'WebAppData', true);
        $hash = hash_hmac('sha256', $dataCheckString, $secretKey);
        
        if (hash_equals($hash, $checkHash)) {
            return json_decode($data['user'] ?? '{}', true);
        }
        return false;
    }

    private function setUserRememberCookie($uid) 
    {
        $cookieVal = $uid . ':' . hash_hmac('sha256', $uid, $this->secureKey);
        Cookie::queue('dx_user_remember', $cookieVal, 86400 * 30, "/");
    }
}