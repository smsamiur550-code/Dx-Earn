<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserVip extends Model
{
    protected $table = 'user_vip';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'vip_id',
        'expires_at',
        'last_bonus_claim',
        'created_at'
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'last_bonus_claim' => 'datetime',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function plan(): BelongsTo
    {
        return $this->belongsTo(VipPlan::class, 'vip_id', 'id');
    }
}