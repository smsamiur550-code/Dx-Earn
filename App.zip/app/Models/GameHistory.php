<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GameHistory extends Model
{
    protected $table = 'game_history';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'game_id',
        'val',
        'label',
        'created_at'
    ];

    protected $casts = [
        'game_id' => 'integer',
        'val' => 'decimal:4',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}