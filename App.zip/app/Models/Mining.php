<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Mining extends Model
{
    protected $table = 'mining';

    protected $primaryKey = 'user_id';

    public $incrementing = false;

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'time_level',
        'income_level',
        'speed_level',
        'mining_start_time',
        'last_claim_time',
        'boost_expires_at',
        'last_boost_time'
    ];

    protected $casts = [
        'mining_start_time' => 'datetime',
        'last_claim_time' => 'datetime',
        'boost_expires_at' => 'datetime',
        'last_boost_time' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}