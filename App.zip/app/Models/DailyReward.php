<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DailyReward extends Model
{
    protected $table = 'daily_rewards';

    protected $primaryKey = 'user_id';

    public $incrementing = false;

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'streak',
        'last_claim_date',
        'total_claimed',
        'cycle_start',
        'streak_mask'
    ];

    protected $casts = [
        'last_claim_date' => 'date',
        'cycle_start' => 'date'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}