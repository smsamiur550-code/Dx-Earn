<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    protected $table = 'orders';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'product_id',
        'name',
        'phone',
        'address',
        'total_price',
        'coin_deducted',
        'coin_percentage',
        'discount_cash',
        'delivery_charge',
        'delivery_location',
        'cod_amount',
        'status',
        'created_at'
    ];

    protected $casts = [
        'total_price' => 'decimal:2',
        'coin_deducted' => 'decimal:2',
        'coin_percentage' => 'integer',
        'discount_cash' => 'decimal:2',
        'delivery_charge' => 'decimal:2',
        'cod_amount' => 'decimal:2',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class, 'product_id', 'id');
    }

    public function lotteryTicket(): HasOne
    {
        return $this->hasOne(LotteryTicket::class, 'order_id', 'id');
    }
}