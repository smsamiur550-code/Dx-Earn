<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Conversion extends Model
{
    protected $table = 'conversions';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'amount_from',
        'amount_to',
        'type',
        'status',
        'rate',
        'created_at'
    ];

    protected $casts = [
        'amount_from' => 'decimal:4',
        'amount_to' => 'decimal:4',
        'rate' => 'decimal:6',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}