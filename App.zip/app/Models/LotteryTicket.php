<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LotteryTicket extends Model
{
    protected $table = 'lottery_tickets';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'order_id',
        'ticket_number',
        'status',
        'prize_amount',
        'created_at'
    ];

    protected $casts = [
        'prize_amount' => 'decimal:2',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class, 'order_id', 'id');
    }
}