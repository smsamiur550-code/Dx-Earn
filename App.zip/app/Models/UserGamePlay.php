<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserGamePlay extends Model
{
    protected $table = 'user_game_plays';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'game_id',
        'plays_today',
        'last_played'
    ];

    protected $casts = [
        'game_id' => 'integer',
        'plays_today' => 'integer',
        'last_played' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}