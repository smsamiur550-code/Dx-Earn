<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Withdrawal extends Model
{
    protected $table = 'withdrawals';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'amount',
        'payment_method',
        'account_number',
        'status',
        'withdrawal_type',
        'ticket_number',
        'requested_at'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'requested_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}