<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class GiftCode extends Model
{
    protected $table = 'gift_codes';

    public $timestamps = false;

    protected $fillable = [
        'code',
        'coin_amount',
        'created_at'
    ];

    protected $casts = [
        'coin_amount' => 'decimal:2',
        'created_at' => 'datetime'
    ];

    public function claims(): HasMany
    {
        return $this->hasMany(UserGiftClaim::class, 'code_id', 'id');
    }
}