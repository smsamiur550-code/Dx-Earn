<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Kyc extends Model
{
    protected $table = 'kyc';

    protected $primaryKey = 'user_id';

    public $incrementing = false;

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'nid_number',
        'full_name',
        'dob',
        'front_img',
        'back_img',
        'selfie_img',
        'status',
        'submitted_at'
    ];

    protected $casts = [
        'dob' => 'date',
        'submitted_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}