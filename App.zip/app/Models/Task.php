<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Task extends Model
{
    protected $table = 'tasks';

    public $timestamps = false;

    protected $fillable = [
        'name',
        'link',
        'reward_amount',
        'task_type'
    ];

    protected $casts = [
        'reward_amount' => 'decimal:4'
    ];

    public function completions(): HasMany
    {
        return $this->hasMany(UserTask::class, 'task_id', 'id');
    }
}