<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    protected $table = 'admins';

    public $timestamps = false;

    protected $fillable = [
        'username',
        'password',
        'permissions',
        'is_active',
        'created_at'
    ];

    protected $casts = [
        'permissions' => 'array',
        'is_active' => 'integer',
        'created_at' => 'datetime'
    ];
}