<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Referral extends Model
{
    protected $table = 'referrals';

    public $timestamps = false;

    protected $fillable = [
        'referrer_id',
        'referee_id',
        'bonus_amount',
        'referee_bonus',
        'status',
        'created_at'
    ];

    protected $casts = [
        'bonus_amount' => 'decimal:2',
        'referee_bonus' => 'decimal:2',
        'created_at' => 'datetime'
    ];

    public function referrer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referrer_id', 'id');
    }

    public function referee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'referee_id', 'id');
    }
}