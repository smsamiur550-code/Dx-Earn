<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;

class User extends Model
{
    protected $table = 'users';

    public $timestamps = false;

    protected $fillable = [
        'username',
        'password',
        'full_name',
        'email',
        'profile_pic',
        'referral_code',
        'referred_by',
        'telegram_id',
        'balance_coin',
        'balance_token',
        'balance_dollar',
        'balance_referral_dollar',
        'is_banned',
        'kyc_status',
        'kyc_submitted_at',
        'device_uid',
        'coin_convert_unlocked',
        'coin_convert_used',
        'profile_edited',
        'shop_country',
        'hard_lock_expires_at',
        'created_at'
    ];

    protected $casts = [
        'balance_coin' => 'decimal:6',
        'balance_token' => 'decimal:6',
        'balance_dollar' => 'decimal:2',
        'balance_referral_dollar' => 'decimal:2',
        'is_banned' => 'integer',
        'coin_convert_unlocked' => 'integer',
        'coin_convert_used' => 'decimal:2',
        'profile_edited' => 'integer',
        'kyc_submitted_at' => 'datetime',
        'hard_lock_expires_at' => 'datetime',
        'created_at' => 'datetime'
    ];

    public function vip(): HasOne
    {
        return $this->hasOne(UserVip::class, 'user_id', 'id');
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(Referral::class, 'referrer_id', 'id');
    }

    public function receivedReferrals(): HasMany
    {
        return $this->hasMany(Referral::class, 'referee_id', 'id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'user_id', 'id');
    }

    public function lotteryTickets(): HasMany
    {
        return $this->hasMany(LotteryTicket::class, 'user_id', 'id');
    }

    public function transactions(): HasMany
    {
        return $this->hasMany(Transaction::class, 'user_id', 'id');
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(Notification::class, 'user_id', 'id');
    }

    public function chatMessages(): HasMany
    {
        return $this->hasMany(Chat::class, 'sender_id', 'id');
    }

    public function completedTasks(): HasMany
    {
        return $this->hasMany(UserTask::class, 'user_id', 'id');
    }
}