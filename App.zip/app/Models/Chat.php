<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Chat extends Model
{
    protected $table = 'chat';

    public $timestamps = false;

    protected $fillable = [
        'sender_id',
        'message',
        'is_admin',
        'is_seen',
        'created_at'
    ];

    protected $casts = [
        'is_admin' => 'integer',
        'is_seen' => 'integer',
        'created_at' => 'datetime'
    ];

    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sender_id', 'id');
    }
}