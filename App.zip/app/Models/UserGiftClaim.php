<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserGiftClaim extends Model
{
    protected $table = 'user_gift_claims';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'code_id',
        'claimed_at'
    ];

    protected $casts = [
        'claimed_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function giftCode(): BelongsTo
    {
        return $this->belongsTo(GiftCode::class, 'code_id', 'id');
    }
}