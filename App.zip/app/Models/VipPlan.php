<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class VipPlan extends Model
{
    protected $table = 'vip_plans';

    public $timestamps = false;

    protected $fillable = [
        'name',
        'price',
        'duration_days',
        'benefits',
        'extra_mining_income',
        'faster_mining_speed',
        'daily_bonus'
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'extra_mining_income' => 'decimal:2',
        'faster_mining_speed' => 'decimal:2',
        'daily_bonus' => 'decimal:2'
    ];

    public function users(): HasMany
    {
        return $this->hasMany(UserVip::class, 'vip_id', 'id');
    }
}