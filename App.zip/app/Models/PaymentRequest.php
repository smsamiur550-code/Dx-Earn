<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PaymentRequest extends Model
{
    protected $table = 'payment_requests';

    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'payment_type',
        'amount',
        'screenshot_pic',
        'meta_data',
        'status',
        'created_at'
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'created_at' => 'datetime'
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}