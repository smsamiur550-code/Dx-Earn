<?php

header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');
header('X-Accel-Buffering: no');
ini_set('output_buffering', 'off');
ini_set('zlib.output_compression', false);

while (ob_get_level()) {
    ob_end_flush();
}
ob_implicit_flush(true);

ini_set('max_execution_time', 600);
ini_set('memory_limit', '512M');

echo "<div style='font-family:monospace; background:#0f172a; color:#38bdf8; padding:20px; min-height:100vh; line-height:1.5;'>";
echo "<h3 style='color:#fbbf24; margin-top:0;'>⚙️ DX EARN - Live Composer Dependency Installer</h3>";

if (!file_exists('composer.phar')) {
    echo "Starting download of composer.phar...<br>";
    flush();

    $fp = fopen('composer.phar', 'w+b');
    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, 'https://getcomposer.org/composer.phar');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $downloadedBytes = 0;
    $lastPercent = -1;

    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $data) use ($fp, &$downloadedBytes, &$lastPercent) {
        $written = fwrite($fp, $data);
        $downloadedBytes += $written;
        
        $totalSize = curl_getinfo($ch, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
        if ($totalSize > 0) {
            $percent = round(($downloadedBytes / $totalSize) * 100);
            if ($percent !== $lastPercent) {
                echo "Downloading composer.phar: " . $percent . "% (" . round($downloadedBytes / 1024 / 1024, 2) . " MB / " . round($totalSize / 1024 / 1024, 2) . " MB)<br>";
                flush();
                $lastPercent = $percent;
            }
        }
        return $written;
    });

    curl_exec($ch);
    curl_close($ch);
    fclose($fp);
    echo "<span style='color:#10b981;'>✓ composer.phar downloaded successfully!</span><br><br>";
    flush();
} else {
    echo "<span style='color:#64748b;'>✓ composer.phar already exists on server.</span><br><br>";
    flush();
}

echo "Initializing 'composer install' process...<br>";
echo "<span style='color:#64748b;'>This may take 2-5 minutes depending on the server network. Please do not close this tab.</span><br><br>";
flush();

$command = 'php composer.phar install -d ../ --no-interaction --no-ansi --no-progress 2>&1';
$process = popen($command, 'r');

if (is_resource($process)) {
    echo "<pre style='color:#94a3b8; background:#1e293b; padding:15px; border-radius:10px; overflow-x:auto; border:1px solid #334155;'>";
    flush();

    while (!feof($process)) {
        $line = fgets($process);
        echo htmlspecialchars($line);
        flush();
    }
    
    pclose($process);
    echo "</pre>";
    echo "<span style='color:#10b981; font-weight:bold;'>🎉 COMPOSER INSTALLATION COMPLETED SUCCESSFULLY!</span><br><br>";
    echo "You can now run your setup file: <a href='setup.php?key=dx_earn_secure_setup_2026' style='color:#fbbf24; text-decoration:underline;'>Click here to Run setup.php</a>";
    flush();
} else {
    echo "<span style='color:#ef4444;'>❌ Failed to execute composer command on this hosting environment.</span>";
    flush();
}

echo "</div>";