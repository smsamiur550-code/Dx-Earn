<?php

$secretKey = "2026"; 

if (!isset($_GET['key']) || $_GET['key'] !== $secretKey) {
    header('HTTP/1.1 403 Forbidden');
    die("<div style='font-family:sans-serif; text-align:center; padding:100px; color:#ef4444;'><h2>⛔ Access Denied!</h2><p>Please provide the correct secure key parameter (e.g., <code>setup.php?key=your_secret_key</code>)</p></div>");
}

define('LARAVEL_START', microtime(true));

// ২. অটো-লোড ফাইল ভ্যালিডেশন (Composer Check)
if (!file_exists(__DIR__.'/../vendor/autoload.php')) {
    die("<div style='font-family:sans-serif; text-align:center; padding:100px; color:#ef4444;'><h2>⚠️ Vendor folder missing!</h2><p>Please run <code>composer install</code> on your server first before running this setup script.</p></div>");
}

// ৩. .env ফাইল চেক ও অটো-কপি (.env Automatic Creator)
if (!file_exists(__DIR__.'/../.env') && file_exists(__DIR__.'/../.env.example')) {
    copy(__DIR__.'/../.env.example', __DIR__.'/../.env');
    echo "<p style='color: #3b82f6; font-family:sans-serif; text-align:center; font-weight: bold;'>✓ .env file created from .env.example</p>";
}

// ৪. লারাভেল বুটস্ট্র্যাপ লোড করা (Bootstrap Laravel Engine)
require __DIR__.'/../vendor/autoload.php';
$app = require_once __DIR__.'/../bootstrap/app.php';

$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

// এইচটিএমএল আউটপুট স্টাইল
echo "<div style='font-family:sans-serif; padding:30px; max-width:600px; margin: 50px auto; background:#f8fafc; border:1px solid #e2e8f0; border-radius:24px; box-shadow:0 15px 35px rgba(0,0,0,0.03);'>";
echo "<h2 style='color:#1e293b; border-bottom:1px solid #e2e8f0; padding-bottom:10px; margin-bottom:20px; font-size:20px; font-weight:900;'>⚡ DX EARN - Secure Automated Setup</h2>";

try {
    // ৫. সিকিউরিটি কি জেনারেট করা (Application Key)
    $appKey = env('APP_KEY');
    if (empty($appKey)) {
        $kernel->call('key:generate');
        echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Application Security Key Generated successfully!</p>";
    } else {
        echo "<p style='color: #64748b; font-size:13px; font-weight:bold;'>✓ Application Security Key already exists.</p>";
    }

    // ৬. ডাটাবেজ মাইগ্রেশন ও সিডিং করা (Database Migration & Seeding)
    $kernel->call('migrate', ['--force' => true]);
    echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Database Tables Migrated & Seeded successfully!</p>";

    // ৭. ইমেজ স্টোরেজ লিংক তৈরি করা (Storage Link)
    if (!file_exists(public_path('storage'))) {
        $kernel->call('storage:link');
        echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Storage Symbolic Link Created successfully!</p>";
    } else {
        echo "<p style='color: #64748b; font-size:13px; font-weight:bold;'>✓ Storage Symbolic Link already exists.</p>";
    }

    // ৮. কনফিগারেশন, রাউট ও ভিউ ক্যাশিং করা (Cache optimization)
    $kernel->call('config:cache');
    echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Configurations Cached successfully!</p>";

    $kernel->call('route:cache');
    echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Route Channels Cached successfully!</p>";

    $kernel->call('view:cache');
    echo "<p style='color: #10b981; font-size:13px; font-weight:bold;'>✓ Blade Templates Compiled & Cached successfully!</p>";

    echo "<div style='background:#f0fdf4; border:1px solid #bbf7d0; padding:15px; border-radius:16px; margin-top:30px; color:#16a34a;'>";
    echo "<h4 style='margin:0 0 5px 0; font-size:14px; font-weight:900;'>🎉 Setup Completed Successfully!</h4>";
    echo "<p style='margin:0; font-size:11px; font-weight:600; line-height:1.5;'>Your DX EARN application node is now active. Please delete this <code>setup.php</code> file from your <code>public/</code> folder for security reasons.</p>";
    echo "</div>";

} catch (\Exception $e) {
    echo "<div style='background:#fef2f2; border:1px solid #fecaca; padding:15px; border-radius:16px; margin-top:30px; color:#dc2626;'>";
    echo "<h4 style='margin:0 0 5px 0; font-size:14px; font-weight:900;'>❌ Setup Error!</h4>";
    echo "<p style='margin:0; font-size:11px; font-weight:600; line-height:1.5;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}

echo "</div>";