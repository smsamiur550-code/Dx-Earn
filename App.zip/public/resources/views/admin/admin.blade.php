m@extends('layouts.admin')

@section('title', 'Sub-Admin Management - DX EARN')
@section('page_title', 'Stuffs access 🛡️')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <button onclick="openCreateModal()" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-blue">
        ➕ Create New Sub-Admin
    </button>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1">Sub-Admins & Page Permissions</h3>
        
        @foreach ($admins as $adm) 
            @php 
                $admJson = json_encode($adm);
                $permissionsArray = json_decode($adm->permissions, true) ?: [];
                $permissionCount = count($permissionsArray);
            @endphp
            <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-3">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-slate-50 border border-slate-150 rounded-xl flex items-center justify-center text-sm">
                            🛡️
                        </div>
                        <div>
                            <!-- Blade Escaping bug fixed here -->
                            <h4 class="text-xs font-black text-slate-800">{{ htmlspecialchars($adm->username) }}</h4>
                            <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Permissions: {{ $permissionCount }} hubs • status: <strong class="{{ $adm->is_active ? 'text-emerald-600' : 'text-rose-500' }}">{{ $adm->is_active ? 'ACTIVE' : 'BLOCKED' }}</strong></p>
                        </div>
                    </div>
                    <div class="flex gap-2">
                        <!-- JS Quote Collision fixed by using Base64 encoding -->
                        <button onclick="openEditModal('{{ base64_encode($admJson) }}')" class="w-8 h-8 rounded-lg bg-blue-50/50 hover:bg-blue-100 text-blue-600 flex items-center justify-center text-xs active:scale-90 transition-transform"><i class="fa-solid fa-pen"></i></button>
                        <form method="POST" action="{{ route('admin.admin_list.action') }}" onsubmit="return confirm('⚠️ Permanent Deletion!\n\nAre you sure you want to completely remove this sub-admin?');">
                            @csrf
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="delete_id" value="{{ $adm->id }}">
                            <button type="submit" class="w-8 h-8 rounded-lg bg-rose-50/50 hover:bg-rose-100 text-rose-500 flex items-center justify-center text-xs active:scale-90 transition-transform"><i class="fa-solid fa-trash-can"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach

        @if ($admins->isEmpty())
            <div class="text-center py-16 bg-white border border-slate-200 rounded-[2rem] shadow-sm">
                <span class="text-4xl block mb-2">👤</span>
                <p class="text-xs font-black text-slate-400 uppercase tracking-widest">No Sub-admins registered yet.</p>
            </div>
        @endif
    </div>
</main>

<!-- 1. CREATE MODAL -->
<div id="createModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
    <div class="bg-white border border-slate-200 rounded-[2.5rem] w-full max-w-sm p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto no-scrollbar text-slate-800">
        <h3 class="text-sm font-black text-slate-900 uppercase text-center">Add New Sub-Admin</h3>
        
        <form method="POST" action="{{ route('admin.admin_list.action') }}" class="space-y-4 pt-3 border-t border-slate-100">
            @csrf
            <input type="hidden" name="action" value="create">

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Username 👤</label>
                <input type="text" name="username" required placeholder="staffname" class="w-full bg-slate-50 border border-slate-150 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none">
            </div>

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Password 🔑</label>
                <input type="password" name="password" required placeholder="••••••••" class="w-full bg-slate-50 border border-slate-150 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none">
            </div>

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-2 ml-1">Page Access Privileges 🛡️</label>
                <div class="grid grid-cols-2 gap-2 text-[9px] font-bold text-slate-500 uppercase h-32 overflow-y-auto border border-slate-150 p-2.5 rounded-xl bg-slate-50/50">
                    @foreach ($availablePermissions as $file => $label)
                        <label class="flex items-center gap-1.5 cursor-pointer justify-start">
                            <input type="checkbox" name="permissions[]" value="{{ $file }}" class="rounded text-blue-500 focus:ring-0">
                            <span class="truncate">{{ $label }}</span>
                        </label>
                    @endforeach
                </div>
            </div>

            <div class="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onclick="closeCreateModal()" class="flex-1 py-3.5 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl text-[10px] font-black border border-slate-200 shadow-sm active:scale-95 duration-100 uppercase tracking-widest bouncy-hover">
                    Cancel
                </button>
                <button type="submit" class="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 duration-100 bouncy-hover btn-glow-blue">
                    Create ⚡
                </button>
            </div>
        </form>
    </div>
</div>

<!-- 2. EDIT MODAL -->
<div id="editModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
    <div class="bg-white border border-slate-200 rounded-[2.5rem] w-full max-w-sm p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto no-scrollbar text-slate-800">
        <h3 class="text-sm font-black text-slate-900 uppercase text-center">Edit Sub-Admin</h3>
        
        <form method="POST" action="{{ route('admin.admin_list.action') }}" class="space-y-4 pt-3 border-t border-slate-100" id="editForm">
            @csrf
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="admin_id" id="edit_admin_id">

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Username (Immutable) 👤</label>
                <input type="text" id="edit_username" readonly class="w-full bg-slate-50 border border-slate-150 text-slate-400 rounded-xl px-3 py-2.5 text-xs font-black cursor-not-allowed outline-none select-none">
            </div>

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">New Password (Optional) 🔑</label>
                <input type="password" name="password" placeholder="Leave blank to keep existing" class="w-full bg-slate-50 border border-slate-150 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none">
            </div>

            <div class="grid grid-cols-1">
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Status 🛡️</label>
                    <select name="is_active" id="edit_is_active" class="w-full bg-slate-50 border border-slate-150 rounded-xl px-2 py-2.5 text-xs font-black text-slate-505 outline-none focus:border-blue-400 transition-all">
                        <option value="1">Active Sub-Admin</option>
                        <option value="0">Blocked Sub-Admin</option>
                    </select>
                </div>
            </div>

            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-2 ml-1">Page Access Privileges 🛡️</label>
                <div class="grid grid-cols-2 gap-2 text-[9px] font-bold text-slate-500 uppercase h-32 overflow-y-auto border border-slate-150 p-2.5 rounded-xl bg-slate-50/50" id="edit_permissions_wrapper">
                    @foreach ($availablePermissions as $file => $label)
                        <label class="flex items-center gap-1.5 cursor-pointer justify-start">
                            <input type="checkbox" name="permissions[]" value="{{ $file }}" id="edit_perm_{{ str_replace('.', '_', $file) }}" class="rounded text-blue-500 focus:ring-0">
                            <span class="truncate">{{ $label }}</span>
                        </label>
                    @endforeach
                </div>
            </div>

            <div class="flex gap-2 pt-2 border-t border-slate-100">
                <button type="button" onclick="closeEditModal()" class="flex-1 py-3.5 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl text-[10px] font-black border border-slate-200 shadow-sm active:scale-95 duration-100 uppercase tracking-widest bouncy-hover">
                    Cancel
                </button>
                <button type="submit" class="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 duration-100 bouncy-hover btn-glow-blue">
                    Save ⚡
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const c_modal = document.getElementById('createModal');
    const e_modal = document.getElementById('editModal');

    function openCreateModal() {
        c_modal.classList.remove('hidden');
    }

    function closeCreateModal() {
        c_modal.classList.add('hidden');
    }

    function openEditModal(dataBase64) {
        // Base64 decoded to prevent JS Quotation Crashes
        const data = JSON.parse(atob(dataBase64));

        document.getElementById('edit_admin_id').value = data.id;
        document.getElementById('edit_username').value = data.username;
        document.getElementById('edit_is_active').value = data.is_active;

        document.querySelectorAll('#edit_permissions_wrapper input[type="checkbox"]').forEach(box => {
            box.checked = false;
        });

        const perms = JSON.parse(data.permissions) || [];
        perms.forEach(file => {
            const elementId = 'edit_perm_' + file.replace('.', '_');
            const box = document.getElementById(elementId);
            if (box) {
                box.checked = true;
            }
        });

        e_modal.classList.remove('hidden');
    }

    function closeEditModal() {
        e_modal.classList.add('hidden');
    }
</script>
@endpush