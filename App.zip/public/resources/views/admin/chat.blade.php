@extends('layouts.admin')

@section('title', 'Live Support Chat - DX EARN')
@section('page_title', 'Support Inbox 💬')

@section('content')
<main class="p-4 flex-grow max-w-[480px] mx-auto w-full flex flex-col relative overflow-hidden text-left" style="height: calc(100vh - 72px);">
    <div id="pane-users-list" class="absolute inset-0 bg-slate-50 flex flex-col overflow-y-auto no-scrollbar z-10 transition-transform duration-300">
        <div class="p-3 bg-white border-b border-slate-200 shrink-0">
            <input type="text" id="chatSearch" oninput="filterChatUsers(this.value)" placeholder="Search message threads..." class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all text-slate-800 shadow-inner">
        </div>
        <div class="flex-grow divide-y divide-slate-100" id="usersContainer"></div>
    </div>

    <div id="pane-conversation" class="absolute inset-0 bg-slate-50 flex flex-col translate-x-full transition-transform duration-300 z-20 overflow-hidden">
        <div class="bg-white px-4 py-3 flex items-center justify-between border-b border-slate-200 shrink-0 shadow-sm">
            <div class="flex items-center gap-2.5 min-w-0">
                <button onclick="backToUserList()" class="text-slate-400 hover:text-slate-700 active:scale-90 p-1 mr-1 shrink-0"><i class="fa-solid fa-chevron-left text-base"></i></button>
                <img id="active-user-pic" src="" class="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 bg-slate-100">
                <div class="min-w-0">
                    <h4 id="active-user-name" class="text-xs font-black text-slate-800 uppercase tracking-wide truncate max-w-[150px]">--</h4>
                    <span class="text-[7px] text-emerald-500 font-bold uppercase tracking-wider block">Support Thread</span>
                </div>
            </div>
        </div>
        <div class="flex-grow overflow-y-auto p-4 space-y-3.5 flex flex-col no-scrollbar bg-slate-50/50" id="chatBox"></div>
        <form id="chatForm" class="bg-white p-3 flex gap-2 border-t border-slate-200 shrink-0">
            <input type="text" id="messageInput" placeholder="Write reply message..." required autocomplete="off" class="flex-grow bg-slate-50 rounded-full px-5 py-3 text-xs font-bold outline-none border border-slate-200 focus:border-blue-400 focus:bg-white transition-all text-slate-900 placeholder:text-slate-400 shadow-inner">
            <button type="submit" class="w-11 h-11 bg-blue-600 text-white rounded-full flex items-center justify-center shrink-0 shadow-md active:scale-90 transition-transform bouncy-hover">
                <i class="fa-solid fa-paper-plane text-xs"></i>
            </button>
        </form>
    </div>
</main>
@endsection

@push('scripts')
<script>
    let selectedUserId = null;
    let lastMessageCount = 0;
    let pollingInterval = null;

    const chatBox = document.getElementById('chatBox');
    const msgInput = document.getElementById('messageInput');
    const chatForm = document.getElementById('chatForm');

    function playIncomingBeep() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, now);
            osc.frequency.setValueAtTime(880.00, now + 0.1);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.25);
        } catch(e) {}
    }

    function loadActiveChatUsers() {
        fetch("{{ route('admin.chat.list') }}")
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let html = '';
                    data.chats.forEach(u => {
                        const isExternal = u.profile_pic && (u.profile_pic.startsWith('http://') || u.profile_pic.startsWith('https://'));
                        const pic = isExternal ? u.profile_pic : `{{ asset('uploads') }}/${u.profile_pic || 'default_avatar.png'}`;
                        const countBadge = u.unread_count > 0 
                            ? `<span class="bg-blue-600 text-white w-5 h-5 rounded-full flex items-center justify-center text-[9px] font-black animate-pulse shrink-0">${u.unread_count}</span>` 
                            : '';
                        
                        html += `
                        <div onclick="openUserConversation(${u.id}, '${escapeHTML(u.username)}', '${escapeHTML(u.full_name)}', '${pic}')" class="chat-user-row bg-white p-4 flex justify-between items-center cursor-pointer hover:bg-slate-50 transition-colors active:scale-95 duration-100 border-b border-slate-100">
                            <div class="flex items-center gap-3 min-w-0">
                                <img src="${pic}" class="w-10 h-10 rounded-full object-cover shrink-0 bg-slate-50 border border-slate-200 shadow-sm">
                                <div class="min-w-0">
                                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide truncate w-36">${escapeHTML(u.full_name || u.username)}</h4>
                                    <span class="text-[9px] text-slate-400 font-bold block mt-0.5 truncate w-40">${escapeHTML(u.last_msg || 'No messages')}</span>
                                </div>
                            </div>
                            <div class="text-right shrink-0 flex flex-col items-end gap-1">
                                <span class="text-[7px] text-slate-400 font-bold uppercase tracking-wider block">${u.last_time || ''}</span>
                                ${countBadge}
                            </div>
                        </div>`;
                    });

                    if (data.chats.length === 0) {
                        html = `<div class="text-center py-20 p-8 mx-auto"><span class="text-4xl block mb-2">💬</span><p class="text-[9px] font-black uppercase tracking-widest text-slate-400">No active threads found.</p></div>`;
                    }
                    
                    document.getElementById('usersContainer').innerHTML = html;
                }
            });
    }

    function filterChatUsers(val) {
        const query = val.toLowerCase().trim();
        document.querySelectorAll('.chat-user-row').forEach(row => {
            const text = row.innerText.toLowerCase();
            if (text.includes(query)) {
                row.classList.remove('hidden');
            } else {
                row.classList.add('hidden');
            }
        });
    }

    function openUserConversation(userId, username, fullName, picUrl) {
        selectedUserId = userId;
        lastMessageCount = 0;
        document.getElementById('active-user-name').innerText = fullName || username;
        document.getElementById('active-user-pic').src = picUrl;
        document.getElementById('pane-conversation').classList.remove('translate-x-full');
        syncChatFeed();
        clearInterval(pollingInterval);
        pollingInterval = setInterval(syncChatFeed, 2000);
    }

    function backToUserList() {
        selectedUserId = null;
        clearInterval(pollingInterval);
        document.getElementById('pane-conversation').classList.add('translate-x-full');
        loadActiveChatUsers();
    }

    function syncChatFeed() {
        if (!selectedUserId) return;
        fetch(`{{ route('admin.chat.messages') }}?user_id=${selectedUserId}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    let html = '';
                    const messages = data.messages;
                    messages.forEach(msg => {
                        if (msg.is_admin === 1) {
                            const seenIcon = msg.is_seen === 1 ? '<i class="fa-solid fa-check-double text-blue-300 ml-1"></i>' : '<i class="fa-solid fa-check text-white/50 ml-1"></i>';
                            html += `<div class="self-end bg-gradient-to-br from-blue-500 to-indigo-650 text-white px-4 py-2.5 rounded-2xl rounded-tr-none shadow-sm max-w-[80%] my-1 shrink-0"><p class="text-xs font-semibold leading-relaxed break-all">${escapeHTML(msg.message)}</p><div class="flex items-center justify-end gap-1 mt-1 opacity-80"><span class="text-[7px] font-bold uppercase tracking-wider">${msg.msg_time}</span>${seenIcon}</div></div>`;
                        } else {
                            html += `<div class="self-start bg-white border border-slate-200 text-slate-700 px-4 py-2.5 rounded-2xl rounded-tl-none shadow-sm max-w-[80%] my-1 shrink-0"><p class="text-xs font-semibold leading-relaxed break-all">${escapeHTML(msg.message)}</p><div class="text-left mt-1 opacity-85"><span class="text-[7px] text-slate-400 font-bold uppercase tracking-wider">${msg.msg_time}</span></div></div>`;
                        }
                    });
                    chatBox.innerHTML = html;
                    
                    if (messages.length > lastMessageCount) {
                        const lastMsg = messages[messages.length - 1];
                        if (lastMsg.is_admin === 0) {
                            playIncomingBeep();
                        }
                        scrollToBottom();
                    }
                    lastMessageCount = messages.length;
                }
            });
    }

    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const text = msgInput.value.trim();
        if (text === '' || !selectedUserId) return;
        msgInput.value = '';
        
        const payload = new FormData();
        payload.append('user_id', selectedUserId);
        payload.append('message', text);
        payload.append('_token', '{{ csrf_token() }}');
        
        fetch("{{ route('admin.chat.send') }}", { method: 'POST', body: payload })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                syncChatFeed();
            } else {
                alert('Failed to send message: ' + data.message);
            }
        });
    });

    function scrollToBottom() {
        chatBox.scrollTo({ top: chatBox.scrollHeight, behavior: 'smooth' });
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag));
    }

    document.addEventListener('DOMContentLoaded', () => {
        loadActiveChatUsers();
        setInterval(loadActiveChatUsers, 4000);
    });
</script>
@endpush