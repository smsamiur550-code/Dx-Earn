@extends('layouts.admin')

@section('title', 'Voucher Feed - DX EARN')
@section('page_title', 'Voucher Feed ⚙️')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <form method="POST" action="{{ route('admin.withdraw_feed.generate_fake') }}">
        @csrf
        <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-amber">
            ⚡ Generate Simulated Payout
        </button>
    </form>

    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-gears text-blue-500"></i> Feed & Ticket Range Settings</h3>
        <form method="POST" action="{{ route('admin.withdraw_feed.settings') }}" class="space-y-4">
            @csrf
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Live Feed status</label>
                <select name="live_feed_status" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-505">
                    <option value="1" {{ $feedStatusVal === '1' ? 'selected' : '' }}>Enabled / Active</option>
                    <option value="0" {{ $feedStatusVal === '0' ? 'selected' : '' }}>Disabled / Hidden</option>
                </select>
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Ticket start numbering range</label>
                <input type="number" name="withdraw_ticket_start" value="{{ $ticketStartVal }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md bouncy-hover">Save Configurations</button>
        </form>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1">Live Feed Ledger (50 Per Page)</h3>
        <div class="space-y-3">
            @foreach ($feedWithdrawals as $w)
                @php 
                    $status = strtolower($w->status);
                    $badge = 'bg-amber-50 text-amber-600 border border-amber-200/50';
                    if ($status === 'approved' || $status === 'completed') {
                        $badge = 'bg-emerald-50 text-emerald-600 border-emerald-250/50';
                    } elseif ($status === 'cancelled' || $status === 'rejected') {
                        $badge = 'bg-rose-50 text-rose-600 border-rose-250/50';
                    }
                @endphp
                <div class="bg-white border border-slate-200 p-4 rounded-2xl shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 min-w-0">
                        <!-- Blade Escaping bug fixed here -->
                        <h4 class="text-xs font-black text-slate-800">{{ htmlspecialchars($w->username ?? 'user') }}</h4>
                        <span class="text-[8px] text-slate-400 font-bold block truncate w-44">Gateway: {{ htmlspecialchars($w->payment_method) }} ({{ htmlspecialchars($w->account_number) }})</span>
                        <span class="text-[8px] text-slate-400 font-bold block mt-0.5">Submitted: {{ $w->requested_at ? $w->requested_at->format('d M Y, h:i A') : '' }}</span>
                        <span class="text-[8px] font-black text-blue-700 block mt-0.5">Ticket ID: #{{ htmlspecialchars($w->ticket_number ?? '0') }}</span>
                    </div>
                    <div class="text-right shrink-0">
                        <span class="text-[8px] font-black {{ $badge }} border px-2 py-0.5 rounded uppercase tracking-wider mb-1 block w-fit ml-auto">{{ $w->status }}</span>
                        <span class="font-black text-emerald-600 block text-xs">$ {{ number_format($w->amount, 2) }}</span>
                    </div>
                </div>
            @endforeach
            @if ($feedWithdrawals->isEmpty())
                <p class="text-center text-slate-455 text-[10px] font-bold uppercase tracking-wider py-8">No live payout records logged.</p>
            @endif
        </div>
    </div>

    <!-- Pagination links -->
    <div class="flex gap-2">
        @if ($page > 1)
            <a href="{{ route('admin.withdraw_feed', ['page' => $page - 1]) }}" class="flex-1 text-center py-3 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-500 rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover">Previous Page</a>
        @endif
        @if ($page < $totalPages)
            <a href="{{ route('admin.withdraw_feed', ['page' => $page + 1]) }}" class="flex-1 text-center py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover">Next 50 Entries ➔</a>
        @endif
    </div>
</main>
@endsection