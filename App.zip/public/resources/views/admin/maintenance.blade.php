@extends('layouts.admin')

@section('title', 'Maintenance - DX EARN')
@section('page_title', 'Maintenance 🧹')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    <div class="flex gap-4 overflow-x-auto px-4 bg-white border border-slate-200 rounded-2xl py-3 shrink-0 scrollbar-none">
        <button onclick="switchMaintTab('cleanup')" id="btn-cleanup" class="pb-1 text-xs uppercase tracking-wider font-extrabold text-blue-600 border-b-2 border-blue-600 shrink-0">Database Cleanup</button>
        <button onclick="switchMaintTab('media')" id="btn-media" class="pb-1 text-xs uppercase tracking-wider font-extrabold text-slate-400 shrink-0">Storage Cleanup</button>
    </div>

    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <!-- Tab 1: Database Cleanup -->
    <div id="tab-cleanup-pane" class="tab-pane space-y-4">
        <div class="bg-white/80 border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-database text-blue-500"></i> Auto-Delete Intervals (Days)</h3>
            <form method="POST" action="{{ route('admin.maintenance.cleanup') }}" class="space-y-4">
                @csrf
                
                <div class="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-100 rounded-2xl shadow-inner">
                    <span class="text-[10px] font-black text-slate-700 uppercase tracking-wider">Enable Automated Cleanups</span>
                    <input type="checkbox" name="cleanup_enabled" value="1" {{ $cleanup_enabled_val === 1 ? 'checked' : '' }} class="rounded text-blue-600 focus:ring-0">
                </div>

                <div class="grid grid-cols-2 gap-3.5">
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Ad Views History</label>
                        <input type="number" name="cleanup_ad_views_days" value="{{ $cleanup_ad_views_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Game History Logs</label>
                        <input type="number" name="cleanup_game_history_days" value="{{ $cleanup_game_history_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3.5">
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Daily Game Plays</label>
                        <input type="number" name="cleanup_game_plays_days" value="{{ $cleanup_game_plays_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Promo Claims History</label>
                        <input type="number" name="cleanup_gift_claims_days" value="{{ $cleanup_gift_claims_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3.5">
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Completed Missions</label>
                        <input type="number" name="cleanup_tasks_days" value="{{ $cleanup_tasks_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Support Chats Logs</label>
                        <input type="number" name="cleanup_chats_days" value="{{ $cleanup_chats_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3.5">
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Lottery Tickets Logs</label>
                        <input type="number" name="cleanup_tickets_days" value="{{ $cleanup_tickets_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Cloud Mining Logs</label>
                        <input type="number" name="cleanup_mining_days" value="{{ $cleanup_mining_val }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                </div>

                <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md bouncy-hover">Save Database Intervals</button>
            </form>
        </div>
    </div>

    <!-- Tab 2: Storage Cleanup -->
    <div id="tab-media-pane" class="tab-pane space-y-4 hidden">
        <div class="bg-white/80 border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-broom text-rose-500"></i> Clean Orphan Media Uploads</h3>
            <p class="text-[10px] text-slate-500 font-semibold leading-relaxed">Deletes unreferenced files inside <code>/uploads/</code>, <code>/uploads/kyc_docs/</code>, and <code>/uploads/payments/</code> that do not belong to active users, payments, or kyc rows. Safe and space-saving!</p>
            
            <form method="POST" action="{{ route('admin.maintenance.clean_orphans') }}" onsubmit="return confirm('⚠️ Clean Media Directories?\n\nThis will scan and delete unused avatar copies and screenshots from server disk space permanently.');">
                @csrf
                <button type="submit" class="w-full py-4 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-rose">⚡ Run Storage Media Scan</button>
            </form>
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function switchMaintTab(tab) {
        const panes = document.querySelectorAll('.tab-pane');
        panes.forEach(p => p.classList.add('hidden'));

        const activePane = document.getElementById(`tab-${tab}-pane`);
        if (activePane) activePane.classList.remove('hidden');

        const buttons = document.querySelectorAll('button[id^="btn-"]');
        buttons.forEach(b => b.className = "pb-1 text-xs uppercase tracking-wider font-extrabold text-slate-400 shrink-0");

        const activeBtn = document.getElementById(`btn-${tab}`);
        if (activeBtn) activeBtn.className = "pb-1 text-xs uppercase tracking-wider font-extrabold text-blue-600 border-b-2 border-blue-600 shrink-0";
    }
</script>
@endpush