@extends('layouts.admin')

@section('title', 'Deposits Audit - DX EARN')
@section('page_title', 'Deposits Audit 💳')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    <div class="flex gap-4 border-b border-slate-200 bg-white px-4 py-3 rounded-2xl shadow-sm font-extrabold text-slate-400">
        <a href="{{ route('admin.payment', ['sub_tab' => 'pending']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'pending' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Pending</a>
        <a href="{{ route('admin.payment', ['sub_tab' => 'approved']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'approved' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Approved</a>
        <a href="{{ route('admin.payment', ['sub_tab' => 'rejected']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'rejected' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Rejected</a>
    </div>

    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="space-y-4">
        @foreach ($depositsList as $pay)
            @php 
                $meta = json_decode($pay->meta_data, true) ?: [];
                $badge = 'bg-amber-50 text-amber-600 border-amber-200/50';
                if ($pay->status === 'approved') {
                    $badge = 'bg-emerald-50 text-emerald-600 border-emerald-250/50';
                } elseif ($pay->status === 'rejected') {
                    $badge = 'bg-rose-50 text-rose-600 border-rose-250/50';
                }
            @endphp
            <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4 animate-fadeIn">
                <div class="flex justify-between items-start">
                    <div class="flex items-center gap-3">
                        <img src="{{ asset('uploads/' . $pay->screenshot_pic) }}" class="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-100 shadow-sm">
                        <div>
                            <!-- Blade Escaping bug fixed here -->
                            <h4 class="text-xs font-black text-slate-800 uppercase">{{ htmlspecialchars($pay->username) }}</h4>
                            <span class="text-[8px] text-slate-400 font-bold block mt-1">Submitted: {{ $pay->created_at ? $pay->created_at->format('d M Y • h:i A') : '' }}</span>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="text-sm font-black text-emerald-600 block">$ {{ number_format($pay->amount, 2) }}</span>
                        <span class="text-[8px] font-black border {{ $badge }} px-2 py-0.5 rounded uppercase block tracking-wider mt-1 text-center">{{ htmlspecialchars($pay->status) }}</span>
                    </div>
                </div>
                <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-150 text-[9px] text-slate-550 font-bold uppercase space-y-1 shadow-inner">
                    <div>Type: <strong class="text-slate-800">{{ strtoupper(htmlspecialchars($pay->payment_type)) }}</strong></div>
                    <div>Description: <strong class="text-slate-800 leading-normal">{{ htmlspecialchars($meta['description'] ?? 'General Deposit') }}</strong></div>
                    @if ($pay->payment_type === 'coin_to_token' && isset($meta['amount_coin']))
                        <div>Coin Amount: <strong class="text-amber-600">🪙 {{ number_format($meta['amount_coin'], 2) }}</strong></div>
                        <div>Tokens Est: <strong class="text-blue-600">💵 {{ number_format($meta['tokens'] ?? 0, 2) }}</strong></div>
                    @endif
                </div>
                <div class="flex gap-2 pt-1.5">
                    <button onclick="openLightbox('{{ asset('uploads/payments/' . $pay->screenshot_pic) }}')" class="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 text-center rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover border border-slate-200">View Proof 🖼️</button>
                    @if ($pay->status === 'pending')
                        <form method="POST" action="{{ route('admin.payment.audit') }}" class="flex-1">
                            @csrf
                            <input type="hidden" name="payment_id" value="{{ $pay->id }}">
                            <input type="hidden" name="payment_action" value="approve">
                            <button type="submit" class="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover btn-glow-emerald">Approve ⚡</button>
                        </form>
                        <form method="POST" action="{{ route('admin.payment.audit') }}" class="flex-1">
                            @csrf
                            <input type="hidden" name="payment_id" value="{{ $pay->id }}">
                            <input type="hidden" name="payment_action" value="reject">
                            <button type="submit" class="w-full py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/50 rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover">Reject</button>
                        </form>
                    @endif
                </div>
            </div>
        @endforeach
        @if ($depositsList->isEmpty())
            <div class="text-center py-12 bg-white border border-slate-200 rounded-[2rem] p-8 shadow-sm">
                <p class="text-[10px] text-slate-455 font-bold uppercase tracking-wider">No deposit audit entries located.</p>
            </div>
        @endif
    </div>
</main>

<!-- Lightbox Modal -->
<div id="lightboxModal" class="hidden fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
    <div class="relative max-w-sm w-full bg-white rounded-3xl p-3 border border-slate-100 flex flex-col items-center">
        <button onclick="closeLightbox()" class="absolute -top-3 -right-3 w-8 h-8 bg-white border border-slate-200 rounded-full flex items-center justify-center text-slate-500 hover:text-slate-800 shadow-md transition-all text-sm z-50"><i class="fa-solid fa-times"></i></button>
        <img id="lightboxImage" src="" class="w-full h-auto max-h-[70vh] object-contain rounded-2xl">
    </div>
</div>
@endsection

@push('scripts')
<script>
    function openLightbox(src) {
        document.getElementById('lightboxImage').src = src;
        document.getElementById('lightboxModal').classList.remove('hidden');
    }

    function closeLightbox() {
        document.getElementById('lightboxModal').classList.add('hidden');
    }
</script>
@endpush