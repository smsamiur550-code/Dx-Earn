@extends('layouts.admin')

@section('title', 'VIP Configuration - DX EARN')
@section('page_title', 'VIP Config 👑')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4 animate-fadeIn">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-circle-plus text-amber-500"></i> Deploy / Edit VIP Card</h3>
        <form method="POST" action="{{ route('admin.vip.save') }}" class="space-y-4" id="vipForm">
            @csrf
            <input type="hidden" name="plan_id" id="plan_id" value="0">
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Card Name 🏷️</label>
                <input type="text" name="name" id="name" placeholder="E.g. Gold Node Booster" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Price (in Tokens)</label>
                    <input type="number" step="0.01" name="price" id="price" placeholder="500.00 Tokens" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Duration (Days) 📅</label>
                    <input type="number" name="duration_days" id="duration_days" placeholder="30" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Benefits Description 📋</label>
                <textarea name="description" id="benefits" rows="2" placeholder="Detail perks items list..." class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner"></textarea>
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-wider shadow-md bouncy-hover btn-glow-blue">
                Save VIP Card Settings
            </button>
        </form>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1">Configured Cards</h3>
        <div class="space-y-3.5">
            @foreach ($vipPlans as $plan)
                @php $planBase64 = base64_encode(json_encode($plan)); @endphp
                <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm flex flex-col justify-between relative overflow-hidden">
                    <div class="flex justify-between items-start">
                        <div class="space-y-0.5">
                            <h4 class="font-black text-slate-800 text-sm tracking-wider uppercase">{{ htmlspecialchars($plan->name) }}</h4>
                            <span class="text-[8px] font-bold uppercase text-slate-400">Duration: {{ $plan->duration_days }} Days • Price: <strong class="text-amber-500">💵 {{ number_format($plan->price, 2) }}</strong></span>
                            <div class="flex gap-1.5 pt-1.5 text-[8px] font-black uppercase text-slate-455">
                                <span>Mining Speed: {{ $plan->faster_mining_speed }}x</span>
                                <span>•</span>
                                <span>Daily Games: 2x</span>
                            </div>
                        </div>
                        <div class="flex gap-1">
                            <button onclick="populateEdit('{{ $planBase64 }}')" class="w-8 h-8 bg-blue-50/50 text-blue-600 border border-blue-100/30 rounded-xl flex items-center justify-center text-xs hover:bg-blue-100 active:scale-95 transition-all shadow-inner">
                                <i class="fa-solid fa-pen"></i>
                            </button>
                            <form method="POST" action="{{ route('admin.vip.delete') }}" onsubmit="return confirm('Terminate this plan permanently?');" class="shrink-0">
                                @csrf
                                <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                                <button type="submit" class="w-8 h-8 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center text-xs hover:bg-rose-100 bouncy-hover transition-all">
                                    <i class="fa-regular fa-trash-can"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function populateEdit(planBase64) {
        const plan = JSON.parse(atob(planBase64));

        document.getElementById('plan_id').value = plan.id;
        document.getElementById('name').value = plan.name;
        document.getElementById('price').value = plan.price;
        document.getElementById('duration_days').value = plan.duration_days;
        document.getElementById('benefits').value = plan.benefits;

        document.getElementById('vipForm').scrollIntoView({ behavior: 'smooth' });
    }
</script>
@endpush