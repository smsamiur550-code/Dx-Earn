@extends('layouts.admin')

@section('title', 'Products Directory - DX EARN')
@section('page_title', 'Inventory 📦')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <!-- Category Setup -->
    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-tags text-emerald-500"></i> Manage Store Categories</h3>
        <form method="POST" action="{{ route('admin.products.category.add') }}" class="flex gap-2">
            @csrf
            <input type="text" name="category_name" placeholder="E.g. Electronics 📱" required class="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-slate-800 shadow-inner">
            <button type="submit" class="px-5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase bouncy-hover btn-glow-blue">Add</button>
        </form>

        @if(!$categories->isEmpty())
            <div class="flex flex-wrap gap-2 pt-2">
                @foreach ($categories as $cat)
                    <div class="bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-xl text-[9px] font-black uppercase text-slate-600 flex items-center gap-2 shadow-sm">
                        <span>{{ htmlspecialchars($cat->name) }}</span>
                        <form method="POST" action="{{ route('admin.products.category.delete') }}" class="inline" onsubmit="return confirm('Delete this category?');">
                            @csrf
                            <input type="hidden" name="category_id" value="{{ $cat->id }}">
                            <button type="submit" class="text-rose-500 hover:text-rose-600 active:scale-75 transition-transform"><i class="fa-solid fa-xmark"></i></button>
                        </form>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    <!-- Product Setup Form -->
    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4 animate-fadeIn">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest" id="form-title"><i class="fa-solid fa-circle-plus text-indigo-500"></i> Publish / Edit Product</h3>
        <form method="POST" action="{{ route('admin.products.save') }}" enctype="multipart/form-data" class="space-y-4" id="productForm">
            @csrf
            <input type="hidden" name="product_id" id="product_id" value="0">
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Product Name 🏷️</label>
                <input type="text" name="name" id="name" placeholder="E.g. Xiaomi Node Booster Card" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Price (৳ / $)</label>
                    <input type="number" step="0.01" name="price" id="price" placeholder="1000.00" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Stock Count 📦</label>
                    <input type="number" name="stock" id="stock" placeholder="25" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Category</label>
                <select name="category_id" id="category_id" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2.5 text-xs font-bold outline-none text-slate-500">
                    <option value="">No Category</option>
                    @foreach ($categories as $cat)
                        <option value="{{ $cat->id }}">{{ htmlspecialchars($cat->name) }}</option>
                    @endforeach
                </select>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Company / Brand Name 🏢</label>
                    <input type="text" name="company_name" id="company_name" placeholder="E.g. Apple Inc." class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Company Logo File 📸</label>
                    <input type="file" name="company_logo_file" accept="image/*" class="text-xs text-slate-500 file:mr-1.5 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[9px] file:font-black file:bg-blue-50 file:text-blue-600 w-full bg-slate-50 border border-slate-200 p-1.5 rounded-xl shadow-inner">
                </div>
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Main Product Photo 📸</label>
                <input type="file" name="product_img" accept="image/*" class="text-xs text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-xl file:border-0 file:text-[9px] file:font-black file:bg-blue-50 file:text-blue-600 w-full bg-slate-50 border border-slate-200 p-1.5 rounded-xl shadow-inner">
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Product Description & Specs 📋</label>
                <textarea name="description" id="description" placeholder="Technical specifications details list..." rows="2" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner"></textarea>
            </div>
            <button type="submit" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">Publish / Save Product</button>
        </form>
    </div>

    <!-- Inventory List -->
    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1">Store Inventory Directory</h3>
        <div class="space-y-3.5">
            @foreach ($products as $p)
                @php $pBase64 = base64_encode(json_encode($p)); @endphp
                <div class="bg-white border border-slate-200 p-4 rounded-[2rem] shadow-sm flex justify-between items-center text-xs hover:shadow-md transition-shadow">
                    <div class="flex items-center gap-3 min-w-0">
                        <img src="{{ asset('uploads/' . ($p->image ?? 'default.png')) }}" class="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-100 bg-slate-50 shadow-sm">
                        <div class="min-w-0 text-left">
                            <h4 class="font-black text-slate-700 text-xs tracking-wide uppercase truncate w-32">{{ htmlspecialchars($p->name) }}</h4>
                            <span class="text-[8px] font-bold uppercase text-slate-455 block mt-0.5">Price: <strong class="text-emerald-600">💲 {{ number_format($p->price, 2) }}</strong> • Stock: {{ $p->stock }}</span>
                            <div class="flex flex-wrap gap-1.5 mt-1.5">
                                <span class="inline-block bg-slate-50 text-slate-600 px-2 py-0.5 rounded text-[7px] font-black uppercase border border-slate-200 shadow-sm">{{ htmlspecialchars($p->company_name ?: 'Official Brand') }}</span>
                                @if (!empty($p->category_name))
                                    <span class="inline-block bg-blue-50 text-blue-600 px-2 py-0.5 rounded text-[7px] font-black uppercase tracking-wider border border-blue-100/30">{{ htmlspecialchars($p->category_name) }}</span>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="flex gap-1 shrink-0">
                        <button onclick="populateProductEdit('{{ $pBase64 }}')" class="w-8 h-8 bg-blue-50/50 text-blue-600 border border-blue-100/30 rounded-xl flex items-center justify-center text-xs hover:bg-blue-100 active:scale-95 duration-100 transition-all shadow-inner">
                            <i class="fa-solid fa-pen"></i>
                        </button>
                        <form method="POST" action="{{ route('admin.products.delete') }}" onsubmit="return confirm('Delete this product permanently?');">
                            @csrf
                            <input type="hidden" name="product_id" value="{{ $p->id }}">
                            <button type="submit" class="w-8 h-8 bg-rose-50/50 text-rose-500 border border-rose-100/30 rounded-xl flex items-center justify-center text-xs hover:bg-rose-100 active:scale-95 duration-100 transition-all">
                                <i class="fa-regular fa-trash-can"></i>
                            </button>
                        </form>
                    </div>
                </div>
            @endforeach
            @if ($products->isEmpty())
                <p class="text-center text-[10px] text-slate-455 font-bold uppercase tracking-wider py-8 bg-white border border-slate-200 rounded-[2rem] shadow-sm">No products found in directory.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function populateProductEdit(pBase64) {
        const p = JSON.parse(atob(pBase64));
        document.getElementById('product_id').value = p.id;
        document.getElementById('name').value = p.name;
        document.getElementById('price').value = p.price;
        document.getElementById('stock').value = p.stock;
        document.getElementById('description').value = p.description;
        document.getElementById('category_id').value = p.category_id || "";
        document.getElementById('company_name').value = p.company_name || "";

        document.getElementById('form-title').innerHTML = `<i class="fa-solid fa-pen-to-square text-indigo-500"></i> Edit Product Parameters`;
        document.getElementById('productForm').scrollIntoView({ behavior: 'smooth' });
    }
</script>
@endpush