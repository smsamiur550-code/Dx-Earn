@extends('layouts.admin')

@section('title', 'Shop Orders - DX EARN')
@section('page_title', 'Shop Orders 🚚')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    <div class="flex gap-1.5 bg-white border border-slate-200 p-1.5 rounded-2xl shadow-sm shrink-0 overflow-x-auto no-scrollbar">
        <a href="{{ route('admin.orders', ['sub_tab' => 'pending']) }}" class="flex-1 py-2 rounded-xl text-[8px] font-black uppercase text-center text-slate-505 {{ $currentSubTab === 'pending' ? 'bg-blue-600 text-white font-black' : '' }}">Pending</a>
        <a href="{{ route('admin.orders', ['sub_tab' => 'processing']) }}" class="flex-1 py-2 rounded-xl text-[8px] font-black uppercase text-center text-slate-505 {{ $currentSubTab === 'processing' ? 'bg-blue-600 text-white font-black' : '' }}">Processing</a>
        <a href="{{ route('admin.orders', ['sub_tab' => 'on_way']) }}" class="flex-1 py-2 rounded-xl text-[8px] font-black uppercase text-center text-slate-505 {{ $currentSubTab === 'on_way' ? 'bg-blue-600 text-white font-black' : '' }}">On Way</a>
        <a href="{{ route('admin.orders', ['sub_tab' => 'completed']) }}" class="flex-1 py-2 rounded-xl text-[8px] font-black uppercase text-center text-slate-505 {{ $currentSubTab === 'completed' ? 'bg-blue-600 text-white font-black' : '' }}">Delivered</a>
        <a href="{{ route('admin.orders', ['sub_tab' => 'cancelled']) }}" class="flex-1 py-2 rounded-xl text-[8px] font-black uppercase text-center text-slate-505 {{ $currentSubTab === 'cancelled' ? 'bg-blue-600 text-white font-black' : '' }}">Cancelled</a>
    </div>

    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="space-y-4">
        @foreach ($orders as $o) 
            @php
                $clean_name = str_replace(["\r", "\n", "'", '"'], " ", $o->name);
                $clean_phone = str_replace(["\r", "\n", "'", '"'], " ", $o->phone);
                $clean_address = str_replace(["\r", "\n", "'", '"'], " ", $o->address);
                $clean_product_name = str_replace(["\r", "\n", "'", '"'], " ", $o->product_name);
            @endphp
            <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4 animate-fadeIn">
                <div class="flex justify-between items-start">
                    <div class="flex items-center gap-3">
                        <img src="{{ asset('uploads/' . $o->product_image) }}" class="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-100 shadow-sm">
                        <div>
                            <h4 class="text-xs font-black text-slate-700 uppercase tracking-wide truncate w-40">{{ $o->product_name }}</h4>
                            <!-- Blade Escaping bug fixed here -->
                            <span class="text-[8px] text-slate-400 font-bold block mt-1">Ordered By: {{ htmlspecialchars($o->username) }}</span>
                            <span class="text-[8px] text-slate-455 font-bold block">Ref ID: #{{ $o->id }}</span>
                        </div>
                    </div>
                    <span class="text-sm font-black text-emerald-600">$ {{ number_format($o->total_price, 2) }}</span>
                </div>

                <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-150 space-y-1.5 text-[10px] text-slate-550 font-bold uppercase leading-normal shadow-inner">
                    <div>Recipient Name: <strong class="text-slate-700">{{ htmlspecialchars($o->name) }}</strong></div>
                    <div>Phone Address: <strong class="text-slate-700 font-mono">{{ htmlspecialchars($o->phone) }}</strong></div>
                    <div class="whitespace-normal break-all text-left">Address: <strong class="text-slate-700 leading-normal lowercase first-letter:uppercase">{{ htmlspecialchars($o->address) }}</strong></div>
                    <div class="pt-1.5 mt-1.5 border-t border-slate-150 space-y-1 text-[8px] font-black text-slate-455">
                        <div class="flex justify-between"><span>Deducted Tokens</span><span class="text-amber-600">- 💵 {{ number_format($o->coin_deducted, 2) }} ({{ $o->coin_percentage }}%)</span></div>
                        <div class="flex justify-between"><span>Remaining Cash discount</span><span class="text-indigo-650">- $ {{ number_format($o->discount_cash, 2) }}</span></div>
                        <div class="flex justify-between"><span>Delivery Charge ({{ $o->delivery_location }})</span><span class="text-slate-700">+ $ {{ number_format($o->delivery_charge, 2) }}</span></div>
                        <div class="flex justify-between border-t border-slate-150 pt-1 text-[9px] text-slate-800 font-black"><span>Subtotal COD Cash Due</span><span class="text-emerald-600">{{ number_format($o->cod_amount * $takaRate, 2) }} ৳</span></div>
                    </div>
                </div>

                <div class="flex gap-2 pt-1 border-t border-slate-100">
                    <button type="button" onclick="printInvoice(
                        '{{ $o->id }}',
                        '{{ addslashes($clean_name) }}',
                        '{{ addslashes($clean_phone) }}',
                        '{{ addslashes($clean_address) }}',
                        '{{ addslashes($clean_product_name) }}',
                        '{{ number_format($o->total_price * $takaRate, 2) }}',
                        '{{ number_format($o->coin_deducted, 2) }}',
                        '{{ number_format($o->delivery_charge * $takaRate, 2) }}',
                        '{{ number_format($o->cod_amount * $takaRate, 2) }}',
                        '{{ $o->created_at ? $o->created_at->format(\'d M Y h:i A\') : \'\' }}',
                        '{{ htmlspecialchars($o->ticket_number ?: \'N/A\') }}'
                    )" class="flex-grow py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[9px] font-black uppercase tracking-wider bouncy-hover flex items-center justify-center gap-1.5">🖨️ Print Receipt</button>
                    
                    <form method="POST" action="{{ route('admin.orders.delete') }}" onsubmit="return confirm('Confirm order deletion? associated tickets will be erased too.');">
                        @csrf
                        <input type="hidden" name="order_id" value="{{ $o->id }}">
                        <input type="hidden" name="sub_tab" value="{{ $currentSubTab }}">
                        <button type="submit" class="w-10 h-10 bg-rose-50 hover:bg-rose-100 text-rose-500 border border-rose-100 rounded-xl flex items-center justify-center text-xs active:scale-95 transition-all shadow-inner">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </form>

                    @if ($o->status !== 'completed' && $o->status !== 'cancelled')
                        <form method="POST" action="{{ route('admin.orders.audit') }}" class="flex-grow flex gap-2">
                            @csrf
                            <input type="hidden" name="order_id" value="{{ $o->id }}">
                            <input type="hidden" name="sub_tab" value="{{ $currentSubTab }}">
                            <select name="order_status" required class="flex-grow bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-2 text-[9px] font-black text-slate-505 outline-none">
                                <option value="pending" {{ $o->status === 'pending' ? 'selected' : '' }}>Pending</option>
                                <option value="processing" {{ $o->status === 'processing' ? 'selected' : '' }}>Processing</option>
                                <option value="on_way" {{ $o->status === 'on_way' ? 'selected' : '' }}>On Way</option>
                                <option value="completed" {{ $o->status === 'completed' ? 'selected' : '' }}>Delivered</option>
                                <option value="cancelled" {{ $o->status === 'cancelled' ? 'selected' : '' }}>Cancelled</option>
                            </select>
                            <button type="submit" class="px-3 bg-blue-600 text-white rounded-xl text-[9px] font-black uppercase bouncy-hover btn-glow-blue">Save</button>
                        </form>
                    @endif
                </div>
            </div>
        @endforeach
        @if ($orders->isEmpty())
            <div class="text-center py-12 bg-white border border-slate-200 rounded-[2rem] p-8 shadow-sm">
                <p class="text-[10px] text-slate-455 font-bold uppercase tracking-wider">No orders found.</p>
            </div>
        @endif
    </div>
</main>
@endsection

@push('scripts')
<script>
    function printInvoice(id, name, phone, address, product, total, discount, delivery, cod, date, ticket) {
        const printWindow = window.open('', '_blank', 'width=600,height=600');
        printWindow.document.write(`
            <html>
            <head>
                <title>Invoice - #${id}</title>
                <style>
                    body { font-family: monospace; padding: 20px; color: #000; line-height: 1.4; font-size: 11px; }
                    .text-center { text-align: center; }
                    .divider { border-top: 1px dashed #000; margin: 10px 0; }
                    .flex { display: flex; justify-content: space-between; }
                    .font-bold { font-weight: bold; }
                    .mb-5 { margin-bottom: 5px; }
                </style>
            </head>
            <body onload="window.print(); window.close();">
                <div class="text-center font-bold" style="font-size: 14px;">DX EARN OFFICIAL STORE</div>
                <div class="divider"></div>
                <div class="flex"><span>Order Reference:</span><span class="font-bold">#ORD-\${id}</span></div>
                <div class="flex"><span>Issue Date:</span><span>\${date}</span></div>
                <div class="flex"><span>Sweepstakes Code:</span><span class="font-bold">\${ticket}</span></div>
                <div class="divider"></div>
                <div class="font-bold mb-5">RECIPIENT PARAMETERS:</div>
                <div>Name: \${name}</div>
                <div>Phone: \${phone}</div>
                <div style="word-wrap: break-word; max-width: 100%;">Shipping Destination: \${address}</div>
                <div class="divider"></div>
                <div class="font-bold mb-5">LINE TRANSACTION ITEMS:</div>
                <div class="flex"><span class="font-bold">\${product}</span><span>x 1</span></div>
                <div class="flex"><span>Original Base Price:</span><span>\${total} ৳</span></div>
                <div class="divider"></div>
                <div class="flex"><span>1. Token Discount Deduct:</span><span>- 💵 \${discount}</span></div>
                <div class="flex"><span>2. Shipping Carrier Fee:</span><span>+ \${delivery} ৳</span></div>
                <div class="flex font-bold" style="font-size: 12px; margin-top:5px;"><span>3. CASH ON DELIVERY SUB-DUE:</span><span>\${cod} ৳</span></div>
                <div class="divider"></div>
                <div class="text-center font-bold" style="margin-top: 15px; font-size:10px;">THANK YOU FOR YOUR VALUED PATRONAGE!</div>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
</script>
@endpush