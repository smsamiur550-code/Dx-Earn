<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>Admin Panel - Gatekeeper</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            -webkit-user-select: none; 
            user-select: none; 
            overflow: hidden;
            height: 100vh;
        }
        .bg-animate {
            background: linear-gradient(135deg, #fef08a 0%, #d9f99d 50%, #bae6fd 100%);
            background-size: 400% 400%;
            animation: flowBackground 10s ease infinite;
        }
        @keyframes flowBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .bounce-animation {
            animation: bounceSoft 2.5s ease-in-out infinite;
        }
        @keyframes bounceSoft {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-8px); }
        }
        .container-box {
            max-width: 440px;
            width: 100%;
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(20px);
            border-radius: 40px;
            box-shadow: 0 25px 55px rgba(0, 0, 0, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.7);
            padding: 2.5rem;
            animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes slideUp {
            0% { transform: translateY(30px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }
        .action-btn { transition: all 0.15s ease-in-out; }
        .action-btn:active { transform: scale(0.95); }
    </style>
</head>
<body class="bg-animate font-sans flex justify-center items-center p-4">

    <div class="container-box flex flex-col items-center justify-center text-center">
        <div class="mb-6 bounce-animation">
            <div class="w-20 h-20 bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-500 rounded-[28px] mx-auto flex items-center justify-center shadow-[0_12px_25px_rgba(99,102,241,0.2)] mb-4 border-4 border-white">
                <span class="text-4xl">👑</span>
            </div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight">Admin Portal</h1>
            <p class="text-[10px] text-indigo-650 font-black uppercase tracking-widest mt-1.5">Developer System Protection Node ✨</p>
        </div>

        @if(session('error'))
            <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2 mb-4 w-full text-left">
                <span>⚠️</span> {{ session('error') }}
            </div>
        @endif

        <form method="POST" action="{{ route('admin.login.submit') }}" class="space-y-4 w-full text-left">
            @csrf
            <div>
                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Username 👤</label>
                <input type="text" name="username" required class="w-full bg-white/80 border border-slate-150 rounded-2xl px-4 py-3.5 text-xs font-bold text-slate-800 outline-none focus:border-blue-400 focus:bg-white transition-all shadow-sm">
            </div>

            <div>
                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Password 🔑</label>
                <input type="password" name="password" required class="w-full bg-white/80 border border-slate-150 rounded-2xl px-4 py-3.5 text-xs font-bold text-slate-800 outline-none focus:border-blue-400 focus:bg-white transition-all shadow-sm">
            </div>

            <button type="submit" class="w-full py-4 bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest active:scale-95 duration-100 action-btn">
                Unlock Panel ⚡
            </button>
        </form>
    </div>

    <script>
        document.addEventListener('click', function(e) {
            const target = e.target.closest('button, a, input[type="submit"], [role="button"]');
            if (target && window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(15);
            }
        });
    </script>
</body>
</html>