@extends('layouts.admin')

@section('title', 'Platform Settings - DX EARN')
@section('page_title', 'Platform Settings ⚙️')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <form method="POST" action="{{ route('admin.settings.global') }}" class="space-y-4">
        @csrf

        <!-- Google OAuth Credentials -->
        <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-brands fa-google text-red-500"></i> Google OAuth Setup</h3>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Client ID</label>
                <input type="text" name="google_client_id" value="{{ htmlspecialchars($google_client_id) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none select-all">
            </div>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Client Secret</label>
                <input type="text" name="google_client_secret" value="{{ htmlspecialchars($google_client_secret) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none select-all">
            </div>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Redirect Callback URL</label>
                <input type="url" name="google_redirect_url" value="{{ htmlspecialchars($google_redirect_url) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none select-all">
            </div>
        </div>

        <!-- Links Setup -->
        <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-link text-blue-500"></i> Monetag & Tradingview Links</h3>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Monetag Direct Link (boost Ad)</label>
                <input type="url" name="monetag_direct_link" value="{{ htmlspecialchars($monetag_direct_link) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
            </div>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">TradingView Chart Link</label>
                <input type="text" name="live_market_link" value="{{ htmlspecialchars($live_market_link) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
            </div>
        </div>

        <!-- Rates Setup -->
        <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-arrows-spin text-emerald-500"></i> Rates & Conversion Rules</h3>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Coin to Token Rate</label>
                    <input type="number" step="0.0001" name="coin_to_token_rate" value="{{ $coin_to_token_rate }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Token to USD Rate</label>
                    <input type="number" step="0.0001" name="token_to_dollar_rate" value="{{ $token_to_dollar_rate }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">USD to BDT Rate (৳)</label>
                    <input type="number" step="0.01" name="usd_to_bdt_rate" value="{{ $usd_to_bdt_rate }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Minimum Withdraw Limit ($)</label>
                    <input type="number" step="0.01" name="min_withdraw" value="{{ $min_withdraw }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
            </div>
        </div>

        <!-- Referral Bonus Settings -->
        <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-users text-teal-500"></i> Referral Bonus Setup</h3>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Referrer Reward ($)</label>
                    <input type="number" step="0.01" name="ref_bonus_referrer" value="{{ $ref_bonus_referrer }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Referee Reward ($)</label>
                    <input type="number" step="0.01" name="ref_bonus_referee" value="{{ $ref_bonus_referee }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
            </div>
        </div>

        <!-- Customizations Setup -->
        <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-wand-magic-sparkles text-amber-500"></i> Brand & Buttons Styling</h3>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Coin Symbol</label>
                    <input type="text" name="coin_symbol" value="{{ htmlspecialchars($coin_symbol) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-center">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Token Symbol</label>
                    <input type="text" name="token_symbol" value="{{ htmlspecialchars($token_symbol) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-center">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Games Button Name</label>
                    <input type="text" name="btn_name_games" value="{{ htmlspecialchars($btn_name_games) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-center">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Mining Button Name</label>
                    <input type="text" name="btn_name_mining" value="{{ htmlspecialchars($btn_name_mining) }}" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-center">
                </div>
            </div>
        </div>

        <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">Save Global Setup</button>
    </form>

    <!-- Homepage slider editor -->
    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-images text-indigo-500"></i> Add Homepage Slider Banner</h3>
        <form method="POST" action="{{ route('admin.settings.slider.add') }}" class="space-y-4">
            @csrf
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Slider Title</label>
                <input type="text" name="title" required placeholder="E.g. Mining booster active" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
            </div>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Slider Description Text</label>
                <input type="text" name="desc_text" required placeholder="E.g. Buy a premium node now" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
            </div>
            <div class="grid grid-cols-2 gap-3.5">
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Background Gradient CSS</label>
                    <input type="text" name="grad" placeholder="from-blue-500 to-indigo-600" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-center">
                </div>
                <div>
                    <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Redirect Link URL</label>
                    <input type="text" name="redirect_url" placeholder="user/vip.php" class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
            </div>
            <button type="submit" class="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black text-xs uppercase tracking-wider bouncy-hover">Create Banner Slide</button>
        </form>

        <div class="space-y-3 pt-4 border-t border-slate-100">
            <h4 class="text-[10px] font-black uppercase text-slate-400 tracking-wider">Active homepage sliders</h4>
            <div class="space-y-2">
                @foreach ($sliders as $slide)
                    <div class="bg-slate-50 p-3 rounded-2xl border border-slate-150 flex justify-between items-center text-xs">
                        <div class="min-w-0">
                            <span class="text-[8px] font-black text-slate-455 block uppercase">Slide ID #{{ $slide->id }}</span>
                            <span class="font-black text-slate-800 block truncate w-40">{{ htmlspecialchars($slide->title) }}</span>
                            <span class="text-[8px] text-slate-400 font-bold block truncate w-44">{{ htmlspecialchars($slide->desc_text) }}</span>
                        </div>
                        <form method="POST" action="{{ route('admin.settings.slider.delete') }}" onsubmit="return confirm('Erase this home banner slide?');">
                            @csrf
                            <input type="hidden" name="slider_id" value="{{ $slide->id }}">
                            <button type="submit" class="w-7 h-7 bg-rose-50 text-rose-600 rounded-lg flex items-center justify-center hover:bg-rose-100 bouncy-hover transition-all">
                                <i class="fa-solid fa-trash-can text-[10px]"></i>
                            </button>
                        </form>
                    </div>
                @endforeach
                @if ($sliders->isEmpty())
                    <p class="text-center text-[10px] font-black text-slate-400 uppercase tracking-wider py-4">No custom sliders active.</p>
                @endif
            </div>
        </div>
    </div>
</main>
@endsection