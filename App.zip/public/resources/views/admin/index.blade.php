@extends('layouts.admin')

@section('title', 'Admin Dashboard - DX EARN')
@section('page_title', 'Dashboard 📊')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="grid grid-cols-3 gap-2.5">
        <div class="bg-white border border-slate-200 p-3 rounded-2xl shadow-sm text-center">
            <span class="text-[8px] text-slate-400 font-black block uppercase tracking-wider">Total Users 👥</span>
            <span class="text-sm font-black text-slate-800 mt-1 block">{{ number_format($totalUsers) }}</span>
            <div class="flex justify-center gap-1.5 text-[7px] font-bold text-slate-400 mt-1 uppercase">
                <span class="text-emerald-600 font-black">🟢 {{ $activeUsers }}</span>
                <span class="text-rose-500 font-black">🔴 {{ $bannedUsers }}</span>
            </div>
        </div>
        
        <div class="bg-white border border-slate-200 p-3 rounded-2xl shadow-sm text-center">
            <span class="text-[8px] text-slate-400 font-black block uppercase tracking-wider">Total Approved 💸</span>
            <span class="text-sm font-black text-emerald-600 mt-1 block">$ {{ number_format($totalWithdraw, 2) }}</span>
            <div class="flex justify-center gap-1 text-[7px] font-bold text-slate-455 mt-1 uppercase">
                <span>🪙 {{ number_format($totalCoins / 1000, 1) }}K</span>
                <span>💵 {{ number_format($totalTokens / 1000, 1) }}K</span>
            </div>
        </div>

        <div class="bg-slate-900 border-0 p-3 rounded-2xl shadow-sm text-center text-white relative overflow-hidden">
            <span class="text-[8px] text-slate-400 font-black block uppercase tracking-wider relative z-10">Pending Issues ⏳</span>
            <span class="text-sm font-black text-amber-400 mt-1 block relative z-10 animate-pulse">{{ $totalPendingRequests }} Tasks</span>
            <div class="flex justify-center gap-1 text-[6px] font-bold text-slate-400 mt-1 uppercase relative z-10">
                <span>payout: {{ $pendingWithdraw }}</span>
                <span>order: {{ $pendingOrders }}</span>
            </div>
        </div>
    </div>

    <!-- Graph Analytics -->
    <div class="bg-white border border-slate-200 p-4 rounded-[2rem] shadow-sm space-y-3">
        <div class="flex justify-between items-center px-1">
            <div class="flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <h3 class="text-[10px] font-black text-slate-800 uppercase tracking-wider">Revenue & Growth Analytics 📈</h3>
            </div>
            <span class="text-[8px] bg-slate-50 border border-slate-200/50 text-slate-500 font-black px-2.5 py-1 rounded-full uppercase tracking-wider">Weekly Trend</span>
        </div>
        <div class="w-full h-44">
            <canvas id="insightsChart"></canvas>
        </div>
    </div>

    <!-- Management Directory Nodes -->
    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1"><i class="fa-solid fa-folder-tree text-blue-600 mr-1.5"></i> Admin Command Hubs</h3>
        
        <div class="space-y-4">
            <details class="group border border-slate-150 rounded-2xl p-3 bg-slate-50/50" open>
                <summary class="list-none text-[9px] font-black text-slate-450 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                    <span>Directory Hubs</span>
                    <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                </summary>
                <div class="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200/40 mt-3">
                    <a href="{{ route('admin.users') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">👥</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Members Setup</span>
                    </a>
                    <a href="{{ route('admin.chat') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">💬</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Live Support Chat</span>
                    </a>
                    <a href="{{ route('admin.tasks') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">📝</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Missions Hub</span>
                    </a>
                    <a href="{{ route('admin.gift') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">🎁</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Promo Generator</span>
                    </a>
                </div>
            </details>

            <details class="group border border-slate-150 rounded-2xl p-3 bg-slate-50/50" open>
                <summary class="list-none text-[9px] font-black text-slate-455 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                    <span>Financial Nodes</span>
                    <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                </summary>
                <div class="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200/40 mt-3">
                    <a href="{{ route('admin.payment') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">💳</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Deposits Auditor</span>
                    </a>
                    <a href="{{ route('admin.withdraw') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">💸</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Vouchers/Payouts</span>
                    </a>
                    <a href="{{ route('admin.withdraw_feed') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1 col-span-2">
                        <span class="text-xl">🔗</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Feeds / Receipts Injector</span>
                    </a>
                </div>
            </details>

            <details class="group border border-slate-150 rounded-2xl p-3 bg-slate-50/50" open>
                <summary class="list-none text-[9px] font-black text-slate-455 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                    <span>E-Store Systems</span>
                    <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                </summary>
                <div class="grid grid-cols-2 gap-3 pt-3 border-t border-slate-200/40 mt-3">
                    <a href="{{ route('admin.settings') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">⚙️</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Shipping Setup</span>
                    </a>
                    <a href="{{ route('admin.products') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">📦</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Product Stocks</span>
                    </a>
                    <a href="{{ route('admin.orders') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">🚚</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Shop Orders</span>
                    </a>
                    <a href="{{ route('admin.lottery') }}" class="flex flex-col items-center justify-center p-3.5 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-xl">🎫</span>
                        <span class="text-[8px] font-black uppercase tracking-wider text-slate-700">Sweepstakes draw</span>
                    </a>
                </div>
            </details>

            <details class="group border border-slate-150 rounded-2xl p-3 bg-slate-50/50" open>
                <summary class="list-none text-[9px] font-black text-slate-455 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                    <span>Interactive Node</span>
                    <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                </summary>
                <div class="grid grid-cols-3 gap-2.5 pt-3 border-t border-slate-200/40 mt-3">
                    <a href="{{ route('admin.game') }}" class="flex flex-col items-center justify-center p-2 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-lg">🎮</span>
                        <span class="text-[7px] font-black uppercase text-slate-700">Game parameter</span>
                    </a>
                    <a href="{{ route('admin.mining') }}" class="flex flex-col items-center justify-center p-2 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-lg">⛏️</span>
                        <span class="text-[7px] font-black uppercase text-slate-700">Mining Nodes</span>
                    </a>
                    <a href="{{ route('admin.vip') }}" class="flex flex-col items-center justify-center p-2 bg-white border border-slate-200 rounded-2xl bouncy-hover text-center space-y-1">
                        <span class="text-lg">👑</span>
                        <span class="text-[7px] font-black uppercase text-slate-700">VIP cards</span>
                    </a>
                </div>
            </details>
        </div>
    </div>

    <!-- Administrative core settings logs -->
    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-list-check text-blue-500"></i> Operation Summaries</h3>
        
        <div class="space-y-2.5 divide-y divide-slate-100">
            <div class="flex justify-between items-center py-1 text-xs">
                <span class="text-[10px] font-extrabold text-slate-500 uppercase tracking-wide">Tasks Completed Today ✅</span>
                <span class="font-black text-slate-800">{{ number_format($completedTasksToday) }} Missions</span>
            </div>
            <div class="flex justify-between items-center pt-2.5 text-xs">
                <span class="text-[10px] font-extrabold text-slate-500 uppercase tracking-wide">Active Sweepstakes Entry 🎫</span>
                <span class="font-black text-amber-500">{{ number_format($activeLotteryTickets) }} Tickets</span>
            </div>
            <div class="flex justify-between items-center pt-2.5 text-xs">
                <span class="text-[10px] font-extrabold text-slate-500 uppercase tracking-wide">Promo Redemptions 🎁</span>
                <span class="font-black text-blue-600">{{ number_format($totalGiftCodeClaims) }} Claims</span>
            </div>
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const chartCtx = document.getElementById('insightsChart').getContext('2d');
        new Chart(chartCtx, {
            type: 'line',
            data: {
                labels: @json($growthLabels),
                datasets: [
                    {
                        label: 'User Growth',
                        data: @json($growthData),
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.05)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 3,
                        pointRadius: 2
                    },
                    {
                        label: 'Revenue (USD)',
                        data: @json($revenueData),
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.05)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 3,
                        pointRadius: 2
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        grid: { display: false },
                        ticks: { font: { size: 8, weight: 'bold' } }
                    },
                    y: {
                        grid: { color: '#f1f5f9' },
                        ticks: { font: { size: 8, weight: 'bold' } }
                    }
                }
            }
        });
    });
</script>
@endpush