@extends('layouts.admin')

@section('title', 'Payout Audit - DX EARN')
@section('page_title', 'Payout Audit 💵')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    <div class="flex gap-4 border-b border-slate-200 bg-white px-4 py-3 rounded-2xl shadow-sm font-extrabold text-slate-400">
        <a href="{{ route('admin.withdraw', ['sub_tab' => 'pending']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'pending' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Pending</a>
        <a href="{{ route('admin.withdraw', ['sub_tab' => 'approved']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'approved' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Approved</a>
        <a href="{{ route('admin.withdraw', ['sub_tab' => 'cancelled']) }}" class="pb-1 uppercase text-xs {{ $currentSubTab === 'cancelled' ? 'text-blue-600 border-b-2 border-blue-600 font-black' : '' }}">Cancelled</a>
    </div>

    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="space-y-4">
        @foreach ($withdrawals as $w)
            @php 
                $badge = 'bg-amber-50 text-amber-600 border-amber-250/50';
                if ($w->status === 'approved') {
                    $badge = 'bg-emerald-50 text-emerald-600 border-emerald-250/50';
                } elseif ($w->status === 'cancelled') {
                    $badge = 'bg-rose-50 text-rose-600 border-rose-250/50';
                }
            @endphp
            <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4 animate-fadeIn">
                <div class="flex justify-between items-start">
                    <div>
                        <!-- Blade Escaping bug fixed here -->
                        <h4 class="text-xs font-black text-slate-800 uppercase">{{ htmlspecialchars($w->username) }}</h4>
                        <span class="text-[8px] text-slate-400 font-bold block mt-1">Submitted: {{ $w->requested_at ? $w->requested_at->format('d M Y • h:i A') : '' }}</span>
                    </div>
                    <div class="text-right">
                        <span class="text-sm font-black text-emerald-600 block">$ {{ number_format($w->amount, 2) }}</span>
                        <span class="text-[8px] font-black border {{ $badge }} px-2 py-0.5 rounded uppercase block tracking-wider mt-1 text-center">{{ htmlspecialchars($w->status) }}</span>
                    </div>
                </div>
                <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-150 text-[9px] text-slate-550 font-bold uppercase space-y-1.5 leading-normal shadow-inner">
                    <div>Gateway: <strong class="text-slate-800">{{ htmlspecialchars($w->payment_method) }}</strong></div>
                    <div>Target Address: <strong class="text-slate-800 break-all select-all font-mono">{{ htmlspecialchars($w->account_number) }}</strong></div>
                    <div class="pt-1.5 mt-1.5 border-t border-slate-200/50 flex justify-between text-[8px] font-black text-slate-400">
                        <span>Balance Type: <strong class="text-blue-600">{{ $w->withdrawal_type === 'referral_usd' ? 'Referral Balance' : 'Main USD' }}</strong></span>
                    </div>
                    <span class="text-[8px] font-black text-blue-700 block uppercase tracking-wide">Ticket ID: #{{ htmlspecialchars($w->ticket_number ?? '0') }}</span>
                </div>
                <div class="flex gap-2">
                    @if ($w->status === 'pending')
                        <form method="POST" action="{{ route('admin.withdraw.audit') }}" class="flex-1" onsubmit="return confirm('Approve payout ticket?');">
                            @csrf
                            <input type="hidden" name="withdrawal_id" value="{{ $w->id }}">
                            <input type="hidden" name="withdraw_action" value="approve">
                            <input type="hidden" name="sub_tab" value="{{ $currentSubTab }}">
                            <button type="submit" class="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover btn-glow-emerald">Approve Payout ⚡</button>
                        </form>
                        <form method="POST" action="{{ route('admin.withdraw.audit') }}" class="flex-1" onsubmit="return confirm('Reject and refund 100% payout amount?');">
                            @csrf
                            <input type="hidden" name="withdrawal_id" value="{{ $w->id }}">
                            <input type="hidden" name="withdraw_action" value="reject">
                            <input type="hidden" name="sub_tab" value="{{ $currentSubTab }}">
                            <button type="submit" class="w-full py-3 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200/50 rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover">Reject & Refund</button>
                        </form>
                    @endif
                </div>
            </div>
        @endforeach
        @if ($withdrawals->isEmpty())
            <div class="text-center py-12 bg-white border border-slate-200 rounded-[2rem] p-8 shadow-sm">
                <p class="text-[10px] text-slate-455 font-bold uppercase tracking-wider">No payout request entries located.</p>
            </div>
        @endif
    </div>
</main>
@endsection