@extends('layouts.admin')

@section('title', 'User Directory - DX EARN')
@section('page_title', 'User Hub 👥')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-4 rounded-[2rem] shadow-sm">
        <form method="GET" action="{{ route('admin.users') }}" class="flex gap-2">
            <input type="text" name="search" value="{{ htmlspecialchars($searchQuery) }}" placeholder="Search username or name..." class="w-full bg-slate-50 border border-slate-200 rounded-2xl px-4 py-2.5 text-xs font-bold outline-none focus:border-blue-400 transition-all shadow-inner text-slate-800">
            <button type="submit" class="px-5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black uppercase bouncy-hover"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>
    </div>

    <div class="space-y-3">
        @foreach ($usersListData as $u) 
            @php 
                $uJson = json_encode($u);
                $uPicUrl = get_avatar_url($u->profile_pic);
            @endphp
            <!-- Fix: Used Base64 encode for data-user to avoid HTML/JS quotation crash -->
            <div onclick="openUserModal(this)" data-user="{{ base64_encode($uJson) }}" class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm cursor-pointer hover:border-slate-350 active:scale-95 duration-100 transition-all">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <img src="{{ $uPicUrl }}" class="w-10 h-10 rounded-full object-cover bg-slate-50 border border-slate-100 shadow-sm">
                        <div>
                            <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide leading-none">{{ htmlspecialchars($u->full_name ?: '@' . $u->username) }}</h4>
                            <!-- Blade Escaping bug fixed here -->
                            <p class="text-[9px] text-slate-400 font-bold mt-1.5">{{ htmlspecialchars($u->username) }}</p>
                            <span class="text-[8px] text-slate-400 font-bold block mt-1">ID: #{{ $u->id }} • Status: <strong class="{{ $u->is_banned ? 'text-rose-500' : 'text-emerald-600' }}">{{ $u->is_banned ? 'Banned' : 'Active' }}</strong></span>
                        </div>
                    </div>
                    <i class="fa-solid fa-angle-right text-slate-400"></i>
                </div>
            </div>
        @endforeach
        @if ($usersListData->isEmpty())
            <div class="text-center py-12 bg-white border border-slate-200 rounded-[2rem] p-8 shadow-sm">
                <p class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">No users matched your search terms.</p>
            </div>
        @endif
    </div>
</main>

<!-- User Adjustments Modal -->
<div id="userModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white border border-slate-200 rounded-[2.5rem] w-full max-w-sm p-6 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto no-scrollbar text-slate-800">
        <div class="text-center">
            <img id="m_pic" src="" class="w-16 h-16 rounded-full object-cover mx-auto border-2 border-slate-150 mb-2 shadow-inner">
            <h3 id="m_name" class="text-sm font-black text-slate-900 uppercase">--</h3>
            <span id="m_username" class="text-[10px] font-bold text-slate-400 block">--</span>
            <p id="m_created" class="text-[8px] text-slate-455 uppercase font-bold mt-1">Joined: --</p>
            <p id="m_meta" class="text-[8px] text-slate-455 uppercase font-bold">TG ID: -- • Referred: --</p>
        </div>
        <form method="POST" action="{{ route('admin.users.update') }}" class="space-y-4 pt-3 border-t border-slate-100 text-left">
            @csrf
            <input type="hidden" name="user_id" id="m_user_id">
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Coins Balance 🪙</label>
                    <input type="number" step="0.0001" name="balance_coin" id="m_coin" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
                </div>
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Tokens Balance 💵</label>
                    <input type="number" step="0.0001" name="balance_token" id="m_token" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Converted USD $</label>
                    <input type="number" step="0.01" name="balance_dollar" id="m_dollar" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
                </div>
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Referral USD $</label>
                    <input type="number" step="0.01" name="balance_referral_dollar" id="m_ref_dollar" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-3 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">KYC status 🛡️</label>
                    <select name="kyc_status" id="m_kyc" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-2 py-2.5 text-xs font-black text-slate-500 outline-none focus:border-blue-400 transition-all">
                        <option value="unverified">Unverified</option>
                        <option value="pending">Processing</option>
                        <option value="approved">Approved</option>
                        <option value="rejected">Rejected</option>
                    </select>
                </div>
                <div>
                    <label class="text-[8px] font-black text-slate-400 uppercase tracking-wider block ml-1 mb-1">Banning Status 🔒</label>
                    <select name="is_banned" id="m_banned" class="w-full bg-slate-50 border border-slate-100 rounded-xl px-2 py-2.5 text-xs font-black text-slate-500 outline-none focus:border-blue-400 transition-all">
                        <option value="0">Active User</option>
                        <option value="1">Banned User</option>
                    </select>
                </div>
            </div>
            <div class="flex gap-2 pt-2">
                <button type="button" onclick="closeUserModal()" class="flex-1 py-3.5 bg-slate-50 hover:bg-slate-100 text-slate-500 rounded-xl text-[10px] font-black border border-slate-100 shadow-sm active:scale-95 duration-100 uppercase tracking-widest bouncy-hover">Cancel</button>
                <button type="submit" class="flex-1 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 duration-100 bouncy-hover btn-glow-blue">Save</button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const userModal = document.getElementById('userModal');

    function openUserModal(element) {
        // Base64 decoded data attribute to avoid Javascript quotation crash
        const data = JSON.parse(atob(element.getAttribute('data-user')));

        document.getElementById('m_user_id').value = data.id;
        
        const isExternal = data.profile_pic && (data.profile_pic.startsWith('http://') || data.profile_pic.startsWith('https://'));
        document.getElementById('m_pic').src = isExternal ? data.profile_pic : `{{ asset('uploads') }}/${data.profile_pic || 'default_avatar.png'}`;
        
        document.getElementById('m_name').innerText = data.full_name || data.username;
        document.getElementById('m_username').innerText = `@${data.username}`;
        
        const dateStr = new Date(data.created_at).toLocaleDateString('en-US', {day: 'numeric', month: 'short', year: 'numeric'});
        document.getElementById('m_created').innerText = `Joined: ${dateStr}`;
        document.getElementById('m_meta').innerText = `TG ID: ${data.telegram_id || 'N/A'} • Referred: ${data.referred_by || 'N/A'}`;
        
        document.getElementById('m_coin').value = parseFloat(data.balance_coin).toFixed(4);
        document.getElementById('m_token').value = parseFloat(data.balance_token).toFixed(4);
        document.getElementById('m_dollar').value = parseFloat(data.balance_dollar).toFixed(2);
        document.getElementById('m_ref_dollar').value = parseFloat(data.balance_referral_dollar || 0).toFixed(2);
        
        document.getElementById('m_kyc').value = data.kyc_status;
        document.getElementById('m_banned').value = data.is_banned;
        
        userModal.classList.remove('hidden');
    }

    function closeUserModal() {
        userModal.classList.add('hidden');
    }
</script>
@endpush