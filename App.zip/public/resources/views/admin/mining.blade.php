@extends('layouts.admin')

@section('title', 'Mining Setup - DX EARN')
@section('page_title', 'Mining Setup ⛏️')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4 text-left">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-microchip text-indigo-500"></i> Cloud Mining Node Settings</h3>
        <form method="POST" action="{{ route('admin.mining.save') }}" class="space-y-4">
            @csrf
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Mining Base Duration (Hours) 📁</label>
                <input type="number" step="0.1" name="mining_base_duration_hours" value="{{ $miningDurationHours }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Base Yield Reward Hourly (Coins/Hour) ⚡</label>
                <input type="number" step="0.0001" name="mining_base_yield_hourly" value="{{ $miningYieldHourly }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Monetag Ad Wait (Sec)</label>
                    <input type="number" name="mining_boost_ad_wait_seconds" value="{{ $miningBoostAdWait }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
                <div>
                    <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Boost Multiplier (x)</label>
                    <input type="number" step="0.1" name="mining_boost_multiplier" value="{{ $miningBoostMult }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Boost Duration (Hours)</label>
                    <input type="number" step="0.1" name="mining_boost_duration_hours" value="{{ $miningBoostDuration }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
                <div>
                    <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Boost Cooldown (Hours)</label>
                    <input type="number" step="0.1" name="mining_boost_cooldown_hours" value="{{ $miningBoostCooldown }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800 shadow-inner">
                </div>
            </div>
            <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-teal-500 to-emerald-650 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover">
                Save Mining Node Parameters 💾
            </button>
        </form>
    </div>
</main>
@endsection