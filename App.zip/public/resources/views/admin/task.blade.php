@extends('layouts.admin')

@section('title', 'Missions - DX EARN')
@section('page_title', 'Missions Hub 📝')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5" id="form-title-task"><i class="fa-solid fa-circle-plus text-blue-500"></i> Publish / Edit Task</h3>
        <form method="POST" action="{{ route('admin.tasks.save') }}" class="space-y-4" id="taskForm">
            @csrf
            <input type="hidden" name="task_id" id="task_id" value="0">
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Task Title Name 🏷️</label>
                <input type="text" name="name" id="name" placeholder="E.g. Follow our Twitter account" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800">
            </div>
            <div>
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Redirection Link URL 🔗</label>
                <input type="url" name="link" id="link" placeholder="https://t.me/your_channel" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Reward Coin Amount 🪙</label>
                    <input type="number" step="0.001" name="reward_amount" id="reward_amount" placeholder="50.00" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-black text-slate-800 outline-none">
                </div>
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Platform Network Type 🌐</label>
                    <select name="task_type" id="task_type" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2.5 text-xs font-bold outline-none text-slate-500">
                        <option value="Telegram">Telegram Channel</option>
                        <option value="YouTube">YouTube Video</option>
                        <option value="Facebook">Facebook Profile</option>
                        <option value="TikTok">TikTok Handle</option>
                        <option value="WhatsApp">WhatsApp Community</option>
                        <option value="Web">Website Visits</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md bouncy-hover btn-glow-blue">Publish Task Details</button>
        </form>
    </div>

    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-sliders text-indigo-500"></i> Global Limits & Wait Durations</h3>
        <form method="POST" action="{{ route('admin.tasks.settings') }}" class="space-y-4">
            @csrf
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Daily Task Limit</label>
                    <input type="number" name="daily_task_limit" value="{{ $dailyTaskLimitVal }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-slate-800">
                </div>
                <div>
                    <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Required Wait (Seconds)</label>
                    <input type="number" name="task_wait_seconds" value="{{ $taskWaitSecondsVal }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-slate-800">
                </div>
            </div>
            <button type="submit" class="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover">Save Global Parameters 💾</button>
        </form>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1">Configured Tasks</h3>
        <div class="space-y-3.5">
            @foreach ($tasks as $task)
                <!-- Task payload base64-encoded to prevent string parsing errors -->
                @php $taskBase64 = base64_encode(json_encode($task)); @endphp
                <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 whitespace-nowrap overflow-hidden pr-3">
                        <h4 class="font-black text-slate-800 text-xs tracking-wide uppercase truncate w-48">{{ htmlspecialchars($task->name) }}</h4>
                        <span class="text-[8px] font-bold uppercase text-slate-400">Reward: <strong class="text-emerald-600">🪙 +{{ number_format($task->reward_amount, 2) }}</strong> • Type: {{ $task->task_type }}</span>
                    </div>
                    <div class="flex gap-1 shrink-0">
                        <button onclick="populateTaskEdit('{{ $taskBase64 }}')" class="w-8 h-8 bg-blue-50/50 text-blue-600 border border-blue-100/30 rounded-xl flex items-center justify-center text-xs hover:bg-blue-100 active:scale-90 transition-all"><i class="fa-solid fa-pen"></i></button>
                        <form method="POST" action="{{ route('admin.tasks.delete') }}" onsubmit="return confirm('Delete this task permanently?');">
                            @csrf
                            <input type="hidden" name="task_id" value="{{ $task->id }}">
                            <button type="submit" class="w-8 h-8 bg-rose-50/50 text-rose-500 border border-rose-100/30 rounded-xl flex items-center justify-center text-xs hover:bg-rose-100 active:scale-90 transition-all"><i class="fa-regular fa-trash-can"></i></button>
                        </form>
                    </div>
                </div>
            @endforeach
            @if ($tasks->isEmpty())
                <p class="text-center text-[10px] text-slate-455 font-bold uppercase tracking-wider py-8">No tasks published yet.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function populateTaskEdit(taskBase64) {
        // Base64 decoded to avoid Javascript Quotation clashes
        const task = JSON.parse(atob(taskBase64));

        document.getElementById('task_id').value = task.id;
        document.getElementById('name').value = task.name;
        document.getElementById('link').value = task.link;
        document.getElementById('reward_amount').value = task.reward_amount;
        document.getElementById('task_type').value = task.task_type;
        document.getElementById('form-title-task').innerHTML = `<i class="fa-solid fa-pen-to-square text-blue-500"></i> Edit Task Parameters`;
        document.getElementById('taskForm').scrollIntoView({ behavior: 'smooth' });
    }
</script>
@endpush