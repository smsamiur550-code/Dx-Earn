@extends('layouts.admin')

@section('title', 'Sweepstakes Drawing - DX EARN')
@section('page_title', 'Weekly Draw 🎫')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-clock-rotate-left text-blue-500"></i> Sweepstakes Drawing Settings</h3>
        <form method="POST" action="{{ route('admin.lottery.schedule') }}" class="space-y-4">
            @csrf
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Next Draw Time String ⏰</label>
                <input type="text" name="next_lottery_draw_time" value="{{ htmlspecialchars($nextDrawTimeVal) }}" placeholder="next Sunday 20:00:00" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
            </div>
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Ticket Manual Purchase Price (🪙 Coins)</label>
                <input type="number" step="0.01" name="lottery_ticket_price" value="{{ $ticketPriceVal }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">Save Schedule Configs</button>
        </form>
    </div>

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-gift text-purple-500"></i> Prize Pools Setup</h3>
        <form method="POST" action="{{ route('admin.lottery.prizes') }}" class="space-y-4">
            @csrf
            <div>
                <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">1st Prize Jackpot (🪙 Coins)</label>
                <input type="number" step="0.01" name="prize_1_amount" value="{{ $prize1Val }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-black text-slate-800 outline-none shadow-inner">
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">Save Prize Pools</button>
        </form>
    </div>

    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-trophy text-amber-500 text-base"></i> Winner Selection Controls</h3>
        <p class="text-[10px] text-slate-500 leading-relaxed font-semibold">Active Approved/Pending Tickets inside pool: <strong class="text-indigo-650">{{ $activeTicketsCount }}</strong></p>
        <form method="POST" action="{{ route('admin.lottery.draw') }}" class="space-y-4" onsubmit="return confirm('Conclude random sweepstakes drawing now? Selected winner claims the jackpot and rest of tickets mark lost.')">
            @csrf
            @if ($activeTicketsCount > 0)
                <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-amber-400 to-orange-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-amber">🎲 Roll & Draw Winner</button>
            @else
                <button type="button" disabled class="w-full py-4 bg-slate-100 text-slate-400 border border-slate-200 rounded-2xl font-black text-xs uppercase tracking-widest cursor-not-allowed">🔒 Pool Empty: Cannot Draw</button>
            @endif
        </form>
    </div>
</main>
@endsection