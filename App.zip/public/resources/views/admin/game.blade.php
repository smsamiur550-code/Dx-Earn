@extends('layouts.admin')

@section('title', 'Core Games Config - DX EARN')
@section('page_title', 'Games Settings 🎮')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10 text-left">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-gears text-indigo-500"></i> Core Games Parameters</h3>
        <form method="POST" action="{{ route('admin.game.save') }}" class="space-y-5">
            @csrf

            <!-- Game 1: Dice Master -->
            <div class="border-t border-slate-100 pt-3 space-y-3">
                <span class="text-[10px] font-black text-blue-600 uppercase tracking-wider block">🎲 Game 1: Dice Master</span>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Daily Limit (Rolls)</label>
                        <input type="number" name="dice_limit" value="{{ $dice_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-slate-800">
                    </div>
                    <div>
                        <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Reward Per Point</label>
                        <input type="number" step="0.01" name="dice_point_value" value="{{ $dice_point_value }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none text-slate-800">
                    </div>
                </div>
            </div>

            <!-- Game 2: Scratch Lotto -->
            <div class="border-t border-slate-100 pt-3 space-y-3">
                <span class="text-[10px] font-black text-rose-500 uppercase tracking-wider block">🎫 Game 2: Scratch Lotto</span>
                <div class="grid grid-cols-3 gap-2">
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Daily Limit</label>
                        <input type="number" name="scratch_limit" value="{{ $scratch_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Min Win (🪙)</label>
                        <input type="number" step="0.01" name="scratch_min_prize" value="{{ $scratch_min_prize }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Max Win (🪙)</label>
                        <input type="number" step="0.01" name="scratch_max_prize" value="{{ $scratch_max_prize }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                </div>
            </div>

            <!-- Game 3: Lucky Spin Wheel -->
            <div class="border-t border-slate-100 pt-3 space-y-3">
                <span class="text-[10px] font-black text-emerald-600 uppercase tracking-wider block">🎡 Game 3: Lucky Spin Wheel</span>
                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Daily Limit (Spins)</label>
                        <input type="number" name="spin_limit" value="{{ $spin_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Base Reward (🪙)</label>
                        <input type="number" step="0.01" name="spin_reward" value="{{ $spin_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                    </div>
                </div>
                <span class="block text-[8px] font-black uppercase tracking-wider text-slate-400 ml-1 font-extrabold">8 Wheel Slices Rewards (🪙 Coins)</span>
                <div class="grid grid-cols-4 gap-2">
                    @for($i=0; $i<=7; $i++)
                        <div>
                            <label class="text-[7px] text-slate-450 block mb-0.5 text-center font-bold">Slice {{ $i }}</label>
                            <input type="number" step="0.01" name="spin_prize_{{ $i }}_val" value="{{ ${'spin_prize_'.$i.'_val'} }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-1.5 py-1 text-xs font-bold outline-none text-center">
                        </div>
                    @endfor
                </div>
            </div>

            <!-- Game 4: Treasure Box -->
            <div class="border-t border-slate-100 pt-3 space-y-3">
                <span class="text-[10px] font-black text-purple-600 uppercase tracking-wider block">🏴‍☠️ Game 4: Treasure Box</span>
                <div>
                    <label class="block text-[8px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Daily Limit (Attempts)</label>
                    <input type="number" name="treasure_limit" value="{{ $treasure_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2 text-xs font-bold outline-none">
                </div>
                <div class="space-y-2">
                    <span class="block text-[8px] font-black uppercase tracking-wider text-slate-400 ml-1 font-extrabold">9 Box Hidden Values (🪙 Coins)</span>
                    <div class="grid grid-cols-3 gap-2">
                        @for($i=1; $i<=9; $i++)
                            <div>
                                <label class="text-[7px] text-slate-455 block mb-0.5 text-center font-bold">Box {{ $i }}</label>
                                <input type="number" step="0.01" name="treasure_val_{{ $i }}" value="{{ ${'treasure_val_'.$i} }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-1.5 text-xs font-bold outline-none text-center">
                            </div>
                        @endfor
                    </div>
                </div>
            </div>

            <!-- Other In-App Games Limits -->
            <div class="border-t border-slate-100 pt-3 space-y-3">
                <span class="text-[10px] font-black text-cyan-600 uppercase tracking-wider block">🧠 Other In-App Games Limits</span>
                <div class="grid grid-cols-3 gap-2">
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Math Limit</label>
                        <input type="number" name="math_limit" value="{{ $math_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Word Limit</label>
                        <input type="number" name="word_limit" value="{{ $word_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Quiz Limit</label>
                        <input type="number" name="quiz_limit" value="{{ $quiz_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                </div>
                <div class="grid grid-cols-3 gap-2 mt-2">
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Brain Limit</label>
                        <input type="number" name="brain_limit" value="{{ $brain_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Puzzle Limit</label>
                        <input type="number" name="puzzle_limit" value="{{ $puzzle_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Emoji Limit</label>
                        <input type="number" name="emoji_limit" value="{{ $emoji_limit }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold outline-none">
                    </div>
                </div>
                <div class="grid grid-cols-3 gap-2 mt-2">
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Math Reward</label>
                        <input type="number" step="0.01" name="math_reward" value="{{ $math_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Word Reward</label>
                        <input type="number" step="0.01" name="word_reward" value="{{ $word_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Quiz Reward</label>
                        <input type="number" step="0.01" name="quiz_reward" value="{{ $quiz_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                </div>
                <div class="grid grid-cols-3 gap-2 mt-2">
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Brain Reward</label>
                        <input type="number" step="0.01" name="brain_reward" value="{{ $brain_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Puzzle Reward</label>
                        <input type="number" step="0.01" name="puzzle_reward" value="{{ $puzzle_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                    <div>
                        <label class="block text-[7px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Emoji Reward</label>
                        <input type="number" step="0.01" name="emoji_reward" value="{{ $emoji_reward }}" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-2 py-2 text-xs font-bold">
                    </div>
                </div>
            </div>

            <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">
                Save Game Configurations 💾
            </button>
        </form>
    </div>
</main>
@endsection