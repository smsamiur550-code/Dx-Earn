@extends('layouts.admin')

@section('title', 'Promo Codes - DX EARN')
@section('page_title', 'Promo Codes 🎁')

@section('content')
<main class="p-4 space-y-4 flex-grow max-w-[480px] mx-auto w-full pb-10">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white border border-slate-200 p-5 rounded-[2.5rem] shadow-sm space-y-4 animate-fadeIn">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest flex items-center gap-1.5 text-left"><i class="fa-solid fa-circle-plus text-blue-500"></i> Generate Promo Code</h3>
        <form method="POST" action="{{ route('admin.gift.create') }}" class="space-y-4">
            @csrf
            <div class="text-left">
                <label class="block text-[8px] font-black uppercase tracking-wider text-slate-400 mb-1 ml-1">Reward Value (Coins 🪙)</label>
                <input type="number" step="0.01" name="reward_amount" placeholder="E.g. 500.00" required class="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs font-bold outline-none text-slate-800">
            </div>
            <button type="submit" class="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs uppercase tracking-wider shadow-md bouncy-hover btn-glow-blue">Generate Code ⚡</button>
        </form>
    </div>

    <div class="bg-white border border-slate-200 p-5 rounded-[2rem] shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-850 uppercase tracking-widest flex items-center gap-1.5 text-left"><i class="fa-solid fa-ticket text-indigo-500"></i> Active Promo Codes</h3>
        <div class="space-y-3.5">
            @foreach ($gifts as $gift)
                <div class="bg-slate-50 border border-slate-150 p-4 rounded-2xl flex justify-between items-center text-xs">
                    <div class="space-y-1 text-left">
                        <div class="flex items-center gap-2">
                            <h4 class="font-black text-slate-700 text-sm tracking-wider font-mono" id="code-val-{{ $gift->id }}">#{{ htmlspecialchars($gift->code) }}</h4>
                            <button onclick="copyToClipboard('code-val-{{ $gift->id }}')" class="w-6 h-6 bg-white border border-slate-200 hover:bg-blue-50 text-slate-500 hover:text-blue-600 rounded-lg flex items-center justify-center text-[10px] active:scale-75 transition-all shadow-sm"><i class="fa-regular fa-copy"></i></button>
                        </div>
                        <div class="flex gap-2.5 text-[8px] font-bold text-slate-400 uppercase tracking-wider">
                            <span>Reward: <strong class="text-blue-600">🪙 +{{ number_format($gift->coin_amount, 2) }}</strong></span>
                            <span>•</span>
                            <span>Limit: <strong class="text-slate-655">Unlimited</strong></span>
                        </div>
                    </div>
                    <form method="POST" action="{{ route('admin.gift.delete') }}" onsubmit="return confirm('Terminate this promo code permanently?')" class="shrink-0">
                        @csrf
                        <input type="hidden" name="gift_id" value="{{ $gift->id }}">
                        <button type="submit" class="w-8 h-8 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center text-xs hover:bg-rose-100 bouncy-hover transition-all">
                            <i class="fa-regular fa-trash-can"></i>
                        </button>
                    </form>
                </div>
            @endforeach
            @if ($gifts->isEmpty())
                <p class="text-center text-[10px] text-slate-455 font-bold uppercase tracking-wider py-8">No promo codes active yet.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function copyToClipboard(elementId) {
        const el = document.getElementById(elementId);
        const cleanCodeText = el.innerText.replace('#', '');
        navigator.clipboard.writeText(cleanCodeText).then(() => {
            if (window.GlobalPopup) {
                GlobalPopup.show('success', 'Copied!', 'Promo Code copied successfully. 📋', false, 1500);
            } else {
                alert('Copied to clipboard!');
            }
        });
    }
</script>
@endpush