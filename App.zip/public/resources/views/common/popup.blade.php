@if(session()->has('popup_data'))
    @php $p = session('popup_data'); @endphp
    <script>
    document.addEventListener('DOMContentLoaded', () => {
        if (window.GlobalPopup) {
            window.GlobalPopup.show(
                "{{ $p['type'] }}", 
                "{{ $p['title'] }}", 
                "{{ $p['message'] }}",
                true,
                {{ intval($p['auto_close'] ?? 0) }}
            );
        }
    });
    </script>
@endif