@extends('layouts.app')

@section('title', 'My Wallet - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">My Wallet 💳</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    <!-- Balance Card -->
    <div class="bg-gradient-to-tr from-blue-600 via-indigo-650 to-purple-600 p-6 rounded-[2.2rem] text-white shadow-md relative overflow-hidden">
        <div class="relative z-10 space-y-4">
            <div>
                <span class="text-[9px] font-black uppercase tracking-widest text-slate-100 opacity-90">Estimated Total Balance (৳) ✨</span>
                @php 
                    $totalUsd = floatval($user->balance_dollar) + floatval($user->balance_referral_dollar ?? 0);
                    $totalBdt = $totalUsd * $takaRate;
                @endphp
                <h2 class="text-3xl font-black text-white mt-0.5 text-left">{{ number_format($totalBdt, 2) }} <span class="text-emerald-300 text-sm font-bold uppercase">৳</span></h2>
            </div>

            <div class="grid grid-cols-2 gap-4 pt-3 border-t border-white/15 text-xs font-semibold uppercase text-slate-100 text-left">
                <div>
                    <span class="text-[8px] opacity-80 block font-black">Main Balance</span>
                    <span class="text-base font-black">{{ number_format($user->balance_dollar * $takaRate, 2) }} ৳</span>
                </div>
                <div>
                    <span class="text-[8px] opacity-80 block font-black">Referral Balance</span>
                    <span class="text-base font-black">{{ number_format(($user->balance_referral_dollar ?? 0) * $takaRate, 2) }} ৳</span>
                </div>
            </div>
        </div>
        <div class="absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-md"></div>
    </div>

    <!-- Assets Grid -->
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between h-24 text-left">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">Coins ⛏️</span>
            <span class="text-sm font-black text-slate-700 block mt-1">{{ number_format($user->balance_coin, 2) }} Coins</span>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between h-24 text-left">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">Tokens 🟡</span>
            <span class="text-sm font-black text-slate-700 block mt-1">{{ number_format($user->balance_token, 2) }} Tokens</span>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-2 gap-3">
        <a href="{{ route('convert') }}" class="py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl text-center text-xs font-black uppercase tracking-widest bouncy-hover btn-glow-blue">
            Swap / Convert 🔄
        </a>
        <a href="{{ route('withdraw') }}" class="py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl text-center text-xs font-black uppercase tracking-widest bouncy-hover btn-glow-slate">
            Request Payout 💵
        </a>
    </div>

    <!-- Recent Transactions Ledger -->
    <div class="space-y-3 pt-2">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Recent Transactions</h3>
        <div class="space-y-2.5">
            @foreach ($transactions as $tx)
                @php 
                    $badgeClass = 'text-blue-500 bg-blue-50 border-blue-100';
                    $symbolPrefix = '';
                    $type = strtolower($tx->type ?? 'credit');
                    
                    if ($type === 'credit') {
                        $badgeClass = 'text-emerald-500 bg-emerald-50 border-emerald-100';
                        $symbolPrefix = '+';
                    } elseif ($type === 'debit') {
                        $badgeClass = 'text-rose-500 bg-rose-50 border-rose-100';
                        $symbolPrefix = '-';
                    }

                    $currencySymbol = '🪙';
                    if ($tx->currency === 'token') {
                        $currencySymbol = '💵';
                    } elseif ($tx->currency === 'usd') {
                        $currencySymbol = '৳';
                    }
                    
                    $amt = floatval($tx->amount);
                    if ($tx->currency === 'usd') {
                        $amt = $amt * $takaRate;
                    }
                @endphp
                <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between">
                    <div class="space-y-1 text-left">
                        <span class="text-[8px] font-black border px-2 py-0.5 rounded-md uppercase tracking-wider block w-fit {{ $badgeClass }}">{{ htmlspecialchars($tx->category) }}</span>
                        <h4 class="text-xs font-bold text-slate-700 max-w-[200px] break-words">{{ htmlspecialchars($tx->description) }}</h4>
                        <span class="text-[8px] text-slate-400 font-bold block">{{ $tx->created_at->format('d M Y • h:i A') }}</span>
                    </div>
                    <span class="text-xs font-black {{ $type === 'credit' ? 'text-emerald-600' : 'text-rose-500' }} shrink-0">
                        {{ $symbolPrefix . $currencySymbol . ' ' . number_format($amt, 2) }}
                    </span>
                </div>
            @endforeach

            @if ($transactions->isEmpty())
                <div class="text-center py-8 opacity-50 bg-white border border-slate-100 rounded-3xl p-6">
                    <span class="text-3xl block mb-1">📜</span>
                    <p class="text-[9px] font-black uppercase text-slate-400 tracking-wider">No transactions found</p>
                </div>
            @endif
        </div>
    </div>
</main>
@endsection