@extends('layouts.app')

@section('title', 'Missions - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-90 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Missions Center 📝</h1>
    <div class="px-3 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<div class="p-4 space-y-4">
    <div class="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm text-center space-y-2">
        <div class="flex justify-between items-baseline text-[9px] font-black text-slate-400 uppercase tracking-wider">
            <span>Completed Tasks Today</span>
            <span class="text-blue-600 font-extrabold">{{ $completedTodayCount }} / {{ $dailyTaskLimit }}</span>
        </div>
        <div class="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
            <div class="bg-blue-500 h-full rounded-full transition-all duration-550" style="width: {{ min(100, ($completedTodayCount / $dailyTaskLimit) * 100) }}%"></div>
        </div>
    </div>

    @if(session('success'))
        <div class="bg-emerald-50 text-emerald-600 border border-emerald-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>✅</span> Successfully claimed 🪙 {{ number_format(floatval(request()->query('amt', 0)), 2) }} DX Coins! 🎉
        </div>
    @endif
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="space-y-4">
        @foreach ($allTasks as $t)
            @php
                $type = strtolower($t->task_type);
                $isVideo = in_array($type, ['youtube', 'yt', 'video']);
                $watchSeconds = $isVideo ? 45 : 5;
                
                $icon = 'fa-solid fa-share-nodes';
                $colorClass = 'text-blue-500 bg-blue-50 border-blue-100';

                if ($type === 'facebook' || $type === 'fb') {
                    $icon = 'fa-brands fa-facebook';
                    $colorClass = 'text-indigo-650 bg-indigo-50 border-indigo-100';
                } elseif ($type === 'telegram' || $type === 'tg') {
                    $icon = 'fa-brands fa-telegram';
                    $colorClass = 'text-sky-500 bg-sky-50 border-sky-100';
                } elseif ($type === 'whatsapp' || $type === 'wp') {
                    $icon = 'fa-brands fa-whatsapp';
                    $colorClass = 'text-emerald-550 bg-emerald-50 border-emerald-100';
                } elseif ($type === 'tiktok' || $type === 'tt') {
                    $icon = 'fa-brands fa-tiktok';
                    $colorClass = 'text-slate-800 bg-slate-50 border-slate-100';
                } elseif ($isVideo) {
                    $icon = 'fa-brands fa-youtube';
                    $colorClass = 'text-red-500 bg-red-50 border-red-100';
                }

                // Helper to extract YouTube Video ID
                preg_match('%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^"&?/ ]{11})%i', $t->link, $match);
                $youtubeId = $match[1] ?? null;
            @endphp
            <div class="bg-white border border-slate-100 p-4 rounded-3xl shadow-[0_4px_20px_rgba(0,0,0,0.01)] transition-all duration-300 overflow-hidden task-card" id="task-card-{{ $t->id }}">
                @if ($isVideo)
                    <div class="p-1 mb-3">
                        <div class="relative w-full pb-[56.25%] h-0 bg-black rounded-2xl overflow-hidden border border-slate-100 shadow-inner">
                            @if (!empty($youtubeId))
                                <iframe id="video-iframe-{{ $t->id }}" class="absolute top-0 left-0 w-full h-full border-0" src="" allow="autoplay" allowfullscreen></iframe>
                            @else
                                <div class="absolute inset-0 flex items-center justify-center text-slate-400 text-xs bg-slate-900">Invalid YouTube Link</div>
                            @endif
                        </div>
                    </div>
                @endif

                <div class="p-1">
                    <div class="flex justify-between items-start mb-4">
                        <div class="flex gap-3">
                            <div class="w-10 h-10 rounded-xl flex items-center justify-center text-lg border {{ $colorClass }} shrink-0">
                                <i class="{{ $icon }}"></i>
                            </div>
                            <div class="space-y-0.5 text-left">
                                <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide leading-normal">{{ htmlspecialchars($t->name) }}</h4>
                                <p class="text-[8px] text-slate-455 font-bold uppercase tracking-wider mt-0.5">Platform: {{ $t->task_type }}</p>
                            </div>
                        </div>
                        <span class="text-xs font-black text-emerald-600 block shrink-0">🪙 +{{ number_format($t->reward_amount, 2) }}</span>
                    </div>

                    <div id="game-controls-wrapper-{{ $t->id }}" class="w-full">
                        @if ($isLimitReached)
                            <button disabled class="w-full py-3.5 bg-slate-100 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-widest cursor-not-allowed select-none">Daily Limit Reached 🔒</button>
                        @else
                            <div class="flex gap-2" id="action-wrapper-{{ $t->id }}">
                                <a href="{{ $t->link }}" target="_blank" onclick="startTask('{{ $t->id }}')" class="flex-1 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-center text-xs font-black uppercase tracking-wider bouncy-hover">
                                    Start Mission 🚀
                                </a>
                                <form method="POST" action="{{ route('task.claim') }}" class="flex-1">
                                    @csrf
                                    <input type="hidden" name="task_id" value="{{ $t->id }}">
                                    <button type="submit" id="claim-btn-{{ $t->id }}" disabled class="w-full py-3 bg-slate-100 text-slate-400 border border-slate-200 rounded-xl font-black text-xs uppercase tracking-wider cursor-not-allowed">
                                        Verify <span id="countdown-{{ $t->id }}">{{ $watchSeconds }}s</span> ⏱️
                                    </button>
                                </form>
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach

        @if ($allTasks->isEmpty())
            <div class="text-center py-20 bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                <span class="text-6xl mb-4 block">✅</span>
                <p class="text-xs font-black text-slate-400 uppercase tracking-widest">All tasks completed! Come back later.</p>
            </div>
        @endif
    </div>
</div>
@endsection

@push('scripts')
<script>
    let isTaskSpamLocked = false;
    // Fix: adRestricted checked dynamically from global helpers to prevent Undefined variable crashes
    const adRestricted = {{ is_ad_restricted(session('user_id')) ? 'true' : 'false' }};

    function startTask(id) {
        if (adRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert("🚨 Access Restricted: Multi-account ad viewing detected on this device.");
            }
            return;
        }

        if (isTaskSpamLocked) {
            if (window.GlobalPopup) {
                GlobalPopup.show('warning', 'Spam Warning', 'Please wait 5 seconds before clicking another task.');
            } else {
                alert("🚨 Anti-Spam: Please wait 5 seconds before clicking another task.");
            }
            return;
        }

        isTaskSpamLocked = true;
        setTimeout(() => { isTaskSpamLocked = false; }, 5000);

        localStorage.setItem('active_task_id', id);
        evaluateTaskLocks();

        fetch(`{{ route('task.start') }}?task_id=${id}`)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    const videoId = "{{ $youtubeId ?? '' }}";
                    const iframe = document.getElementById(`video-iframe-${id}`);
                    if (iframe && videoId) {
                        iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&enablejsapi=1`;
                    }

                    const claimBtn = document.getElementById(`claim-btn-${id}`);
                    const countdownLabel = document.getElementById(`countdown-${id}`);
                    
                    let seconds = "{{ $watchSeconds }}";
                    let remaining = seconds;

                    const interval = setInterval(() => {
                        remaining--;
                        if (countdownLabel) countdownLabel.innerText = remaining + "s";

                        if (remaining <= 0) {
                            clearInterval(interval);
                            if (claimBtn) {
                                claimBtn.disabled = false;
                                claimBtn.className = "w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs uppercase tracking-wider bouncy-hover";
                                claimBtn.innerHTML = "Claim Reward ⚡";
                            }
                            triggerVibration('medium');
                        }
                    }, 1000);
                } else {
                    alert(data.message || 'Initialization failed.');
                    localStorage.removeItem('active_task_id');
                    evaluateTaskLocks();
                }
            });
    }

    function evaluateTaskLocks() {
        const activeId = localStorage.getItem('active_task_id');
        if (activeId) {
            document.querySelectorAll('.task-card').forEach(card => {
                if (card.id !== `task-card-${activeId}`) {
                    card.style.opacity = '0.35';
                    card.style.pointerEvents = 'none';
                    card.style.filter = 'grayscale(1)';
                }
            });
        } else {
            document.querySelectorAll('.task-card').forEach(card => {
                card.style.opacity = '1';
                card.style.pointerEvents = 'auto';
                card.style.filter = 'none';
            });
        }
    }

    function clearActiveTaskSession() {
        localStorage.removeItem('active_task_id');
    }
</script>
@endpush