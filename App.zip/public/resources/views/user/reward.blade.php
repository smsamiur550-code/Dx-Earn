@extends('layouts.app')

@section('title', 'Daily Bonus - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-90 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Bonus Hub 🎁</h1>
    <div class="px-3 py-1 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div class="bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-600 p-5 text-white flex justify-between items-center relative overflow-hidden">
            <div class="relative z-10 space-y-1 text-left">
                <span class="text-[8px] font-black uppercase tracking-widest text-slate-100 opacity-90">Cycle Progress</span>
                <h2 class="text-2xl font-black text-white">{{ substr_count($streakMask, '1') }} / 7 Claims</h2>
                <div class="w-24 h-1.5 bg-white/25 rounded-full overflow-hidden mt-1">
                    <div class="h-full bg-amber-300 rounded-full" style="width: {{ (substr_count($streakMask, '1') / 7) * 100 }}%"></div>
                </div>
            </div>
            <div class="text-right z-10">
                <span class="text-[8px] font-black uppercase tracking-wider block opacity-75">Total Claims</span>
                <span class="text-lg font-black block">{{ $rewardsData->total_claimed }} Days</span>
            </div>
            <i class="fa-solid fa-gift absolute -right-6 -bottom-6 text-7xl opacity-5"></i>
        </div>

        <div class="p-4 space-y-4 bg-white">
            <div class="grid grid-cols-4 gap-2">
                @for ($day = 1; $day <= 7; $day++)
                    @php
                        $bitClaimed = (substr($streakMask, $day - 1, 1) === '1');
                        $isMissed = (!$bitClaimed && $day < $currentDayOfCycle);
                        $isCurrent = ($day === $currentDayOfCycle && !$isClaimedToday);
                        $isLocked = ($day > $currentDayOfCycle);
                        
                        $bgClass = "bg-slate-50 border-slate-100 text-slate-400";
                        if ($bitClaimed) {
                            $bgClass = "bg-emerald-50 border-emerald-100 text-emerald-600";
                        } elseif ($isMissed) {
                            $bgClass = "bg-rose-50 border-rose-100 text-rose-500";
                        } elseif ($isCurrent) {
                            $bgClass = "bg-blue-50 text-blue-600 border-blue-200 ring-2 ring-blue-500/5";
                        }
                    @endphp
                    <div class="p-2 border rounded-xl flex flex-col items-center justify-between text-center relative overflow-hidden h-20 {{ $bgClass }} {{ ($day === 7) ? 'col-span-2' : '' }}">
                        <span class="text-[8px] font-black uppercase tracking-wider block">Day {{ $day }}</span>
                        
                        <div class="my-0.5 text-sm">
                            @if ($bitClaimed)
                                <span>✅</span>
                            @elseif ($isMissed)
                                <span>❌</span>
                            @elseif ($isLocked)
                                <span class="opacity-40">🔒</span>
                            @else
                                <span class="animate-pulse text-blue-500 font-bold">⚡</span>
                            @endif
                        </div>

                        <span class="text-[8px] font-black block leading-none">
                            +🪙 {{ number_format($dayPayouts[$day] * $multiplier) }}
                        </span>
                    </div>
                @endfor
            </div>

            <form method="POST" action="{{ route('reward.claim') }}" class="pt-1">
                @csrf
                @if ($isClaimedToday)
                    <div class="w-full py-3.5 bg-slate-100 text-slate-400 border border-slate-200 rounded-xl font-black text-xs uppercase tracking-widest text-center select-none flex items-center justify-center gap-2">
                        ⏳ Next in: <span id="claim-countdown" class="font-mono">00:00:00</span>
                    </div>
                @else
                    <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-widest flex items-center justify-center gap-2 bouncy-hover btn-glow-blue">
                        🎁 Claim Day {{ $currentDayOfCycle }} Bonus (+🪙 {{ number_format($claimableAmount) }})
                    </button>
                @endif
            </form>
        </div>
    </div>
</main>
@endsection

@push('scripts')
@if ($secondsRemaining > 0)
<script>
    let countdownSec = {{ $secondsRemaining }};
    const displayEl = document.getElementById('claim-countdown');
    function tick() {
        if (countdownSec <= 0) {
            location.reload();
            return;
        }
        countdownSec--;
        let h = Math.floor(countdownSec / 3600);
        let m = Math.floor((countdownSec % 3600) / 60);
        let s = countdownSec % 60;
        displayEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
    }
    setInterval(tick, 1000);
    tick();
</script>
@endif
@endpush