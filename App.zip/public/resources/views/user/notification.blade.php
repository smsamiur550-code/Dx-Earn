@extends('layouts.app')

@section('title', 'Notifications - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Notification Hub 🔔</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-3 flex-grow">
    <div class="space-y-3">
        @foreach ($notifications as $row)
            @php
                $type = strtolower($row->type ?? 'general');
                $isUnread = (strtolower($row->status ?? '') === 'unread');
                
                $emoji = '🔔';
                $colorClass = 'text-blue-500 bg-blue-50 border-blue-100';

                if ($type === 'kyc') {
                    $emoji = '🛡️';
                    $colorClass = 'text-emerald-500 bg-emerald-50 border-emerald-100';
                } elseif ($type === 'reward') {
                    $emoji = '🎁';
                    $colorClass = 'text-amber-500 bg-amber-50 border-amber-100';
                } elseif ($type === 'vip') {
                    $emoji = '👑';
                    $colorClass = 'text-purple-500 bg-purple-50 border-purple-100';
                } elseif ($type === 'lottery') {
                    $emoji = '🎫';
                    $colorClass = 'text-violet-500 bg-violet-50 border-violet-100';
                } elseif ($type === 'shop') {
                    $emoji = '🛍️';
                    $colorClass = 'text-rose-500 bg-rose-50 border-rose-100';
                } elseif ($type === 'mining') {
                    $emoji = '⛏️';
                    $colorClass = 'text-cyan-500 bg-cyan-50 border-cyan-100';
                } elseif ($type === 'referral') {
                    $emoji = '🤝';
                    $colorClass = 'text-teal-500 bg-teal-50 border-teal-100';
                } elseif ($type === 'gift') {
                    $emoji = '🎁';
                    $colorClass = 'text-pink-500 bg-pink-50 border-pink-100';
                } elseif ($type === 'login') {
                    $emoji = '🔑';
                    $colorClass = 'text-slate-800 bg-slate-50 border-slate-150';
                }
            @endphp
            <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex gap-3.5 items-start relative hover:shadow-[0_4px_15px_rgba(0,0,0,0.01)] transition-shadow duration-200">
                @if ($isUnread)
                    <span class="absolute top-4 right-4 w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping"></span>
                    <span class="absolute top-4 right-4 w-2.5 h-2.5 bg-blue-500 rounded-full"></span>
                @endif

                <div class="w-10 h-10 rounded-2xl flex items-center justify-center text-lg border {{ $colorClass }} shrink-0">
                    <span>{{ $emoji }}</span>
                </div>

                <div class="space-y-1 pr-4">
                    <p class="text-xs font-semibold text-slate-700 leading-normal break-words text-left">
                        {{ $row->message }}
                    </p>
                    <span class="text-[8px] text-slate-400 font-bold uppercase block text-left">
                        {{ $row->created_at->format('d M Y • h:i A') }}
                    </span>
                </div>
            </div>
        @endforeach

        @if ($notifications->isEmpty())
            <div class="text-center py-20 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <span class="text-5xl mb-4 block">🔔</span>
                <p class="text-xs font-black text-slate-400 uppercase tracking-widest">Your inbox is completely clear!</p>
            </div>
        @endif
    </div>
</main>
@endsection