@extends('layouts.app')

@section('title', 'Mining - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-90 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Mining Node ⚡</h1>
    <div class="px-3 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<div class="p-4 space-y-4">
    @if(session('success'))
        <div class="bg-emerald-50 text-emerald-600 border border-emerald-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2 animate-bounce-subtle">
            <span>✅</span> {{ session('success') }}
        </div>
    @endif
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center relative overflow-hidden">
        <div class="relative w-40 h-40 mx-auto my-4 flex items-center justify-center">
            <div class="absolute inset-0 bg-gradient-to-tr from-blue-400 via-indigo-400 to-purple-500 rounded-full ring-pulse opacity-20"></div>
            <div class="w-36 h-36 bg-slate-50 rounded-full flex flex-col items-center justify-center shadow-md relative z-10 border-4 border-white">
                <div class="text-blue-550 mb-1">
                    <i class="fa-solid fa-microchip text-4xl {{ ($isActive && !$isStorageFull) ? 'animate-spin' : '' }}" style="animation-duration: 8s; transform-origin: center;"></i>
                </div>
                <span class="text-[9px] font-black tracking-widest uppercase text-slate-400">
                    {{ $isActive ? ($isStorageFull ? 'Full' : 'MINING') : 'Idle' }}
                </span>
            </div>
        </div>

        <div class="space-y-1">
            <h2 class="text-4xl font-black text-slate-800 tracking-tight tabular-nums flex items-center justify-center gap-1.5">
                🪙 <span id="live-counter">{{ number_format($pendingCoins, 5) }}</span>
            </h2>
            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Accumulated DX Coins</p>
        </div>

        <div class="grid grid-cols-3 gap-2 mt-6 pt-4 border-t border-slate-100 text-center">
            <div class="bg-amber-50 border border-amber-100 p-2.5 rounded-2xl col-span-3">
                <span class="text-[7px] text-slate-500 font-black block uppercase tracking-wider">Yield Rate</span>
                <span class="text-xs font-black text-amber-600 block mt-0.5">⚡ 🪙 {{ number_format($baseRateHourly * $speedMult, 2) }}/H</span>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-2 mt-2 text-center">
            <div class="bg-emerald-50 border border-emerald-100 p-2.5 rounded-2xl">
                <span class="text-[7px] text-slate-500 font-black block uppercase tracking-wider">Node Capacity</span>
                <span class="text-xs font-black text-emerald-600 block mt-0.5">📁 {{ round($totalDuration / 3600, 1) }}h</span>
            </div>
            <div class="bg-rose-50 border border-rose-100 p-2.5 rounded-2xl">
                <span class="text-[7px] text-slate-500 font-black block uppercase tracking-wider">Multiplier Speed</span>
                <span class="text-xs font-black text-rose-600 block mt-0.5">⏱️ {{ $speedMult }}x</span>
            </div>
        </div>

        <div class="mt-6 space-y-2 text-left">
            <div class="flex justify-between items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                <span>Storage Progress</span>
                <span id="countdown-timer" class="font-bold text-blue-600 font-mono">{{ $isActive ? ($isStorageFull ? 'STORAGE FULL' : 'Calculating...') : '00:00:00' }}</span>
            </div>
            <div class="w-full h-3 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
                <div id="progress-indicator" class="h-full bg-gradient-to-r from-blue-400 via-indigo-500 to-purple-600 transition-all duration-1000" style="width: {{ $progressPercent }}%"></div>
            </div>
        </div>

        <div class="mt-6 space-y-3">
            <div class="space-y-3">
                @if (!$isActive)
                    <form method="POST" action="{{ route('mining.start') }}">
                        @csrf
                        <button type="submit" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover btn-glow-blue">
                            ▶ Start Mining Node
                        </button>
                    </form>
                @else
                    <form method="POST" action="{{ route('mining.claim') }}">
                        @csrf
                        <button type="submit" class="w-full py-4 {{ $isStorageFull ? 'bg-emerald-600 hover:bg-emerald-700 btn-glow-emerald' : 'bg-slate-800 hover:bg-slate-900' }} text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover">
                            📥 {{ $isStorageFull ? 'Collect & Restart' : 'Claim Earnings' }}
                        </button>
                    </form>
                @endif
            </div>

            <div id="boost-section-wrapper" class="w-full">
                @if ($isBoosted)
                    <div class="w-full py-4 bg-gradient-to-r from-amber-500 to-orange-500 text-white rounded-2xl font-black text-xs uppercase tracking-wider text-center">
                        ⚡ Boost Active ({{ $boostMultiplierConfig }}x) - <span id="boost-expiry-timer">00:00:00</span>
                    </div>
                @elseif ($cooldownRemainingSec > 0)
                    <button disabled class="w-full py-4 bg-slate-200 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-wider cursor-not-allowed">
                        ⏱️ Boost Cooldown: <span id="cooldown-expiry-timer">00:00:00</span>
                    </button>
                @else
                    <button id="trigger-boost-btn" onclick="startBoostFlow()" class="w-full py-4 bg-amber-500 hover:bg-amber-600 text-white rounded-2xl font-black text-xs uppercase tracking-wider active:scale-95 transition-transform duration-105 flex items-center justify-center gap-1.5 bouncy-hover btn-glow-amber">
                        ⚡ Boost Hashing ({{ $boostMultiplierConfig }}x)
                    </button>
                @endif
            </div>
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Claim History</h3>
        <div class="space-y-2">
            @foreach ($claimsHistory as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-450 uppercase tracking-widest block">Cloud Miner Claim</span>
                        <span class="font-extrabold text-slate-700">Earnings Credited</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ date('h:i A', strtotime($log->created_at)) }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->amount, 4) }}</span>
                    </div>
                </div>
            @endforeach

            @if (empty($claimsHistory))
                <p class="text-center text-slate-455 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No mining claims logged today.</p>
            @endif
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const isActive = {{ $isActive ? 'true' : 'false' }};
    const adWaitDuration = {{ $adWaitSec }};
    const monetagAdLink = "{{ $monetagLink }}";
    let boostExpiryRemaining = {{ $boostExpirySec }};
    let cooldownRemaining = {{ $cooldownRemainingSec }};
    
    if (isActive) {
        let currentCoins = {{ $pendingCoins }};
        const rateSec = {{ $coinRateSec }};
        const speedMultiplier = {{ $speedMult }};
        let physicalSecondsRemaining = {{ $secondsRemaining }};
        const totalDurationSec = {{ $totalDuration }};
        let isFull = {{ $isStorageFull ? 'true' : 'false' }};

        const counterEl = document.getElementById('live-counter');
        const timerEl = document.getElementById('countdown-timer');
        const progressEl = document.getElementById('progress-indicator');

        function updateTick() {
            if (!isFull) {
                currentCoins += (rateSec * speedMultiplier);
                counterEl.innerText = currentCoins.toFixed(5);

                if (physicalSecondsRemaining > 0) {
                    physicalSecondsRemaining--;
                    
                    let h = Math.floor(physicalSecondsRemaining / 3600);
                    let m = Math.floor((physicalSecondsRemaining % 3600) / 60);
                    let s = physicalSecondsRemaining % 60;
                    timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
                    
                    let elapsedVirtual = totalDurationSec - (physicalSecondsRemaining * speedMultiplier);
                    let progPercent = Math.min(100, (elapsedVirtual / totalDurationSec) * 100);
                    progressEl.style.width = progPercent + "%";
                } else {
                    isFull = true;
                    timerEl.innerText = "STORAGE FULL";
                    progressEl.style.width = "100%";
                }
            } else {
                timerEl.innerText = "STORAGE FULL";
            }
        }

        setInterval(updateTick, 1000);
        updateTick();
    }

    if (boostExpiryRemaining > 0) {
        const expiryTimerEl = document.getElementById('boost-expiry-timer');
        setInterval(() => {
            if (boostExpiryRemaining > 0) {
                boostExpiryRemaining--;
                let h = Math.floor(boostExpiryRemaining / 3600);
                let m = Math.floor((boostExpiryRemaining % 3600) / 60);
                let s = boostExpiryRemaining % 60;
                expiryTimerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
            } else {
                window.location.reload();
            }
        }, 1000);
    }

    if (cooldownRemaining > 0) {
        const cooldownTimerEl = document.getElementById('cooldown-expiry-timer');
        setInterval(() => {
            if (cooldownRemaining > 0) {
                cooldownRemaining--;
                let h = Math.floor(cooldownRemaining / 3600);
                let m = Math.floor((cooldownRemaining % 3600) / 60);
                let s = cooldownRemaining % 60;
                cooldownTimerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
            } else {
                window.location.reload();
            }
        }, 1000);
    }

    function startBoostFlow() {
        const btn = document.getElementById('trigger-boost-btn');
        btn.disabled = true;
        btn.innerText = "Initializing timer...";
        
        const fd = new FormData();
        fd.append('_token', '{{ csrf_token() }}');
        fd.append('action_start_boost', '1');
        
        fetch("{{ route('mining.boost.start') }}", {
            method: 'POST',
            body: fd
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagAdLink, '_blank');
                let waitTime = adWaitDuration;
                
                const interval = setInterval(() => {
                    if (waitTime > 0) {
                        btn.innerText = `Waiting for Ad: ${waitTime}s ⏱️`;
                        waitTime--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Claiming Boost... ⚡";
                        claimBoost();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Boost Hashing ⚡";
                alert(data.message || 'Validation failed.');
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Boost Hashing ⚡";
        });
    }

    function claimBoost() {
        const btn = document.getElementById('trigger-boost-btn');
        const fd = new FormData();
        fd.append('_token', '{{ csrf_token() }}');
        fd.append('action_claim_boost', '1');
        
        fetch("{{ route('mining.boost.claim') }}", {
            method: 'POST',
            body: fd
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush