@extends('layouts.app')

@section('title', 'Live Status - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('withdraw') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Live Payout Status 🚀</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    <div class="bg-gradient-to-r from-emerald-500 to-teal-600 p-5 rounded-[2rem] text-white text-center shadow-md relative overflow-hidden glow-emerald">
        <span class="absolute top-3 right-3 flex h-3 w-3">
            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-100 opacity-75"></span>
            <span class="relative inline-flex rounded-full h-3 w-3 bg-emerald-300"></span>
        </span>
        <span class="text-[9px] font-black uppercase tracking-widest block opacity-75 mb-1">Global Payout Stream</span>
        <h3 class="text-lg font-black uppercase tracking-wide">Realtime Verification Ledger</h3>
        <p class="text-[10px] text-teal-50 font-semibold leading-relaxed mt-2">Displaying direct cryptographic payouts, withdraw distributions and game voucher claims processed globally across our decentralized cloud infrastructure.</p>
    </div>

    <div class="space-y-3">
        <div class="flex justify-between items-center ml-1">
            <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest">Live Transaction Stream</h3>
            <span class="text-[8px] bg-emerald-100 text-emerald-800 font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">● Live Feed</span>
        </div>
        
        <div class="space-y-2.5" id="payout-stream-container">
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    const usersPool = ['@rakib_33', '@sara_crypto', '@arnob_king', '@shakib_99', '@tasnim_dx', '@tonmoy_dx', '@dubaival_dx', '@king_earn', '@tasnim_pay', '@shohan_dx', '@mim_bt', '@fahim_usdt', '@milon_win', '@tina_77', '@rakib_vip', '@monir_dx', '@ruma_mining', '@ashik_90', '@mithu_pay'];
    const gatewaysPool = ['Binance Pay', 'Trust Wallet', 'Free Fire Diamond Topup 🎮'];
    const amountsPool = [5.00, 10.00, 15.00, 25.00, 50.00, 100.00];
    const takaRate = {{ $takaRate }};

    function generateRandomPayout() {
        const user = usersPool[Math.floor(Math.random() * usersPool.length)];
        const gateway = gatewaysPool[Math.floor(Math.random() * gatewaysPool.length)];
        let amountVal = amountsPool[Math.floor(Math.random() * amountsPool.length)];
        
        let amountStr = (amountVal * takaRate).toFixed(2) + ' ৳';
        let detailStr = 'Payout Distributed';

        if (gateway === 'Free Fire Diamond Topup 🎮') {
            let diamonds = 100;
            if (amountVal === 5.00) diamonds = 520;
            else if (amountVal === 10.00) diamonds = 1060;
            else if (amountVal === 15.00) diamonds = 1600;
            else if (amountVal === 25.00) diamonds = 2750;
            else diamonds = 100;

            amountStr = '💎 ' + diamonds;
            detailStr = 'Diamonds Voucher Credited';
        }

        const now = new Date();
        const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

        const row = document.createElement('div');
        row.className = 'bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs live-payout-row';
        row.innerHTML = `
            <div class="space-y-0.5 text-left">
                <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Withdrawal Voucher</span>
                <span class="font-extrabold text-slate-700">${user}</span>
                <span class="text-[8px] font-bold text-slate-400 block">${gateway} • ${detailStr}</span>
                <span class="text-[8px] font-bold text-slate-400 block">${timeStr}</span>
            </div>
            <div class="text-right">
                <span class="text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-wider block text-emerald-500 bg-emerald-50">COMPLETED</span>
                <span class="font-black text-emerald-600 block text-sm mt-1">${amountStr}</span>
            </div>
        `;

        const container = document.getElementById('payout-stream-container');
        if (container) {
            container.prepend(row);
            if (container.children.length > 12) {
                container.removeChild(container.lastChild);
            }
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        for (let i = 0; i < 5; i++) {
            generateRandomPayout();
        }
        setInterval(generateRandomPayout, 3500);
    });
</script>
@endpush