@extends('layouts.app')

@section('title', 'Profile - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">My Profile 👤</h1>
    <a href="{{ route('logout') }}" class="text-rose-500 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-power-off text-lg"></i>
    </a>
</div>

<div class="p-4 space-y-4">
    <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm text-center">
        <div class="relative w-24 h-24 mx-auto mb-3">
            <img src="{{ get_avatar_url($user->profile_pic) }}" class="w-full h-full rounded-full object-cover border-4 border-slate-100 shadow-sm">
        </div>
        <h2 class="text-lg font-black text-slate-900">{{ htmlspecialchars($user->full_name) }}</h2>
        <p class="text-xs text-slate-400 font-semibold mt-0.5">{{ format_username($user->username) }}</p>
        <div class="flex justify-center mt-3">
            {!! get_kyc_badge($user->kyc_status) !!}
        </div>
        <div class="pt-4 mt-4 border-t border-slate-100 flex justify-between text-[10px] text-slate-400 font-black uppercase">
            <span>Joined: {{ $user->created_at->format('d M Y') }}</span>
            <span>ID: {{ $user->id }}</span>
        </div>
    </div>

    <div class="grid grid-cols-2 gap-2.5">
        <div class="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm text-center">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">DX Coins ⛏️</span>
            <span class="text-sm font-black text-blue-600 block mt-1">{{ number_format($user->balance_coin, 2) }} DX Coin</span>
        </div>
        <div class="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm text-center">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">DX Tokens 🟡</span>
            <span class="text-sm font-black text-amber-500 block mt-1">{{ number_format($user->balance_token, 2) }} DX Token</span>
        </div>
        <div class="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm text-center">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">Converted BDT ৳</span>
            <span class="text-sm font-black text-emerald-600 block mt-1">{{ number_format($user->balance_dollar * $takaRate, 2) }} ৳</span>
        </div>
        <div class="bg-white p-3.5 rounded-2xl border border-slate-100 shadow-sm text-center">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-wider block">Referral BDT 🤝</span>
            <span class="text-sm font-black text-purple-600 block mt-1">{{ number_format(($user->balance_referral_dollar ?? 0) * $takaRate, 2) }} ৳</span>
        </div>
    </div>

    <div class="space-y-2">
        <a href="{{ route('settings', ['tab' => 'profile']) }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">⚙️</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Account Settings</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Edit full name, email & profile avatar</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>

        <a href="{{ route('settings', ['tab' => 'kyc']) }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">🪪</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Identity KYC</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Submit verification documents</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>

        <!-- Ledger History corrected to route('history') -->
        <a href="{{ route('history') }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">📜</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Ledger History</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Track conversion & withdrawal requests</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>

        <!-- Network Rankings corrected to route('leaderboard') -->
        <a href="{{ route('leaderboard') }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">🏆</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Network Rankings</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Check global weekly high scorers</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>

        <a href="{{ route('lottery') }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">🎫</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Weekly Lottery</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Check sweepstakes, draw prizes & rules</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>

        <a href="{{ route('privacy') }}" class="profile-nav-card bg-white p-4 rounded-2xl flex items-center justify-between bouncy-hover">
            <div class="flex items-center gap-3">
                <span class="text-xl">🛡️</span>
                <div class="text-left">
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">Privacy & Terms</h4>
                    <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">Information collection & safety policy</p>
                </div>
            </div>
            <i class="fa-solid fa-chevron-right text-slate-350 text-xs"></i>
        </a>
    </div>
</div>
@endsection