@extends('layouts.app')

@section('title', 'Promo Codes - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Promotion Codes 🎁</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2 leading-relaxed">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif
   
    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.01)] text-center space-y-5">
        <div class="w-14 h-14 bg-gradient-to-tr from-pink-500 to-rose-500 text-white rounded-2xl flex items-center justify-center mx-auto text-2xl shadow-inner border border-pink-100/30">
            🎁
        </div>
        
        <div>
            <h2 class="text-base font-black text-slate-800 uppercase tracking-wide">Redeem Promotion Code</h2>
            <p class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Acquire promo balances securely</p>
        </div>

        <form method="POST" action="{{ route('gift.redeem') }}" class="space-y-4" id="giftForm">
            @csrf
            <input type="text" name="gift_code" placeholder="DX-CODE-XXXX" required autocomplete="off" class="w-full py-4 bg-slate-50 border border-slate-100 focus:border-blue-400 focus:bg-white rounded-2xl text-base font-black text-center text-slate-800 tracking-widest outline-none transition-all uppercase shadow-inner">
            <button type="submit" id="claimBtn" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 tracking-wider uppercase flex items-center justify-center gap-1.5 action-btn bouncy-hover btn-glow-blue">
                Claim Code Rewards ⚡
            </button>
        </form>
    </div>

    @php 
        $tgGroup = get_setting_val('telegram_group_link') ?: "https://t.me/DXEarn_Official";
    @endphp
    <a href="{{ htmlspecialchars($tgGroup) }}" target="_blank" class="block bg-blue-50 border border-blue-100 p-5 rounded-[2.2rem] active:scale-95 transition-transform duration-100">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-white border border-blue-150 rounded-2xl flex items-center justify-center text-lg shadow-inner">
                <i class="fa-brands fa-telegram-plane text-blue-500"></i>
            </div>
            <div class="space-y-0.5 text-left">
                <h4 class="text-xs font-black uppercase tracking-wide text-blue-600">Looking For Codes?</h4>
                <p class="text-[10px] text-slate-400 font-semibold">Join official Telegram community to grab new drops</p>
            </div>
            <i class="fa-solid fa-arrow-up-right-from-square text-blue-500 text-xs ml-auto mr-1 animate-pulse"></i>
        </div>
    </a>

    <div class="bg-white p-5 rounded-[2.5rem] border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.01)] space-y-4">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center">
            <span>🕒</span> <span class="ml-2">Last 24 Hours Gift Claims Log</span>
        </h3>
        
        <div class="space-y-3.5 divide-y divide-slate-100">
            @foreach ($redeemHistory as $index => $row)
                <div class="flex justify-between items-center {{ ($index > 0) ? 'pt-3.5' : '' }}">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center text-xs">
                            <span>✅</span>
                        </div>
                        <div class="text-left">
                            <h4 class="text-xs font-black text-slate-700">#{{ htmlspecialchars($row->code) }}</h4>
                            <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">{{ date('h:i A', strtotime($row->claimed_at)) }}</p>
                        </div>
                    </div>
                    <div class="text-right">
                        <span class="text-xs font-black text-emerald-500">🪙 +{{ number_format($row->reward_amount, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($redeemHistory->isEmpty())
                <div class="text-center py-8 opacity-50 flex flex-col items-center justify-center">
                    <span class="text-3xl mb-2">📦</span>
                    <p class="text-[9px] font-black uppercase tracking-wider text-slate-400">No redemptions logged today</p>
                </div>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    document.getElementById('giftForm').addEventListener('submit', function() {
        document.getElementById('claimBtn').disabled = true;
    });
</script>
@endpush