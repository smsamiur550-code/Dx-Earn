@extends('layouts.app')

@section('title', 'Orders - DX Shop')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('shop') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">My Orders 📦</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow pb-24">
    <div class="bg-blue-50 border border-blue-100 p-4 rounded-3xl text-center text-xs leading-relaxed text-blue-700 font-bold shadow-inner">
        🚚 Trace shipping status and delivery updates of your retail orders. Click on any item below to view full details.
    </div>
    
    <div class="space-y-3.5">
        @foreach ($orders as $ord)
            @php 
                $status = strtolower($ord->status ?? 'pending');
                $badge = 'bg-amber-50 text-amber-600 border-amber-200';
                $statusLabel = 'Pending';
                if ($status === 'processing') {
                    $badge = 'bg-blue-50 text-blue-600 border-blue-200';
                    $statusLabel = 'Processing';
                } elseif ($status === 'shipped' || $status === 'on_way') {
                    $badge = 'bg-purple-50 text-purple-600 border-purple-200';
                    $statusLabel = 'On Way';
                } elseif ($status === 'completed' || $status === 'delivered') {
                    $badge = 'bg-emerald-50 text-emerald-600 border-emerald-200';
                    $statusLabel = 'Delivered';
                } elseif ($status === 'cancelled') {
                    $badge = 'bg-rose-50 text-rose-600 border-rose-200';
                    $statusLabel = 'Cancelled';
                }

                $coinDeductedVal = floatval($ord->coin_deducted);
                $codAmountBdt = floatval($ord->cod_amount) * $takaRate;
                $totalPriceBdt = floatval($ord->total_price) * $takaRate;
                $discountCashBdt = floatval($ord->discount_cash) * $takaRate;
                $deliveryChargeBdt = floatval($ord->delivery_charge) * $takaRate;

                $ordJson = json_encode([
                    'id' => $ord->id,
                    'status_label' => $statusLabel,
                    'badge_class' => $badge,
                    'product_name' => htmlspecialchars($ord->product_name),
                    'product_image' => htmlspecialchars($ord->product_image),
                    'ticket_number' => htmlspecialchars($ord->ticket_number ?? 'N/A'),
                    'recipient_name' => htmlspecialchars($ord->name),
                    'recipient_phone' => htmlspecialchars($ord->phone),
                    'recipient_address' => htmlspecialchars($ord->address),
                    'coin_percentage' => intval($ord->coin_percentage),
                    'coin_deducted' => $coinDeductedVal,
                    'total_price_bdt' => $totalPriceBdt,
                    'discount_cash_bdt' => $discountCashBdt,
                    'delivery_charge_bdt' => $deliveryChargeBdt,
                    'cod_amount_bdt' => $codAmountBdt,
                    'date' => date('d M Y, h:i A', strtotime($ord->created_at))
                ]);
            @endphp
            <!-- Fix: Passed base64 encoded string to onclick to bypass JS quotes crashing -->
            <div onclick="openOrderDetailModal('{{ base64_encode($ordJson) }}')" class="bg-white p-4 rounded-[2rem] shadow-sm flex items-center justify-between order-card cursor-pointer bouncy-hover">
                <div class="flex items-center gap-3">
                    <img src="{{ asset('uploads/' . ($ord->product_image ?? 'default.png')) }}" class="w-12 h-12 rounded-2xl object-cover shrink-0 border border-slate-100 shadow-sm">
                    <div class="text-left">
                        <h4 class="text-xs font-black text-slate-700 truncate w-36 uppercase tracking-wide">{{ htmlspecialchars($ord->product_name) }}</h4>
                        <p class="text-[8px] text-slate-400 font-bold">Order: #ORD-{{ $ord->id }}</p>
                        <p class="text-[8px] text-slate-400 font-bold mt-0.5">Date: {{ date('d M Y, h:i A', strtotime($ord->created_at)) }}</p>
                    </div>
                </div>
                <div class="text-right shrink-0">
                    <span class="text-[8px] font-black border {{ $badge }} px-2.5 py-1 rounded-md uppercase tracking-wider block w-fit ml-auto mb-1.5">{{ $statusLabel }}</span>
                    <span class="text-[9px] font-black text-amber-500 block leading-none">💵 -{{ number_format($coinDeductedVal, 2) }}</span>
                    <span class="text-[9px] font-black text-emerald-600 block mt-1 leading-none">{{ number_format($codAmountBdt, 2) }} ৳</span>
                </div>
            </div>
        @endforeach

        @if ($orders->isEmpty())
            <div class="text-center py-20 bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                <span class="text-5xl mb-4 block">📋</span>
                <p class="text-xs font-black text-slate-400 uppercase tracking-widest">No order logs tracked.</p>
                <a href="{{ route('shop') }}" class="inline-block mt-4 text-[10px] bg-blue-600 text-white font-black px-5 py-2.5 rounded-full uppercase tracking-wider bouncy-hover">Go to Shop</a>
            </div>
        @endif
    </div>
</main>

<div id="orderDetailsModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white w-full max-w-[380px] rounded-[2.5rem] p-6 border border-slate-150 shadow-2xl relative flex flex-col justify-between max-h-[85vh] overflow-y-auto no-scrollbar">
        <button onclick="closeOrderDetailModal()" class="absolute top-4 right-4 text-slate-400 active:scale-75 transition-all text-xl"><i class="fa-solid fa-times-circle"></i></button>
        
        <div class="space-y-4">
            <div class="text-center">
                <span class="text-3xl block">📦</span>
                <h3 class="text-base font-black text-slate-900 uppercase mt-2">Order Specifics</h3>
                <p class="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Reference ID: #ORD-<span id="m-order-id"></span></p>
                <span id="m-order-status" class="text-[8px] font-black border px-2.5 py-1 rounded-md uppercase tracking-wider block w-fit mx-auto mt-2"></span>
            </div>

            <div class="flex items-center gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-100 shadow-inner">
                <img id="m-product-image" class="w-12 h-12 rounded-xl object-cover border border-slate-150 shrink-0">
                <div class="text-left">
                    <span class="text-[8px] font-black text-slate-400 block uppercase tracking-widest leading-none">Purchased Product</span>
                    <span id="m-product-name" class="text-xs font-black text-slate-800 uppercase block mt-1 truncate w-48"></span>
                </div>
            </div>

            <div id="m-ticket-container" class="bg-gradient-to-tr from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-2.5 text-center shadow-inner">
                <span class="text-[8px] font-black uppercase text-blue-600 block tracking-widest">Draw Entry Ticket</span>
                <span id="m-ticket-number" class="text-lg font-black text-blue-700 tracking-widest select-all"></span>
                <span class="text-[8px] font-bold text-slate-400 block mt-0.5">Status: Active</span>
            </div>

            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 text-xs shadow-inner">
                <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1 text-left">Recipient & Shipping info</span>
                <div class="flex justify-between items-start">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">Recipient:</span>
                    <span id="m-recipient-name" class="font-black text-slate-700"></span>
                </div>
                <div class="flex justify-between items-start">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">Phone:</span>
                    <span id="m-recipient-phone" class="font-black text-slate-700"></span>
                </div>
                <div class="flex justify-between items-start">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px] shrink-0">Address:</span>
                    <span id="m-recipient-address" class="font-black text-slate-700 text-right break-words max-w-[180px]"></span>
                </div>
            </div>

            <div class="border-t border-slate-100 pt-3 space-y-2 text-xs">
                <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1 text-left">Financial breakdown</span>
                <div class="flex justify-between items-center text-xs">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">1. Token Deducted</span>
                    <span class="font-black text-amber-600" id="m-token-deduction"></span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">2. Discount Cash equivalent</span>
                    <span class="font-black text-indigo-600" id="m-discount-cash"></span>
                </div>
                <div class="flex justify-between items-center text-xs">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">3. Delivery Charge</span>
                    <span class="font-black text-slate-700" id="m-delivery-charge"></span>
                </div>
                <div class="flex justify-between items-center text-xs border-t border-slate-100 pt-2 font-black text-slate-800">
                    <span class="font-extrabold text-slate-455 uppercase tracking-wider text-[8px]">4. COD Cash Subtotal</span>
                    <span class="font-black text-emerald-600 text-sm" id="m-cod-amount"></span>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .order-card {
        transition: all 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        border: 1px solid rgba(226, 232, 240, 0.8);
    }
    .order-card:active {
        transform: scale(0.98);
    }
</style>
@endsection

@push('scripts')
<script>
    function openOrderDetailModal(ordBase64) {
        // Fix: Parse JSON cleanly from base64 string
        const ord = JSON.parse(atob(ordBase64));

        document.getElementById('m-order-id').innerText = ord.id;
        
        const statusEl = document.getElementById('m-order-status');
        statusEl.innerText = ord.status_label;
        statusEl.className = "text-[8px] font-black border px-2.5 py-1 rounded-md uppercase tracking-wider block w-fit mx-auto mt-2 " + ord.badge_class;

        document.getElementById('m-product-image').src = `{{ asset('uploads/') }}/${ord.product_image}`;
        document.getElementById('m-product-name').innerText = ord.product_name;

        const ticketContainer = document.getElementById('m-ticket-container');
        if (ord.ticket_number && ord.ticket_number !== 'N/A') {
            ticketContainer.classList.remove('hidden');
            document.getElementById('m-ticket-number').innerText = ord.ticket_number;
        } else {
            ticketContainer.classList.add('hidden');
        }

        document.getElementById('m-recipient-name').innerText = ord.recipient_name;
        document.getElementById('m-recipient-phone').innerText = ord.recipient_phone;
        document.getElementById('m-recipient-address').innerText = ord.recipient_address;

        document.getElementById('m-token-deduction').innerText = '- 💵 ' + ord.coin_deducted.toFixed(2) + ' Tokens (-' + ord.coin_percentage + '%)';
        document.getElementById('m-discount-cash').innerText = '- ' + ord.discount_cash_bdt.toFixed(2) + ' ৳';
        document.getElementById('m-delivery-charge').innerText = '+ ' + ord.delivery_charge_bdt.toFixed(2) + ' ৳';
        document.getElementById('m-cod-amount').innerText = ord.cod_amount_bdt.toFixed(2) + ' ৳';

        document.getElementById('orderDetailsModal').classList.remove('hidden');

        triggerVibration('light');
    }

    function closeOrderDetailModal() {
        document.getElementById('orderDetailsModal').classList.add('hidden');
    }
</script>
@endpush