@extends('layouts.app')

@section('title', 'Leaderboard - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Leaderboard 🏆</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    <!-- Header Hero Banner -->
    <div class="bg-gradient-to-tr from-amber-400 via-orange-400 to-yellow-500 p-5 rounded-[2rem] text-white flex justify-between items-center relative overflow-hidden shadow-md glow-amber">
        <div class="relative z-10 space-y-1 text-left">
            <span class="text-[8px] bg-white/20 px-2 py-0.5 rounded-full text-white font-extrabold uppercase tracking-widest inline-block">Global Champions</span>
            <h2 class="text-xl font-black uppercase tracking-wide">Top Mining Nodes</h2>
            <p class="text-[10px] text-white/95 leading-relaxed font-semibold">Track the top global network champions claiming maximum coin margins.</p>
        </div>
        <i class="fa-solid fa-trophy absolute -right-6 -bottom-6 text-7xl opacity-10"></i>
    </div>

    <!-- Leaderboard Listings -->
    <div class="space-y-2.5">
        @foreach ($rankings as $index => $row)
            @php
                $actualRank = $index + 1;
                $isMe = ($row->id === session('user_id'));
                
                $rankBadge = "#" . $actualRank;
                $rankStyle = "text-slate-400 font-bold";
                if ($actualRank === 1) {
                    $rankBadge = "👑";
                    $rankStyle = "text-amber-500 text-lg";
                } elseif ($actualRank === 2) {
                    $rankBadge = "🥈";
                    $rankStyle = "text-slate-500 text-lg";
                } elseif ($actualRank === 3) {
                    $rankBadge = "🥉";
                    $rankStyle = "text-amber-700 text-lg";
                }
            @endphp
            <div class="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between {{ $isMe ? 'ring-2 ring-blue-500/10 bg-blue-50/5' : '' }}">
                <div class="flex items-center gap-3">
                    <span class="w-8 text-center {{ $rankStyle }}">{{ $rankBadge }}</span>
                    <img src="{{ get_avatar_url($row->profile_pic) }}" class="w-10 h-10 rounded-full object-cover bg-slate-50 border border-slate-200 shadow-sm">
                    <div class="text-left">
                        <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide leading-none flex items-center gap-1.5">
                            {{ htmlspecialchars($row->full_name ?: $row->username) }}
                            @if ($isMe)
                                <span class="bg-blue-600 text-white text-[7px] font-black uppercase px-1.5 py-0.5 rounded shadow-sm">You</span>
                            @endif
                        </h4>
                        <p class="text-[9px] text-slate-400 font-bold mt-1.5">{{ format_username($row->username) }}</p>
                    </div>
                </div>
                <div class="text-right shrink-0 space-y-1.5">
                    <div class="mb-1 block">
                        {!! get_kyc_badge($row->kyc_status) !!}
                    </div>
                    <span class="font-black text-emerald-600 block text-xs">🪙 {{ number_format($row->score, 2) }}</span>
                </div>
            </div>
        @endforeach

        @if (empty($rankings))
            <div class="text-center py-12 bg-white rounded-3xl p-8 border border-slate-100">
                <span class="text-4xl block mb-2">🏆</span>
                <p class="text-xs font-black text-slate-400 uppercase tracking-widest">No rankings calculated yet</p>
            </div>
        @endif
    </div>
</main>
@endsection