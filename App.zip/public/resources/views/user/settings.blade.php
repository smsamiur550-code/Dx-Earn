@extends('layouts.app')

@section('title', 'Settings & KYC - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('profile') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Settings & KYC ⚙️</h1>
    <div class="w-6"></div>
</div>

<div class="flex gap-2 bg-white border border-slate-100 p-1.5 rounded-2xl shadow-sm shrink-0 m-4">
    <button onclick="switchSettingsTab('profile')" id="sub-profile-btn" class="flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center {{ $activeTab === 'profile' ? 'text-white bg-blue-600' : 'text-slate-500 bg-slate-50' }} bouncy-hover">Profile Settings</button>
    <button onclick="switchSettingsTab('kyc')" id="sub-kyc-btn" class="flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center {{ $activeTab === 'kyc' ? 'text-white bg-blue-600' : 'text-slate-500 bg-slate-50' }} bouncy-hover">Identity KYC</button>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <!-- Profile Tab Pane -->
    <div id="tab-profile-pane" class="{{ $activeTab === 'profile' ? '' : 'hidden' }} space-y-4 animate-fadeIn">
        <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm text-center">
            <div class="relative w-24 h-24 mx-auto mb-3">
                <img src="{{ get_avatar_url($user->profile_pic) }}" class="w-full h-full rounded-full object-cover border-4 border-slate-100 shadow-sm">
            </div>
            <h2 class="text-lg font-black text-slate-900">{{ htmlspecialchars($user->full_name) }}</h2>
            <p class="text-xs text-slate-400 font-semibold mt-0.5">{{ format_username($user->username) }}</p>
        </div>

        <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
            <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest mb-4 text-left"><i class="fa-solid fa-gears text-blue-500 mr-1.5"></i> Edit Profile Info</h3>
            <form method="POST" action="{{ route('settings.profile') }}" class="space-y-4 text-left">
                @csrf
                <div>
                    <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Username (Immutable)</label>
                    <input type="text" value="{{ htmlspecialchars($user->username) }}" readonly class="w-full bg-slate-50 border border-slate-100 text-slate-400 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none cursor-not-allowed select-none">
                </div>
                <div>
                    <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Full Name 👤</label>
                    <input type="text" name="full_name" value="{{ htmlspecialchars($user->full_name) }}" required 
                        @if($user->profile_edited == 1) readonly class="w-full bg-slate-50 border border-slate-100 text-slate-400 rounded-2xl px-4 py-3.5 text-xs font-bold cursor-not-allowed select-none" 
                        @else class="w-full bg-slate-50 border border-slate-100 text-slate-800 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all" @endif>
                </div>
                <div>
                    <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Email Address ✉️</label>
                    <input type="email" name="email" value="{{ htmlspecialchars($user->email ?? '') }}" required 
                        @if($user->profile_edited == 1) readonly class="w-full bg-slate-50 border border-slate-100 text-slate-400 rounded-2xl px-4 py-3.5 text-xs font-bold cursor-not-allowed select-none" 
                        @else class="w-full bg-slate-50 border border-slate-100 text-slate-800 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all" @endif>
                </div>
                @if($user->profile_edited == 0)
                    <button type="submit" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover">
                        Lock Legal Settings
                    </button>
                @else
                    <div class="w-full py-3.5 bg-slate-100 text-slate-400 rounded-2xl font-black text-xs uppercase tracking-wider text-center select-none border border-slate-200">
                        🔒 Settings Permanently Locked
                    </div>
                @endif
            </form>
        </div>
    </div>

    <!-- KYC Tab Pane -->
    <div id="tab-kyc-pane" class="{{ $activeTab === 'kyc' ? '' : 'hidden' }} space-y-4 animate-fadeIn">
        @if($user->kyc_status === 'approved')
            <div class="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm text-center space-y-3">
                <div class="w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center text-3xl mx-auto shadow-sm border border-emerald-100">
                    <span>✓</span>
                </div>
                <h2 class="text-base font-black text-slate-800 uppercase">Verification Approved</h2>
                <p class="text-[11px] text-slate-400 font-semibold leading-relaxed">Your identity has been fully verified. The verified badges are now live. 🎉</p>
            </div>
        @elseif($user->kyc_status === 'pending')
            <div class="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm text-center space-y-4">
                <div class="w-14 h-14 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <div>
                    <h2 class="text-base font-black text-slate-800 uppercase">Documents Under Review</h2>
                    <p class="text-[11px] text-slate-400 font-semibold mt-1">Our administrative nodes are verifying your credentials. This takes up to 10 minutes. ⏳</p>
                </div>
            </div>
        @else
            <div class="bg-white p-5 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-4">
                <div class="flex justify-between items-center px-2 py-1">
                    <span id="step-title" class="text-[10px] font-black text-blue-600 uppercase tracking-widest">Step 1 of 3: Details</span>
                    <div class="flex gap-1.5">
                        <div id="bar-1" class="w-6 h-1.5 bg-blue-500 rounded-full transition-all"></div>
                        <div id="bar-2" class="w-6 h-1.5 bg-slate-200 rounded-full transition-all"></div>
                        <div id="bar-3" class="w-6 h-1.5 bg-slate-200 rounded-full transition-all"></div>
                    </div>
                </div>
                <form method="POST" action="{{ route('settings.kyc') }}" enctype="multipart/form-data" class="space-y-4 text-left" id="kycForm">
                    @csrf
                    
                    <!-- Step 1: Details -->
                    <div id="step-1-container" class="space-y-4">
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Full Name 👤</label>
                            <input type="text" id="full_name_kyc" name="full_name" placeholder="Full legal name" class="w-full bg-slate-50 border border-slate-100 text-slate-800 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Date of Birth 📅</label>
                            <input type="date" id="dob" name="dob" class="w-full bg-slate-50 border border-slate-100 text-slate-800 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">ID Number 🪪</label>
                            <input type="text" id="nid_number" name="nid_number" placeholder="NID ID number" class="w-full bg-slate-50 border border-slate-100 text-slate-800 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all">
                        </div>
                        <button type="button" onclick="navigateStep(2)" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover">
                            Next Step ➔
                        </button>
                    </div>

                    <!-- Step 2: Documents -->
                    <div id="step-2-container" class="space-y-4 hidden">
                        <div class="grid grid-cols-2 gap-3">
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">ID Front Photo 📄</label>
                                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-center cursor-pointer relative h-28 flex flex-col justify-center items-center shadow-inner">
                                    <input type="file" name="front_img" id="front_img" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer" onchange="previewKycDoc(this, 'front-preview')">
                                    <div class="space-y-1.5" id="front-placeholder">
                                        <i class="fa-solid fa-image text-xl text-slate-400"></i>
                                        <p class="text-[8px] font-bold text-slate-400 uppercase">Select Front</p>
                                    </div>
                                    <img id="front-preview" class="hidden w-full h-full object-cover rounded-xl absolute inset-0 p-1">
                                </div>
                            </div>
                            <div class="space-y-2">
                                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">ID Back Photo 📄</label>
                                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-center cursor-pointer relative h-28 flex flex-col justify-center items-center shadow-inner">
                                    <input type="file" name="back_img" id="back_img" accept="image/*" class="absolute inset-0 opacity-0 cursor-pointer" onchange="previewKycDoc(this, 'back-preview')">
                                    <div class="space-y-1.5" id="back-placeholder">
                                        <i class="fa-solid fa-image text-xl text-slate-400"></i>
                                        <p class="text-[8px] font-bold text-slate-400 uppercase">Select Back</p>
                                    </div>
                                    <img id="back-preview" class="hidden w-full h-full object-cover rounded-xl absolute inset-0 p-1">
                                </div>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button type="button" onclick="navigateStep(1)" class="flex-1 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl font-black text-xs border border-slate-200 shadow-sm active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover">
                                Back
                            </button>
                            <button type="button" onclick="navigateStep(3)" class="flex-1 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover">
                                Next Step ➔
                            </button>
                        </div>
                    </div>

                    <!-- Step 3: Selfie -->
                    <div id="step-3-container" class="space-y-4 hidden">
                        <div class="space-y-2">
                            <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1 text-center">Capture Live Selfie 📸</label>
                            <div class="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-center cursor-pointer relative h-40 flex flex-col justify-center items-center shadow-inner">
                                <input type="file" name="selfie_img" id="selfie_img" accept="image/*" capture="user" class="absolute inset-0 opacity-0 cursor-pointer" onchange="previewKycDoc(this, 'selfie-preview')">
                                <div class="space-y-1.5" id="selfie-placeholder">
                                    <i class="fa-solid fa-camera text-3xl text-slate-400"></i>
                                    <p class="text-[9px] font-black text-slate-400 uppercase">Open Camera</p>
                                </div>
                                <img id="selfie-preview" class="hidden w-full h-full object-cover rounded-xl absolute inset-0 p-1">
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button type="button" onclick="navigateStep(2)" class="flex-1 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl font-black text-xs border border-slate-200 shadow-sm active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover">
                                Back
                            </button>
                            <button type="submit" class="flex-1 py-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-widest bouncy-hover btn-glow-emerald">
                                Submit KYC ⚡
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        @endif
    </div>
</main>
@endsection

@push('scripts')
<script>
    function switchSettingsTab(tab) {
        const url = new URL(window.location);
        url.searchParams.set('tab', tab);
        window.history.pushState({}, '', url);

        const profBtn = document.getElementById('sub-profile-btn');
        const kycBtn = document.getElementById('sub-kyc-btn');
        const profPane = document.getElementById('tab-profile-pane');
        const kycPane = document.getElementById('tab-kyc-pane');

        if (tab === 'profile') {
            profBtn.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            kycBtn.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            profPane.classList.remove('hidden');
            kycPane.classList.add('hidden');
        } else {
            profBtn.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            kycBtn.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            profPane.classList.add('hidden');
            kycPane.classList.remove('hidden');
        }
    }

    function previewKycDoc(input, previewId) {
        const preview = document.getElementById(previewId);
        const placeholderId = previewId.replace('-preview', '-placeholder');
        const placeholder = document.getElementById(placeholderId);
        const file = input.files[0];
        const reader = new FileReader();
        reader.onloadend = function () {
            preview.src = reader.result;
            preview.classList.remove('hidden');
            if (placeholder) placeholder.classList.add('hidden');
        }
        if (file) {
            reader.readAsDataURL(file);
        } else {
            preview.src = "";
            preview.classList.add('hidden');
            if (placeholder) placeholder.classList.remove('hidden');
        }
    }

    function navigateStep(step) {
        const s1 = document.getElementById('step-1-container');
        const s2 = document.getElementById('step-2-container');
        const s3 = document.getElementById('step-3-container');

        const b1 = document.getElementById('bar-1');
        const b2 = document.getElementById('bar-2');
        const b3 = document.getElementById('bar-3');

        const title = document.getElementById('step-title');

        if (step === 1) {
            s1.classList.remove('hidden');
            s2.classList.add('hidden');
            s3.classList.add('hidden');
            b1.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            b2.className = "w-6 h-1.5 bg-slate-200 rounded-full";
            b3.className = "w-6 h-1.5 bg-slate-200 rounded-full";
            if (title) title.innerText = "Step 1 of 3: Details";
        } else if (step === 2) {
            const fullName = document.getElementById('full_name_kyc')?.value || '';
            const dob = document.getElementById('dob')?.value || '';
            const nid = document.getElementById('nid_number')?.value || '';
            if (fullName.trim() === "" || dob.trim() === "" || nid.trim() === "") {
                alert("Please fill all step 1 credentials.");
                return;
            }
            s1.classList.add('hidden');
            s2.classList.remove('hidden');
            s3.classList.add('hidden');
            b1.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            b2.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            b3.className = "w-6 h-1.5 bg-slate-200 rounded-full";
            if (title) title.innerText = "Step 2 of 3: Documents";
        } else if (step === 3) {
            const front = document.getElementById('front_img')?.files[0];
            const back = document.getElementById('back_img')?.files[0];
            if (!front || !back) {
                alert("Please upload both front and back document photographs.");
                return;
            }
            s1.classList.add('hidden');
            s2.classList.add('hidden');
            s3.classList.remove('hidden');
            b1.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            b2.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            b3.className = "w-6 h-1.5 bg-blue-500 rounded-full";
            if (title) title.innerText = "Step 3 of 3: Live Selfie";
        }
    }
</script>
@endpush