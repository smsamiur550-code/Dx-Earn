@extends('layouts.app')

@section('title', 'Ledger History - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('profile') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Ledger History 📑</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    <div class="flex gap-2 bg-white border border-slate-100 p-1.5 rounded-2xl shadow-sm shrink-0">
        <button onclick="toggleLedgerTab('withdraw')" id="ledger-withdraw-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover">Payout History</button>
        <button onclick="toggleLedgerTab('convert')" id="ledger-convert-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover">Conversion History</button>
    </div>

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-4">
        <!-- Withdrawal List -->
        <div id="ledger-withdraw-pane" class="space-y-3.5 animate-fadeIn text-left">
            <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-clock-rotate-left text-slate-400"></i> Withdrawal Requests</h3>
            <div class="space-y-3">
                @foreach ($withdrawals_ledger as $w) 
                    @php
                        $status = strtolower($w->status);
                        $badgeClass = 'text-amber-500 bg-amber-50';
                        if ($status === 'approved' || $status === 'completed') {
                            $badgeClass = 'text-emerald-500 bg-emerald-50';
                        } elseif ($status === 'cancelled' || $status === 'rejected') {
                            $badgeClass = 'text-rose-500 bg-rose-50';
                        }
                        $amtBdt = floatval($w->amount) * $takaRate;
                    @endphp
                    <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 flex justify-between items-center text-xs">
                        <div class="space-y-0.5">
                            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Withdraw Request</span>
                            <span class="font-extrabold text-slate-700">{{ htmlspecialchars($w->payment_method) }}</span>
                            <span class="text-[8px] font-bold text-slate-400 block truncate w-40">{{ htmlspecialchars($w->account_number) }}</span>
                            <span class="text-[8px] font-bold text-slate-400 block mt-0.5">{{ $w->requested_at ? $w->requested_at->format('d M Y, h:i A') : '' }}</span>
                        </div>
                        <div class="text-right">
                            <span class="text-[8px] font-black px-2 py-0.5 rounded uppercase tracking-wider block {{ $badgeClass }}">{{ $w->status }}</span>
                            <span class="font-black text-emerald-600 block text-sm mt-1">{{ number_format($amtBdt, 2) }} ৳</span>
                        </div>
                    </div>
                @endforeach

                @if (empty($withdrawals_ledger))
                    <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-12">No withdrawals recorded in the last 30 days.</p>
                @endif
            </div>
        </div>

        <!-- Conversion List -->
        <div id="ledger-convert-pane" class="space-y-3.5 hidden animate-fadeIn text-left">
            <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-clock-rotate-left text-slate-400"></i> Conversion Logs</h3>
            <div class="space-y-3">
                @foreach ($conversions_ledger as $row)
                    <div class="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 flex justify-between items-center text-xs">
                        <div class="space-y-0.5">
                            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Convert Ledger</span>
                            <span class="font-extrabold text-slate-700">{{ $row->type === 'coin_to_token' ? 'Coins to Tokens' : 'Tokens to BDT' }}</span>
                            <span class="text-[8px] font-bold text-slate-400 block">{{ $row->created_at ? $row->created_at->format('d M Y, h:i A') : '' }}</span>
                        </div>
                        <span class="font-black text-slate-800 block text-right">
                            {{ $row->type === 'coin_to_token' ? '🪙 ' . number_format($row->amount_from, 2) : '💵 ' . number_format($row->amount_from, 2) }} ➔ 
                            <span class="text-emerald-600 block mt-0.5">{{ $row->type === 'coin_to_token' ? '💵 ' . number_format($row->amount_to, 2) : number_format($row->amount_to * $takaRate, 2) . ' ৳' }}</span>
                        </span>
                    </div>
                @endforeach

                @if (empty($conversions_ledger))
                    <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-12">No conversions recorded in the last 30 days.</p>
                @endif
            </div>
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function toggleLedgerTab(tab) {
        const btnWithdraw = document.getElementById('ledger-withdraw-btn');
        const btnConvert = document.getElementById('ledger-convert-btn');
        const paneWithdraw = document.getElementById('ledger-withdraw-pane');
        const paneConvert = document.getElementById('ledger-convert-pane');

        if (tab === 'withdraw') {
            btnWithdraw.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            btnConvert.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            paneWithdraw.classList.remove('hidden');
            paneConvert.classList.add('hidden');
        } else {
            btnWithdraw.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            btnConvert.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            paneWithdraw.classList.add('hidden');
            paneConvert.classList.remove('hidden');
        }
    }
</script>
@endpush