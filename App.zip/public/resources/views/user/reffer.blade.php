@extends('layouts.app')

@section('title', 'My Team - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">My Network 👥</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 p-6 rounded-[2rem] text-white shadow-md relative overflow-hidden">
        <div class="relative z-10 space-y-4 text-left">
            <div>
                <span class="text-[9px] font-black uppercase tracking-widest text-slate-100 opacity-90">Verified Referral Earnings (৳) ✨</span>
                <h2 class="text-3xl font-black text-white mt-0.5">{{ number_format($user->balance_referral_dollar * $takaRate, 2) }} <span class="text-emerald-300 text-sm font-bold uppercase">৳</span></h2>
                <p class="text-[10px] text-amber-300 font-bold mt-1 uppercase">Pending Verification: {{ number_format($user->referrals()->where('status', 'pending')->sum('bonus_amount') * $takaRate, 2) }} ৳</p>
            </div>

            <div class="grid grid-cols-2 gap-3 pt-3 border-t border-white/15">
                <div>
                    <span class="text-[8px] font-bold uppercase opacity-80 block">Verified Invitees</span>
                    <span class="text-lg font-black">{{ $user->referrals()->where('status', 'approved')->count() }} <span class="text-[9px] text-emerald-300 font-bold">Approved</span></span>
                </div>
                <div>
                    <span class="text-[8px] font-bold uppercase opacity-80 block">On Hold Invitees</span>
                    <span class="text-lg font-black">{{ $user->referrals()->where('status', 'pending')->count() }} <span class="text-[9px] text-amber-300 font-black">Pending</span></span>
                </div>
            </div>

            <div class="bg-white/15 p-3 rounded-xl border border-white/5 text-[9px] text-blue-100 leading-normal flex gap-2">
                <span>⚠️</span>
                <span>Both parties receive referral BDT bonuses in pending status. Once the invited friend completes ID Verification (KYC), both bonuses are instantly approved and credited!</span>
            </div>
        </div>
        <i class="fa-solid fa-users absolute -right-8 -bottom-8 text-[12rem] opacity-5"></i>
    </div>

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-[0_4px_20px_rgba(0,0,0,0.01)] space-y-4">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest mb-1 text-left"><i class="fa-solid fa-share-nodes text-blue-500 mr-1"></i> Spread Your Network</h3>
        
        <div class="space-y-3">
            <div class="space-y-1 text-left">
                <span class="text-[9px] font-bold text-slate-400 uppercase ml-1">Telegram App Link 📱</span>
                <div class="bg-slate-50 border border-slate-150 p-3 rounded-xl flex items-center justify-between gap-3">
                    <input type="text" id="tgUrl" value="{{ $tgRefLink }}" readonly class="bg-transparent text-[10px] font-mono font-bold text-slate-600 w-full outline-none select-all">
                    <button onclick="copyToClipboard('tgUrl')" class="text-blue-600 active:scale-75 transition-transform p-1 bouncy-hover"><i class="fa-regular fa-copy text-sm"></i></button>
                </div>
            </div>

            <div class="space-y-1 text-left">
                <span class="text-[9px] font-bold text-slate-400 uppercase ml-1">Direct Web Link 🌐</span>
                <div class="bg-slate-50 border border-slate-150 p-3 rounded-xl flex items-center justify-between gap-3">
                    <input type="text" id="webUrl" value="{{ $webRefLink }}" readonly class="bg-transparent text-[10px] font-mono font-bold text-slate-600 w-full outline-none select-all">
                    <button onclick="copyToClipboard('webUrl')" class="text-blue-600 active:scale-75 transition-transform p-1 bouncy-hover"><i class="fa-regular fa-copy text-sm"></i></button>
                </div>
            </div>

            <button onclick="triggerNativeShare()" class="w-full py-3.5 color-shifting-btn bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl font-black text-xs shadow-md active:scale-95 transition-transform duration-100 uppercase tracking-wider flex items-center justify-center gap-1.5 mt-2 action-btn bouncy-hover">
                🚀 Invite Friends Directly
            </button>
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1 text-left">Team Directory</h3>
        
        <div class="space-y-3">
            @foreach ($referrals as $ref)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <img src="{{ get_avatar_url($ref->profile_pic) }}" class="w-10 h-10 rounded-xl object-cover border border-slate-200 shrink-0 bg-slate-50">
                        <div class="text-left">
                            <h4 class="text-xs font-black text-slate-800">{{ htmlspecialchars($ref->full_name) }}</h4>
                            <p class="text-[9px] text-slate-400 font-bold">@{{ htmlspecialchars($ref->username) }}</p>
                            <p class="text-[8px] text-slate-400 font-bold mt-0.5">Joined: {{ $ref->created_at->format('d M Y') }}</p>
                        </div>
                    </div>
                    <div class="text-right space-y-1 shrink-0">
                        <div class="mb-1 block">
                            {!! get_kyc_badge($ref->kyc_status) !!}
                        </div>
                        @if ($ref->status === 'approved')
                            <span class="text-[8px] font-black text-emerald-600 bg-emerald-50 border border-emerald-200/50 px-2.5 py-1 rounded-md uppercase tracking-wider block">Approved</span>
                            <p class="text-xs font-black text-slate-800 mt-1">{{ number_format($ref->bonus_amount * $takaRate, 2) }} ৳</p>
                        @else
                            <span class="text-[8px] font-black text-amber-600 bg-amber-50 border border-amber-200/50 px-2.5 py-1 rounded-md uppercase tracking-wider block">Pending KYC</span>
                            <p class="text-[9px] text-amber-500 mt-1 italic font-black">{{ number_format($ref->bonus_amount * $takaRate, 2) }} ৳ Pending</p>
                        @endif
                    </div>
                </div>
            @endforeach

            @if ($referrals->isEmpty())
                <div class="text-center py-12 opacity-50 bg-white rounded-3xl border border-slate-100 p-8">
                    <div class="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mx-auto mb-3"><i class="fa-solid fa-user-group text-lg"></i></div>
                    <p class="text-[10px] font-black uppercase text-slate-400 tracking-wider">Your network is empty. Invite friends now!</p>
                </div>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function copyToClipboard(id) {
        const input = document.getElementById(id);
        input.select();
        input.setSelectionRange(0, 99999);
        navigator.clipboard.writeText(input.value);
        if (window.GlobalPopup) {
            GlobalPopup.show('success', 'Link Copied!', 'Your referral network invitation link has been copied successfully. 📋', false, 1500);
        } else {
            alert("Referral Link Copied! 🤝");
        }
    }

    function triggerNativeShare() {
        const refLink = document.getElementById('tgUrl').value;
        if (navigator.share) {
            navigator.share({
                title: 'Join DX EARN Mining Node',
                text: 'Mine, convert, and earn BDT commissions instantly with DX EARN!',
                url: refLink
            })
            .then(() => console.log('Successfully shared referral link'))
            .catch((error) => console.log('Error sharing:', error));
        } else {
            copyToClipboard('tgUrl');
        }
    }
</script>
@endpush