@extends('layouts.app')

@section('title', 'View Product - DX Shop')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('shop') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Product Details 🔍</h1>
    <div class="w-6"></div>
</div>

<div class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="w-full h-56 rounded-3xl overflow-hidden bg-slate-50 border border-slate-100 relative shadow-inner">
        <img src="{{ asset('uploads/' . ($product->image ?? 'default.png')) }}" class="w-full h-full object-cover">
        <span class="absolute top-3 left-3 bg-blue-650/90 text-white text-[8px] font-black uppercase px-3 py-1 rounded-md border border-white/10 shadow-sm">
            {{ htmlspecialchars($product->category->name ?? 'General') }}
        </span>
    </div>

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-3">
        <div class="space-y-1 text-left">
            <h2 class="text-base font-black text-slate-800 uppercase tracking-wide leading-snug">{{ htmlspecialchars($product->name) }}</h2>
            <span class="text-lg font-black text-emerald-600 block">{{ number_format($productPriceBdt, 2) }} ৳</span>
            
            <div class="flex items-center gap-2 pt-2 border-t border-slate-100 mt-2">
                @if (!empty($product->company_logo))
                    <img src="{{ asset('uploads/' . $product->company_logo) }}" class="w-6 h-6 rounded-full object-cover border border-slate-150">
                @endif
                <div>
                    <span class="text-[8px] font-black text-slate-400 block uppercase tracking-widest leading-none">Manufacturer brand</span>
                    <span class="text-[10px] font-black text-slate-700 block mt-0.5">{{ htmlspecialchars($product->company_name ?? 'Official Brand') }}</span>
                </div>
            </div>
        </div>

        <div class="pt-3 border-t border-slate-100 space-y-1 text-left">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Available Stock</span>
            <span class="text-xs font-extrabold text-slate-700 block">📁 {{ intval($product->stock) }} Items Available</span>
        </div>

        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-[10px] text-slate-600 font-semibold leading-relaxed shadow-inner text-left">
            {!! nl2br(htmlspecialchars($product->description ?? 'No description provided.')) !!}
        </div>

        <div class="pt-4">
            <button onclick="toggleCheckoutModal(true)" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover flex items-center justify-center gap-2 shadow-md btn-glow-blue">
                Buy Now ➔
            </button>
        </div>
    </div>

    @if(!$relatedProducts->isEmpty())
        <div class="space-y-3 pt-2 text-left">
            <h3 class="text-xs font-black text-slate-700 uppercase tracking-wider pl-1">Related Products 🛍️</h3>
            <div class="grid grid-cols-2 gap-3.5">
                @foreach ($relatedProducts as $rp)
                    <a href="{{ route('shop.product', ['id' => $rp->id]) }}" class="bg-white rounded-[2rem] border border-slate-100 p-3 shadow-sm flex flex-col h-[230px] bouncy-hover">
                        <div class="w-full h-24 rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 relative shadow-inner">
                            <img src="{{ asset('uploads/' . ($rp->image ?? 'default.png')) }}" class="w-full h-full object-cover">
                        </div>
                        <div class="space-y-1 mt-2 font-black">
                            <h4 class="text-xs text-slate-700 uppercase tracking-wide truncate">{{ htmlspecialchars($rp->name) }}</h4>
                            <span class="text-[10px] text-emerald-600 block">{{ number_format($rp->price * $takaRate, 2) }} ৳</span>
                        </div>
                    </a>
                @endforeach
            </div>
        </div>
    @endif
</div>

<!-- Direct Order Modal -->
<div id="checkoutModal" class="hidden fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
    <div class="bg-white w-full max-w-[380px] rounded-[2.5rem] p-6 border border-slate-150 shadow-2xl relative flex flex-col justify-between max-h-[85vh] overflow-y-auto no-scrollbar">
        <button onclick="toggleCheckoutModal(false)" class="absolute top-4 right-4 text-slate-400 active:scale-75 transition-all text-xl"><i class="fa-solid fa-circle-xmark"></i></button>
        
        <div class="space-y-4">
            <div class="text-center">
                <span class="text-3xl block">🛍️</span>
                <h3 class="text-base font-black text-slate-900 uppercase mt-2">Instant Direct Checkout</h3>
                <p class="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Claim your product with direct token discount</p>
            </div>

            <form method="POST" action="{{ route('shop.checkout') }}" class="space-y-4">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                
                <div class="space-y-3 text-left">
                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Recipient Full Name 👤</label>
                        <input type="text" name="name" required placeholder="Enter full legal name" class="w-full bg-slate-50 border border-slate-150 rounded-2xl px-4 py-3.5 text-xs font-bold text-slate-800 outline-none">
                    </div>

                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Mobile Phone Number 📞</label>
                        <input type="tel" name="phone" required placeholder="017XXXXXXXX" class="w-full bg-slate-50 border border-slate-150 rounded-2xl px-4 py-3.5 text-xs font-bold text-slate-800 outline-none">
                    </div>

                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1 ml-1">Shipping Full Address 🏠</label>
                        <textarea name="address" required rows="2" placeholder="Full home address, village, upazila, district" class="w-full bg-slate-50 border border-slate-150 rounded-2xl px-4 py-3 text-xs font-bold text-slate-800 outline-none"></textarea>
                    </div>

                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1.5 ml-1">Delivery Destination Area 🚚</label>
                        <div class="grid grid-cols-2 gap-2">
                            <label class="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between cursor-pointer focus-within:ring-2 focus-within:ring-blue-500/10">
                                <span class="text-xs font-bold text-slate-600">Inside Dhaka</span>
                                <input type="radio" name="delivery_loc" value="inside" checked onchange="updateCheckoutCalculations()" class="text-blue-600 focus:ring-0">
                            </label>
                            <label class="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between cursor-pointer focus-within:ring-2 focus-within:ring-blue-500/10">
                                <span class="text-xs font-bold text-slate-600">Outside Dhaka</span>
                                <input type="radio" name="delivery_loc" value="outside" onchange="updateCheckoutCalculations()" class="text-blue-600 focus:ring-0">
                            </label>
                        </div>
                    </div>

                    <div>
                        <label class="block text-[8px] font-black text-slate-400 uppercase tracking-wider mb-1.5 ml-1">Select Token Discount Percent 🏷️</label>
                        <div class="grid grid-cols-3 gap-2 text-center text-xs">
                            @if ($allow20)
                                <label class="bg-slate-50 border border-slate-150 py-3 rounded-2xl flex flex-col items-center justify-center cursor-pointer">
                                    <span class="font-black text-slate-800">20% Off</span>
                                    <input type="radio" name="discount_percent" value="20" checked onchange="updateCheckoutCalculations()" class="text-blue-600 mt-1 focus:ring-0">
                                </label>
                            @endif
                            @if ($allow30)
                                <label class="bg-slate-50 border border-slate-150 py-3 rounded-2xl flex flex-col items-center justify-center cursor-pointer">
                                    <span class="font-black text-slate-800">30% Off</span>
                                    <input type="radio" name="discount_percent" value="30" onchange="updateCheckoutCalculations()" class="text-blue-600 mt-1 focus:ring-0">
                                </label>
                            @endif
                            @if ($allow40)
                                <label class="bg-slate-50 border border-slate-150 py-3 rounded-2xl flex flex-col items-center justify-center cursor-pointer">
                                    <span class="font-black text-slate-800">40% Off</span>
                                    <input type="radio" name="discount_percent" value="40" onchange="updateCheckoutCalculations()" class="text-blue-600 mt-1 focus:ring-0">
                                </label>
                            @endif
                        </div>
                    </div>
                </div>

                <div class="bg-slate-50 p-4 rounded-3xl border border-slate-150 space-y-2 text-xs shadow-inner text-left">
                    <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-1">Price Summary Ledger</span>
                    <div class="flex justify-between items-center font-bold text-slate-600">
                        <span>Original Price:</span>
                        <span>{{ number_format($productPriceBdt, 2) }} ৳</span>
                    </div>
                    <div class="flex justify-between items-center font-bold text-slate-600">
                        <span>Token Discount Deduct:</span>
                        <span class="text-amber-600" id="live-discount-deduction">-0.00 ৳</span>
                    </div>
                    <div class="flex justify-between items-center font-bold text-slate-600">
                        <span>Tokens Required Cost:</span>
                        <span class="text-blue-600" id="live-token-cost">0.00 Tokens</span>
                    </div>
                    <div class="flex justify-between items-center font-bold text-slate-600">
                        <span>Delivery carrier charge:</span>
                        <span id="live-delivery-fee">0.00 ৳</span>
                    </div>
                    <div class="flex justify-between items-center font-black text-slate-800 border-t border-slate-150/40 pt-2 text-sm">
                        <span>COD Cash Due Payment:</span>
                        <span class="text-emerald-600" id="live-cod-due">0.00 ৳</span>
                    </div>
                </div>

                <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-xl font-black text-xs uppercase tracking-widest shadow-md btn-glow-blue bouncy-hover">Confirm Order & Get Ticket 🚀</button>
            </form>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const originalPriceBdt = {{ $productPriceBdt }};
    const tokensPerTaka = {{ $tokenPerTaka }};
    const insideDhakaFee = {{ $deliveryInside }};
    const outsideDhakaFee = {{ $deliveryOutside }};

    function toggleCheckoutModal(show) {
        const modal = document.getElementById('checkoutModal');
        if (show) {
            modal.classList.remove('hidden');
            updateCheckoutCalculations();
        } else {
            modal.classList.add('hidden');
        }
    }

    function updateCheckoutCalculations() {
        const discountPercentEl = document.querySelector('input[name="discount_percent"]:checked');
        const deliveryLocEl = document.querySelector('input[name="delivery_loc"]:checked');

        if (!discountPercentEl || !deliveryLocEl) return;

        const discountPercent = parseInt(discountPercentEl.value);
        const deliveryLoc = deliveryLocEl.value;

        const deliveryFee = (deliveryLoc === 'inside') ? insideDhakaFee : outsideDhakaFee;
        const discountRatio = discountPercent / 100;

        const discountBdt = originalPriceBdt * discountRatio;
        const tokenCost = discountBdt * tokensPerTaka;
        const codDue = (originalPriceBdt - discountBdt) + deliveryFee;

        document.getElementById('live-discount-deduction').innerText = `-${discountBdt.toFixed(2)} ৳ (${discountPercent}%)`;
        document.getElementById('live-token-cost').innerText = `${tokenCost.toFixed(2)} Tokens`;
        document.getElementById('live-delivery-fee').innerText = `${deliveryFee.toFixed(2)} ৳`;
        document.getElementById('live-cod-due').innerText = `${codDue.toFixed(2)} ৳`;
    }
</script>
@endpush