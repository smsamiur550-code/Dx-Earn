@extends('layouts.app')

@section('title', 'Withdraw - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('wallet') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Withdraw Hub 💳</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow pb-24">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <a href="{{ route('withdraw.feed') }}" class="block bg-gradient-to-r from-amber-500 to-orange-500 p-4 rounded-3xl text-white text-center shadow-md bouncy-hover duration-150 btn-glow-amber">
        <span class="text-xs font-black uppercase tracking-wider block">🌍 Global Live Payout Status</span>
        <span class="text-[10px] font-bold block mt-1">Check Rolling Live User Withdrawal Receipts 🚀</span>
    </a>

    <div class="flex gap-2 bg-white border border-slate-100 p-1.5 rounded-2xl shadow-sm shrink-0">
        <button type="button" onclick="togglePayoutSource('referral_usd')" id="sub-payout-ref-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 active bouncy-hover">Referral Balance</button>
        <button type="button" onclick="togglePayoutSource('main_usd')" id="sub-payout-main-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover">Main Balance</button>
    </div>

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm relative overflow-hidden">
        @if (!$isKycApproved)
            <div class="absolute inset-0 bg-white/95 backdrop-blur-sm z-30 flex flex-col items-center justify-center p-6 text-center">
                <div class="w-14 h-14 bg-rose-50 border border-rose-100 rounded-2xl flex items-center justify-center text-rose-500 text-2xl shadow-inner mb-3">👤</div>
                <h3 class="text-sm font-black text-slate-900 uppercase tracking-wider">KYC Verification Required</h3>
                <p class="text-[10px] font-semibold text-slate-400 mt-1 max-w-[80%] leading-relaxed">Identity registration must conclude prior to processing payouts.</p>
            </div>
        @endif

        <form method="POST" action="{{ route('withdraw.submit') }}" class="space-y-4">
            @csrf
            <input type="hidden" name="withdraw_type" id="payout_withdraw_type" value="referral_usd">

            <div class="space-y-1 text-left">
                <div class="flex justify-between items-baseline text-[9px] font-black text-slate-400 uppercase ml-1 tracking-wider">
                    <span>Withdrawal Amount ৳</span>
                    <div>
                        <span>Available: </span>
                        <span id="payout-bal-main" class="hidden text-emerald-600 font-extrabold">{{ number_format($user->balance_dollar * $takaRate, 2) }} ৳</span>
                        <span id="payout-bal-referral" class="text-blue-600 font-extrabold">{{ number_format(($user->balance_referral_dollar ?? 0) * $takaRate, 2) }} ৳</span>
                    </div>
                </div>
                <div class="text-[8px] text-slate-450 font-bold uppercase tracking-wider bg-slate-50 border border-slate-150 p-2.5 rounded-xl shadow-inner flex justify-between">
                    <span>Min Limit:</span>
                    <strong class="text-slate-700">{{ number_format($minWithdraw * $takaRate, 2) }} ৳</strong>
                </div>
                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between mt-2 shadow-inner focus-within:ring-2 focus-within:ring-blue-500/10">
                    <input type="number" step="0.01" name="amount_bdt" id="payout-amount-field" placeholder="0.00" class="bg-transparent text-sm font-black text-slate-800 w-full outline-none">
                    <span class="text-[10px] font-black uppercase text-emerald-600 shrink-0">৳ BDT</span>
                </div>
            </div>

            <div class="text-left">
                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Select Gateway Address 🏦</label>
                <select name="payment_method" id="payout_gateway_select" required class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 text-slate-505 transition-all" onchange="checkGatewaySelection()">
                    <option value="">-- Choose Gateway --</option>
                    <option value="Binance Pay">Binance Pay (Pay ID / UID)</option>
                    <option value="Trust Wallet">Trust Wallet (USDT - BEP20)</option>
                    <option value="Free Fire Diamond Topup 🎮">Free Fire Diamond Topup 🎮</option>
                </select>
            </div>

            <div id="ff-packages-wrapper" class="hidden text-left">
                <label class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Select Diamond Package 💎</label>
                <select name="ff_package_id" class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3.5 text-xs font-bold outline-none focus:border-blue-400 text-slate-505 transition-all">
                    @foreach ($diamondPackages as $pack)
                        <option value="{{ $pack['id'] }}">{{ $pack['diamonds'] }} Diamonds - {{ number_format($pack['price'] * $takaRate, 2) }} ৳</option>
                    @endforeach
                </select>
            </div>

            <div class="text-left">
                <label id="payout_account_label" class="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 ml-1">Target Address / ID 🆔</label>
                <input type="text" name="account_number" id="payout_account_field" placeholder="Enter target credentials" required class="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3.5 text-xs font-bold text-slate-800 outline-none focus:border-blue-400 transition-all">
            </div>

            <button type="submit" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover btn-glow-blue">Submit Request</button>
        </form>
    </div>
</main>
@endsection

@push('scripts')
<script>
    function togglePayoutSource(src) {
        const btnRef = document.getElementById('sub-payout-ref-btn');
        const btnMain = document.getElementById('sub-payout-main-btn');
        const balRef = document.getElementById('payout-bal-referral');
        const balMain = document.getElementById('payout-bal-main');
        const field = document.getElementById('payout_withdraw_type');

        if (src === 'referral_usd') {
            btnRef.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            btnMain.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            balRef.classList.remove('hidden');
            balMain.classList.add('hidden');
            field.value = 'referral_usd';
        } else {
            btnRef.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            btnMain.className = "sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            balRef.classList.add('hidden');
            balMain.classList.remove('hidden');
            field.value = 'main_usd';
        }
        document.getElementById('payout-amount-field').value = '';
    }

    function checkGatewaySelection() {
        const gateway = document.getElementById('payout_gateway_select').value;
        const ffWrapper = document.getElementById('ff-packages-wrapper');
        const label = document.getElementById('payout_account_label');
        const field = document.getElementById('payout_account_field');

        if (gateway === 'Free Fire Diamond Topup 🎮') {
            ffWrapper.classList.remove('hidden');
            label.innerText = 'Player UID (UID Number) 🎮';
            field.placeholder = 'Enter Free Fire Player UID';
            document.getElementById('payout-amount-field').disabled = true;
            document.getElementById('payout-amount-field').placeholder = 'Calculated from package';
        } else {
            ffWrapper.classList.add('hidden');
            label.innerText = 'Target Address / ID 🆔';
            field.placeholder = 'Enter target credentials';
            document.getElementById('payout-amount-field').disabled = false;
            document.getElementById('payout-amount-field').placeholder = '0.00';
        }
    }
</script>
@endpush