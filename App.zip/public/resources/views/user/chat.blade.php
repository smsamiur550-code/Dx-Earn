@extends('layouts.app')

@section('title', 'Live Chat - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('support') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Live Support Chat 💬</h1>
    <div class="w-6"></div>
</div>

<div class="flex-grow overflow-y-auto p-4 space-y-4 no-scrollbar flex flex-col justify-end" id="chatBoxContainer" style="height: calc(100vh - 140px); overflow-y: scroll;">
    <div class="flex-1 overflow-y-auto space-y-4 flex flex-col no-scrollbar" id="chatBox"></div>
</div>

<form id="chatForm" class="bg-white p-3 flex gap-2 border-t border-slate-100 shrink-0 z-20">
    <input type="text" id="messageInput" placeholder="Type your message here..." class="flex-1 bg-slate-50 border border-slate-150 rounded-full px-5 py-3 text-xs font-bold outline-none focus:border-blue-400 focus:bg-white transition-all text-slate-900 placeholder:text-slate-400 shadow-inner" required autocomplete="off">
    <button type="submit" class="w-11 h-11 bg-gradient-to-tr from-blue-500 to-indigo-650 text-white rounded-full flex items-center justify-center shrink-0 shadow-md bouncy-hover">
        <i class="fa-solid fa-paper-plane text-xs"></i>
    </button>
</form>
@endsection

@push('scripts')
<script>
    const chatBox = document.getElementById("chatBox");
    const chatForm = document.getElementById("chatForm");
    const msgInput = document.getElementById("messageInput");
    
    let lastMessageCount = 0;

    function playIncomingBeep() {
        try {
            const ctx = new (window.AudioContext || window.webkitAudioContext)();
            const now = ctx.currentTime;
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(587.33, now);
            osc.frequency.setValueAtTime(880.00, now + 0.1);
            gain.gain.setValueAtTime(0.12, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now);
            osc.stop(now + 0.25);
        } catch(e) {}
    }

    function loadMessages(playNotification = false) {
        fetch("{{ route('chat.fetch') }}")
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    let html = '';
                    const messages = data.messages;

                    if (messages.length === 0) {
                        html = `
                        <div class="my-auto text-center opacity-70 p-10 flex flex-col items-center justify-center h-full w-full">
                            <div class="w-14 h-14 bg-slate-100 border border-slate-200 rounded-full flex items-center justify-center text-blue-400 mb-3 text-xl shadow-inner">
                                💬
                            </div>
                            <p class="text-[10px] font-black uppercase text-slate-400 tracking-wider">No message threads. Start the conversation!</p>
                        </div>`;
                    } else {
                        messages.forEach(msg => {
                            if (msg.is_admin === 0) {
                                const seenIcon = msg.is_seen === 1 ? '<i class="fa-solid fa-check-double text-blue-300 ml-1"></i>' : '<i class="fa-solid fa-check text-white/50 ml-1"></i>';
                                
                                html += `
                                <div class="self-end bg-gradient-to-br from-blue-500 to-indigo-650 text-white px-4 py-2.5 rounded-2xl rounded-tr-none shadow-sm max-w-[80%] my-1 shrink-0">
                                    <p class="text-xs font-semibold leading-relaxed break-all text-left">${escapeHTML(msg.message)}</p>
                                    <div class="flex items-center justify-end gap-1 mt-1 opacity-80">
                                        <span class="text-[7px] font-bold uppercase tracking-wider">${msg.msg_time}</span>
                                        ${seenIcon}
                                    </div>
                                </div>`;
                            } else {
                                html += `
                                <div class="self-start bg-white border border-slate-200 text-slate-700 px-4 py-2.5 rounded-2xl rounded-tl-none shadow-sm max-w-[80%] my-1 shrink-0">
                                    <p class="text-xs font-semibold leading-relaxed break-all text-left">${escapeHTML(msg.message)}</p>
                                    <div class="text-left mt-1 opacity-85">
                                        <span class="text-[7px] text-slate-400 font-bold uppercase tracking-wider">${msg.msg_time}</span>
                                    </div>
                                </div>`;
                            }
                        });
                    }

                    chatBox.innerHTML = html;

                    if (playNotification && messages.length > lastMessageCount) {
                        const latestMsg = messages[messages.length - 1];
                        if (latestMsg.is_admin === 1) {
                            playIncomingBeep();
                        }
                        scrollToBottom();
                    } else if (messages.length !== lastMessageCount) {
                        scrollToBottom();
                    }
                    
                    lastMessageCount = messages.length;
                }
            })
            .catch(err => console.error(err));
    }

    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        e.stopPropagation();

        const text = msgInput.value.trim();
        if (text === '') return;

        msgInput.value = '';

        const now = new Date();
        let hours = now.getHours();
        let minutes = now.getMinutes();
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        const timeStr = hours + ':' + minutes + ' ' + ampm;

        const tempId = 'temp-' + Date.now();
        const tempHtml = `
        <div id="${tempId}" class="self-end bg-gradient-to-br from-blue-500 to-indigo-650 text-white px-4 py-2.5 rounded-2xl rounded-tr-none shadow-sm max-w-[80%] my-1 shrink-0">
            <p class="text-xs font-semibold leading-relaxed break-all text-left">${escapeHTML(text)}</p>
            <div class="flex items-center justify-end gap-1 mt-1 opacity-80">
                <span class="text-[7px] font-bold uppercase tracking-wider">${timeStr}</span>
                <i class="fa-solid fa-clock text-white/50 ml-1 animate-pulse" id="icon-${tempId}"></i>
            </div>
        </div>`;
        
        const emptyCard = chatBox.querySelector('.my-auto');
        if (emptyCard) {
            chatBox.innerHTML = '';
        }

        chatBox.insertAdjacentHTML('beforeend', tempHtml);
        scrollToBottom();

        const formData = new FormData();
        formData.append('message', text);
        formData.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('chat.send') }}", {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                const icon = document.getElementById(`icon-${tempId}`);
                if (icon) {
                    icon.className = 'fa-solid fa-check text-white/50 ml-1';
                }
                loadMessages(false);
            } else {
                alert('Submission error: ' + data.message);
                const tempEl = document.getElementById(tempId);
                if (tempEl) tempEl.remove();
            }
        })
        .catch(err => {
            console.error(err);
            const tempEl = document.getElementById(tempId);
            if (tempEl) tempEl.remove();
        });
    });

    function scrollToBottom() {
        const container = document.getElementById('chatBoxContainer');
        if (container) {
            container.scrollTo({
                top: container.scrollHeight,
                behavior: 'smooth'
            });
        }
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[tag] || tag)
        );
    }

    document.addEventListener('DOMContentLoaded', () => {
        loadMessages();
        setInterval(() => {
            loadMessages(true);
        }, 4000);
    });
</script>
@endpush