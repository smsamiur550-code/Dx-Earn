@extends('layouts.app')

@section('title', 'Payment Gateway - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('convert') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Payment Gateway 🛡️</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-4">
        <div class="bg-blue-50 border border-blue-100 rounded-2xl p-4 text-center">
            <span class="text-[9px] font-black text-blue-500 uppercase tracking-widest block mb-1">Fee Required</span>
            <h2 class="text-xl font-black text-blue-900">{{ number_format(1 * $takaRate, 2) }} ৳</h2>
            <p class="text-[8px] font-bold text-blue-600 uppercase mt-1">Submit 1.00 USD ({{ number_format($takaRate, 2) }} ৳) conversion processing fee to make this swap</p>
        </div>

        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-150 space-y-2.5 shadow-inner text-left">
            <span class="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Conversion Details</span>
            <div class="flex justify-between items-center text-[10px] font-bold uppercase text-slate-700">
                <span>Swap:</span>
                <span>🪙 {{ number_format($amount, 2) }} Coins</span>
            </div>
            <div class="flex justify-between items-center text-[10px] font-bold uppercase text-slate-700">
                <span>Receive:</span>
                <span>💵 {{ number_format($tokens, 4) }} Tokens</span>
            </div>
        </div>

        <div class="bg-slate-50 p-4 rounded-2xl border border-slate-150 space-y-3 shadow-inner text-left">
            <span class="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Select Gateway Address</span>
            
            <div class="space-y-2 text-[10px] font-bold text-slate-600 uppercase">
                <div class="bg-white p-3 rounded-xl border border-slate-100 flex justify-between items-center">
                    <div>
                        <span class="text-[8px] font-black text-slate-400 block tracking-wider">Binance Pay</span>
                        <span class="text-slate-800 text-xs font-black select-all" id="binance-addr">{{ htmlspecialchars($paymentWalletBinance) }}</span>
                    </div>
                    <button onclick="copyAddr('binance-addr')" class="bg-slate-50 text-slate-500 border border-slate-150 px-3 py-1.5 rounded-lg active:scale-95 transition-transform"><i class="fa-regular fa-copy"></i></button>
                </div>
                
                <div class="bg-white p-3 rounded-xl border border-slate-100 flex justify-between items-center">
                    <div>
                        <span class="text-[8px] font-black text-slate-400 block tracking-wider">USDT Address (TRC20)</span>
                        <span class="text-slate-800 text-xs font-black select-all block truncate w-40" id="usdt-addr">{{ htmlspecialchars($paymentWalletUsdt) }}</span>
                    </div>
                    <button onclick="copyAddr('usdt-addr')" class="bg-slate-50 text-slate-500 border border-slate-150 px-3 py-1.5 rounded-lg active:scale-95 transition-transform"><i class="fa-regular fa-copy"></i></button>
                </div>
            </div>
        </div>

        <form method="POST" action="{{ route('payment.proof') }}" enctype="multipart/form-data" class="space-y-4">
            @csrf
            <input type="hidden" name="type" value="{{ $type }}">
            <input type="hidden" name="amount" value="{{ $amount }}">
            <input type="hidden" name="fee" value="{{ $fee }}">
            <input type="hidden" name="tokens" value="{{ $tokens }}">
            
            <div class="bg-slate-50 border border-slate-150 rounded-3xl p-4 text-center cursor-pointer relative h-28 flex flex-col justify-center items-center shadow-inner">
                <input type="file" name="screenshot" accept="image/*" required class="absolute inset-0 opacity-0 cursor-pointer w-full h-full" id="fileInput">
                <div class="space-y-1.5" id="uploadPlaceholder">
                    <i class="fa-solid fa-cloud-arrow-up text-2xl text-slate-400"></i>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-wide">Upload Payment Proof Screenshot</p>
                    <p class="text-[8px] font-bold text-slate-400 uppercase">Max size: 5MB (PNG, JPG, WEBP)</p>
                </div>
                <div class="hidden text-xs font-black text-emerald-600 animate-pulse" id="fileFeedback"></div>
            </div>

            <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-md bouncy-hover btn-glow-blue">Submit Proof for Verification</button>
        </form>
    </div>
</main>
@endsection

@push('scripts')
<script>
    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const placeholder = document.getElementById('uploadPlaceholder');
            const feedback = document.getElementById('fileFeedback');
            if (this.files && this.files[0]) {
                placeholder.classList.add('hidden');
                feedback.classList.remove('hidden');
                feedback.innerText = '📎 Attached: ' + this.files[0].name;
            }
        });
    }

    function copyAddr(id) {
        const el = document.getElementById(id);
        if (!el) return;
        navigator.clipboard.writeText(el.innerText).then(() => {
            if (window.GlobalPopup) {
                GlobalPopup.show('success', 'Copied!', 'Payment address copied to clipboard successfully. 📋', false, 1500);
            } else {
                alert('Copied to clipboard!');
            }
        });
    }
</script>
@endpush