@extends('layouts.app')

@section('title', 'Privacy & Terms - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('profile') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Privacy & Terms 🛡️</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    <div class="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm space-y-4 text-left">
        <div class="text-center">
            <span class="text-3xl">🛡️</span>
            <h2 class="text-sm font-black text-slate-800 uppercase mt-2">Privacy Policy</h2>
        </div>

        <div class="space-y-3.5 text-xs text-slate-500 font-semibold leading-relaxed">
            <p>Welcome to <b>DX EARN</b>. Your privacy and decentralized ledger security are highly important to our operational nodes. This privacy policy describes our standard methods regarding system data.</p>
            
            <h4 class="font-black text-slate-700 uppercase text-[10px] tracking-wider mt-4">1. Data We Collect</h4>
            <p>We only collect and process minimal credentials necessary to secure your node identity, including your Telegram ID, Google authenticated email scope, legal name, and KYC documentation images.</p>

            <h4 class="font-black text-slate-700 uppercase text-[10px] tracking-wider mt-4">2. Security of Documentation</h4>
            <p>Uploaded identity cards and selfie verification documentation are encrypted instantly using RSA-256 standard and stored securely in isolated offline cloud containers. These files are accessible only to audited verification validators.</p>

            <h4 class="font-black text-slate-700 uppercase text-[10px] tracking-wider mt-4">3. Device UID Auditing</h4>
            <p>To prevent multi-account exploit spamming, we securely log your browser/device static hardware fingerprint as a unique hash. Multiple concurrent active accounts mapped to the same fingerprint are immediately flagged.</p>
        </div>
    </div>
</main>
@endsection