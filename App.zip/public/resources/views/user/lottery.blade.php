@extends('layouts.app')

@section('title', 'Weekly Lottery - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Weekly Draw 🎫</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow pb-24">
    <!-- Lottery Countdown Banner -->
    <div class="bg-gradient-to-tr from-purple-600 via-indigo-600 to-blue-600 p-5 rounded-[2rem] text-white flex justify-between items-center relative overflow-hidden shadow-md">
        <div class="relative z-10 space-y-1 text-left">
            <span class="text-[8px] bg-white/20 px-2 py-0.5 rounded-full text-white font-extrabold uppercase tracking-widest inline-block">Draw Countdown</span>
            <h3 class="text-lg font-black uppercase tracking-wide">Sweepstakes Jackpot Draw ⏰</h3>
            <p class="text-[10px] text-white/95 leading-relaxed font-semibold">Next draw scheduled: <span class="font-mono text-yellow-300" id="lottery-time-label">Calculating...</span></p>
        </div>
        <i class="fa-solid fa-clock absolute -right-6 -bottom-6 text-7xl opacity-5"></i>
    </div>

    <!-- Rules & Prizes card -->
    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-3.5 text-left">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-gift text-purple-500"></i> Draw Rules & Prize Pool</h3>
        <p class="text-[10px] text-slate-500 font-semibold leading-relaxed">Purchase products from the DX store to earn automatically approved Sweepstakes Entry Tickets! Or buy tickets manually for 🪙 {{ number_format($ticketPriceVal ?? 50, 2) }} each. One lucky random ticket wins the grand jackpot of <b>🪙 {{ number_format($prizeAmount, 2) }} Coins</b> directly credited!</p>
    </div>

    <!-- User Tickets Ledger -->
    <div class="space-y-3 text-left">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest ml-1">My Active Entry Tickets ({{ $myTickets->count() }})</h3>
        <div class="space-y-2">
            @foreach ($myTickets as $ticket)
                @php
                    $status = strtolower($ticket->status);
                    $badgeClass = 'bg-amber-50 text-amber-600 border-amber-200';
                    if ($status === 'approved' || $status === 'winner') {
                        $badgeClass = 'bg-emerald-50 text-emerald-600 border-emerald-200';
                    } elseif ($status === 'lost') {
                        $badgeClass = 'bg-slate-100 text-slate-400 border-slate-200';
                    }
                @endphp
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center text-xs">
                            <span>🎫</span>
                        </div>
                        <div>
                            <h4 class="text-xs font-black text-slate-700 select-all">#{{ htmlspecialchars($ticket->ticket_number) }}</h4>
                            <p class="text-[8px] text-slate-400 font-bold uppercase mt-0.5">{{ $ticket->created_at->format('d M Y, h:i A') }}</p>
                        </div>
                    </div>
                    <div class="text-right shrink-0">
                        <span class="text-[8px] font-black border {{ $badgeClass }} px-2.5 py-1 rounded-md uppercase tracking-wider block w-fit ml-auto">{{ strtoupper($ticket->status) }}</span>
                        @if ($status === 'winner')
                            <span class="text-[9px] font-black text-emerald-600 block mt-1">🪙 +{{ number_format($ticket->prize_amount, 2) }}</span>
                        @endif
                    </div>
                </div>
            @endforeach

            @if ($myTickets->isEmpty())
                <div class="text-center py-12 opacity-50 bg-white rounded-3xl border border-slate-100 p-8">
                    <div class="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center text-slate-400 mx-auto mb-3"><i class="fa-solid fa-ticket text-lg"></i></div>
                    <p class="text-[10px] font-black uppercase text-slate-400 tracking-wider">You don't have any draw tickets yet.</p>
                </div>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    let countdownSec = {{ $secondsRemaining }};
    const labelEl = document.getElementById('lottery-time-label');

    function tick() {
        if (countdownSec <= 0) {
            labelEl.innerText = "DRAWING IN PROGRESS...";
            return;
        }
        countdownSec--;
        let d = Math.floor(countdownSec / 86400);
        let h = Math.floor((countdownSec % 86400) / 3600);
        let m = Math.floor((countdownSec % 3600) / 60);
        let s = countdownSec % 60;
        
        let labelText = '';
        if (d > 0) labelText += d + 'd ';
        labelText += h.toString().padStart(2,'0') + 'h ' + m.toString().padStart(2,'0') + 'm ' + s.toString().padStart(2,'0') + 's';
        
        labelEl.innerText = labelText;
    }
    setInterval(tick, 1000);
    tick();
</script>
@endpush