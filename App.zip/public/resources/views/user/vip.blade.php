@extends('layouts.app')

@section('title', 'VIP Booster - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">VIP Booster Hub 👑</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-header">
        💵 {{ number_format($user->balance_token ?? 0.00, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    @if ($activeVip)
        <div class="bg-gradient-to-tr from-amber-400 via-yellow-300 to-amber-500 p-5 rounded-[2rem] text-slate-900 shadow-sm relative overflow-hidden space-y-3 btn-glow-amber text-left">
            <span class="text-[9px] bg-black/10 px-2.5 py-1 rounded-full text-slate-900 font-extrabold uppercase tracking-widest inline-block">Active Booster Node</span>
            <div class="flex justify-between items-start">
                <div>
                    <h3 class="text-lg font-black uppercase tracking-wide">{{ htmlspecialchars($activeVip->plan->name ?? '') }}</h3>
                    <p class="text-[10px] text-slate-800 font-bold mt-1">Clock multipliers stacked. daily limits, mining, rewards directly doubled (2x)!</p>
                </div>
            </div>
            <div class="text-left">
                <span class="text-[8px] font-black block uppercase tracking-wider opacity-60">Expires On</span>
                <span class="text-xs font-black block font-mono">{{ $activeVip->expires_at->format('d M Y, h:i A') }}</span>
            </div>
        </div>
    @endif

    <div class="space-y-4">
        @foreach ($vipPlans as $plan)
            @php 
                $isOwned = ($activeVip && $activeVip->plan && $activeVip->plan->name === $plan->name);
            @endphp
            <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm flex flex-col justify-between relative overflow-hidden {{ $isOwned ? 'ring-2 ring-amber-400 shadow-md' : '' }} text-left">
                <div class="flex justify-between items-start">
                    <div>
                        <h4 class="text-sm font-black uppercase tracking-wide text-amber-500">{{ htmlspecialchars($plan->name) }}</h4>
                        <span class="text-[9px] font-bold uppercase text-slate-400">Duration: {{ $plan->duration_days }} Days</span>
                    </div>
                    <span class="text-sm font-black text-emerald-600">💵 {{ number_format($plan->price, 2) }}</span>
                </div>
                <p class="text-[10px] text-slate-500 font-semibold leading-relaxed mt-2.5">{{ htmlspecialchars($plan->benefits) }}</p>
                
                <div class="grid grid-cols-3 gap-2.5 mt-4 pt-3 border-t border-slate-100 text-center">
                    <div class="bg-slate-50 p-2 rounded-xl border border-slate-100 shadow-inner">
                        <span class="text-[7px] text-slate-500 font-bold block uppercase tracking-wide">Daily Games</span>
                        <span class="text-[9px] font-black text-amber-500 block mt-1 uppercase tracking-wider">Double (2x)</span>
                    </div>
                    <div class="bg-slate-50 p-2 rounded-xl border border-slate-100 shadow-inner">
                        <span class="text-[7px] text-slate-500 font-bold block uppercase tracking-wide">Mining Nodes</span>
                        <span class="text-[9px] font-black text-cyan-500 block mt-1">Double (2x)</span>
                    </div>
                    <div class="bg-slate-50 p-2 rounded-xl border border-slate-100 shadow-inner">
                        <span class="text-[7px] text-slate-500 font-bold block uppercase tracking-wide">Daily Rewards</span>
                        <span class="text-[9px] font-black text-emerald-600 block mt-1">Double (2x)</span>
                    </div>
                </div>
                
                <div class="pt-4 mt-2">
                    <form method="POST" action="{{ route('vip.buy') }}">
                        @csrf
                        <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                        <button type="submit" class="w-full py-3.5 bg-gradient-to-r from-amber-400 to-yellow-500 text-slate-900 hover:brightness-105 rounded-xl font-black text-[10px] uppercase tracking-widest transition-all shadow-md bouncy-hover flex items-center justify-center gap-1.5 btn-glow-amber">
                            👑 {{ $isOwned ? 'Extend / Stack Pass' : 'Buy Booster Pass' }}
                        </button>
                    </form>
                </div>
            </div>
        @endforeach
    </div>
</main>
@endsection