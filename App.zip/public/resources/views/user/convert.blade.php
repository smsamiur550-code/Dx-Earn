@extends('layouts.app')

@section('title', 'Convert Center - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('wallet') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Convert Center 🔄</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-4 flex-grow">
    @if(session('error'))
        <div class="bg-rose-50 text-rose-600 border border-rose-200 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2">
            <span>⚠️</span> {{ session('error') }}
        </div>
    @endif

    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-4">
        <div class="flex gap-2 border-b border-slate-100 pb-3">
            <button onclick="toggleSwapType('coin_to_token')" id="sub-swap-coin-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover">🪙 Coins to 💵 Tokens</button>
            <button onclick="toggleSwapType('token_to_dollar')" id="sub-swap-token-btn" class="sub-tab-btn flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover">💵 Tokens to ৳ BDT</button>
        </div>

        <!-- Coins to Tokens Form -->
        <form id="form-coin-to-token" method="POST" action="{{ route('convert.coin_to_token') }}" class="space-y-4">
            @csrf
            <div class="space-y-1 text-left">
                <div class="flex justify-between items-center text-[9px] font-black text-slate-400 uppercase ml-1">
                    <span>Convert Amount 🪙</span>
                    <span>Avail: <strong class="text-blue-600">🪙 {{ number_format($user->balance_coin, 2) }}</strong></span>
                </div>
                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between shadow-inner focus-within:ring-2 focus-within:ring-blue-500/10">
                    <input type="number" step="0.01" id="coin-input-val" name="amount_coin" placeholder="0.00" oninput="calculateCoinToToken()" required class="bg-transparent text-sm font-black text-slate-800 w-full outline-none">
                    <span class="text-[10px] font-black uppercase text-blue-600 shrink-0">🪙 {{ $coinName }}</span>
                </div>
            </div>

            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 shadow-inner text-left">
                <span class="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Receive Preview</span>
                <div class="flex justify-between items-center">
                    <span class="text-xs font-black text-slate-800" id="coin-preview-val">💵 0.0000</span>
                    <span class="text-[9px] font-black text-amber-500 uppercase tracking-wider">💵 {{ $tokenName }}</span>
                </div>
            </div>

            <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover btn-glow-blue">Proceed to Payment Proof ➔</button>
        </form>

        <!-- Tokens to BDT Form -->
        <form id="form-token-to-dollar" method="POST" action="{{ route('convert.token_to_dollar') }}" class="hidden space-y-4">
            @csrf
            <div class="space-y-1 text-left">
                <div class="flex justify-between items-center text-[9px] font-black text-slate-400 uppercase ml-1">
                    <span>Convert Amount 💵</span>
                    <span>Avail: <strong class="text-amber-500">💵 {{ number_format($user->balance_token, 2) }}</strong></span>
                </div>
                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between shadow-inner focus-within:ring-2 focus-within:ring-emerald-500/10">
                    <input type="number" step="0.01" id="token-input-val" name="amount_token" placeholder="0.00" oninput="calculateTokenToUSD()" {{ !$tokenToDollarEnabled ? 'disabled' : '' }} required class="bg-transparent text-sm font-black text-slate-800 w-full outline-none">
                    <span class="text-[10px] font-black uppercase text-amber-500 shrink-0">💵 {{ $tokenName }}</span>
                </div>
            </div>

            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2 shadow-inner text-left">
                <span class="text-[9px] font-black text-slate-400 uppercase tracking-widest block">Receive Preview</span>
                <div class="flex justify-between items-center">
                    <span class="text-xs font-black text-slate-800" id="token-preview-val">0.00 ৳</span>
                    <span class="text-[9px] font-black text-emerald-600 uppercase tracking-wider">Taka Balance</span>
                </div>
            </div>

            @if (!$tokenToDollarEnabled)
                <div class="bg-amber-50 p-3 rounded-xl border border-amber-200 text-amber-600 text-[9px] text-center shadow-inner">🔒 Token exchange is temporarily locked by Admin.</div>
            @else
                <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover btn-glow-emerald">Swap Tokens</button>
            @endif
        </form>
    </div>
</main>
@endsection

@push('scripts')
<script>
    const coinToTokenRate = {{ $rateCoinToToken }};
    const convertFeePercent = {{ $convertFeePercent }};
    const tokenToDollarRate = {{ $rateTokenToDollar }};
    const bdtRate = {{ $takaRate }};

    function toggleSwapType(type) {
        const btnCoin = document.getElementById('sub-swap-coin-btn');
        const btnToken = document.getElementById('sub-swap-token-btn');
        const formCoin = document.getElementById('form-coin-to-token');
        const formToken = document.getElementById('form-token-to-dollar');

        if (type === 'coin_to_token') {
            btnCoin.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            btnToken.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            formCoin.classList.remove('hidden');
            formToken.classList.add('hidden');
        } else {
            btnCoin.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-slate-500 bg-slate-50 bouncy-hover";
            btnToken.className = "flex-1 py-2.5 rounded-xl text-[10px] font-black uppercase text-center text-white bg-blue-600 bouncy-hover";
            formCoin.classList.add('hidden');
            formToken.classList.remove('hidden');
        }
    }

    function calculateCoinToToken() {
        const val = parseFloat(document.getElementById('coin-input-val').value) || 0;
        const fee = (val * convertFeePercent) / 100;
        const net = val - fee;
        const res = net * coinToTokenRate;
        document.getElementById('coin-preview-val').innerText = '💵 ' + res.toFixed(4);
    }

    function calculateTokenToUSD() {
        const val = parseFloat(document.getElementById('token-input-val').value) || 0;
        const resUsd = val * tokenToDollarRate;
        const resBdt = resUsd * bdtRate;
        document.getElementById('token-preview-val').innerText = resBdt.toFixed(2) + ' ৳';
    }
</script>
@endpush