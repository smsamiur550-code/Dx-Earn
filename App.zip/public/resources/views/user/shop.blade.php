@extends('layouts.app')

@section('title', 'DX Premium Shop')

@section('content')
@if ($showCountryModal)
<div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-6">
    <div class="bg-white border border-slate-100 rounded-[2.5rem] w-full max-w-sm p-6 text-center space-y-6 shadow-xl max-h-[85vh] flex flex-col justify-between">
        <div class="w-16 h-16 bg-blue-50 border border-blue-100 rounded-full flex items-center justify-center text-3xl mx-auto shadow-inner shrink-0">🌐</div>
        <div class="shrink-0">
            <h2 class="text-lg font-black text-slate-900 uppercase tracking-wider">Select Your Country</h2>
            <p class="text-[10px] text-slate-400 mt-1 uppercase tracking-wide">Localized deals and local payment currencies</p>
        </div>
        <!-- Route corrected to route('shop.country') -->
        <form method="POST" action="{{ route('shop.country') }}" class="space-y-4 overflow-y-auto pr-1 flex-1 py-2 no-scrollbar">
            @csrf
            <select name="selected_country" required class="w-full bg-slate-50 border border-slate-200 text-slate-800 py-4 px-4 rounded-2xl text-xs font-bold outline-none focus:border-blue-400 transition-all">
                <option value="" disabled {{ empty($userCountry) ? 'selected' : '' }}>Choose Region</option>
                @foreach ($countries as $country)
                    <option value="{{ htmlspecialchars($country) }}" {{ $userCountry === $country ? 'selected' : '' }}>{{ htmlspecialchars($country) }}</option>
                @endforeach
            </select>
            <button type="submit" class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover shadow-md shrink-0">Save Selection</button>
        </form>
    </div>
</div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-40 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <div class="text-center">
        <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">DX Premium Shop 🛍️</h1>
        <a href="{{ route('shop', ['change_country' => 1]) }}" class="text-[8px] bg-slate-50 border border-slate-150 font-black px-2 py-0.5 rounded uppercase mt-0.5 inline-block active:scale-95 transition-transform">Region: {{ htmlspecialchars($userCountry ?: 'Set Region') }} ✏️</a>
    </div>
    <a href="{{ route('shop.orders') }}" class="w-9 h-9 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 border border-blue-100 text-base bouncy-hover">
        📦
    </a>
</div>

<div class="p-4 space-y-4">
    @if ($isRestricted)
        <div class="p-6 text-center space-y-6 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm my-6">
            <div class="w-20 h-20 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-4xl mx-auto shadow-inner">📍</div>
            <div class="space-y-2">
                <h3 class="text-sm font-black text-rose-600 uppercase tracking-widest">Region Blocked</h3>
                <p class="text-xs text-slate-500 font-bold leading-relaxed px-4">Our native e-commerce store is currently available exclusively for Bangladesh users. Please select Bangladesh or contact support desk.</p>
            </div>
            <div class="pt-2">
                <a href="{{ route('shop', ['change_country' => 1]) }}" class="block w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover shadow-md btn-glow-blue">Change Server Location ✏️</a>
            </div>
        </div>
    @else
        <!-- Carousel Slider -->
        <div class="relative w-full h-36 rounded-3xl overflow-hidden shadow-sm border border-slate-100 bg-white">
            <div class="w-full h-full relative" id="shopSliderContainer">
                @if (!empty($sliderImages))
                    @foreach ($sliderImages as $index => $imgPath)
                        <div class="absolute inset-0 w-full h-full {{ $index === 0 ? 'block' : 'hidden' }}" id="shop-slide-{{ $index }}">
                            <img src="{{ htmlspecialchars($imgPath) }}" class="w-full h-full object-cover">
                        </div>
                    @endforeach
                @else
                    <div class="absolute inset-0 w-full h-full bg-gradient-to-tr from-blue-600 to-indigo-650 p-5 flex flex-col justify-center text-white">
                        <div class="text-left">
                            <h3 class="text-xs font-black uppercase tracking-wider text-yellow-305">⚡ DX Premium Store</h3>
                            <p class="text-[10px] text-white/95 font-semibold leading-relaxed mt-1">Get high-end physical products and cod cash benefits with your tokens!</p>
                        </div>
                    </div>
                @endif
            </div>
        </div>

        <!-- Categories -->
        <div class="space-y-3">
            <h3 class="text-xs font-black text-slate-700 uppercase tracking-wider pl-1 text-left">Store Categories</h3>
            <div class="flex gap-3 overflow-x-auto pb-1 no-scrollbar shrink-0">
                @foreach ($categories as $cat)
                    <div class="bg-white border border-slate-150 p-3 rounded-2xl flex items-center gap-2 shadow-sm shrink-0">
                        <span class="text-lg">🛍️</span>
                        <span class="text-[10px] font-black uppercase tracking-wider text-slate-700">{{ htmlspecialchars($cat->name) }}</span>
                    </div>
                @endforeach
            </div>
        </div>

        <!-- All Products -->
        <div class="space-y-3">
            <h3 class="text-xs font-black text-slate-700 uppercase tracking-wider pl-1 text-left">All Products</h3>
            <div class="grid grid-cols-2 gap-3.5">
                @foreach ($products as $p)
                    <div class="bg-white rounded-[2rem] border border-slate-100 p-3 shadow-sm flex flex-col justify-between h-[280px]">
                        <div class="space-y-2">
                            <div class="w-full h-28 rounded-2xl overflow-hidden bg-slate-50 border border-slate-100 relative shadow-inner">
                                <img src="{{ asset('uploads/' . ($p->image ?? 'default.png')) }}" class="w-full h-full object-cover">
                            </div>
                            <div class="space-y-1 text-left">
                                <span class="text-[8px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-black uppercase tracking-wider block w-fit">{{ htmlspecialchars($p->category_name ?? 'General') }}</span>
                                <h4 class="text-xs font-black text-slate-700 uppercase tracking-wide truncate mt-1">{{ htmlspecialchars($p->name) }}</h4>
                                <span class="text-[11px] font-black text-emerald-600 block">{{ number_format($p->price * $takaRate, 2) }} ৳</span>
                            </div>
                        </div>
                        <div class="pt-2 border-t border-slate-100/50">
                            <a href="{{ route('shop.product', ['id' => $p->id]) }}" class="block w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-center rounded-xl text-[10px] font-black uppercase tracking-wider bouncy-hover shadow-sm btn-glow-blue">
                                Buy Now / Details
                            </a>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    @endif
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const slides = document.querySelectorAll('[id^="shop-slide-"]');
        let currentSlide = 0;

        if (slides.length > 1) {
            setInterval(() => {
                slides[currentSlide].classList.add('hidden');
                currentSlide = (currentSlide + 1) % slides.length;
                slides[currentSlide].classList.remove('hidden');
            }, 4000);
        }
    });
</script>
@endpush