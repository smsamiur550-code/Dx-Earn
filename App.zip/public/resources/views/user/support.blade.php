@extends('layouts.app')

@section('title', 'Support Center - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('profile') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest text-center">Support Center 📞</h1>
    <div class="w-6"></div>
</div>

<main class="p-4 space-y-5 flex-grow">
    <!-- Live Support Chat Box -->
    <a href="{{ route('chat') }}" class="block bg-gradient-to-r from-blue-500 to-indigo-650 p-5 rounded-[2rem] text-white text-center shadow-md relative overflow-hidden bouncy-hover duration-150 btn-glow-blue">
        <div class="relative z-10 space-y-1">
            <span class="text-[9px] bg-white/20 px-2.5 py-1 rounded-full text-white font-extrabold uppercase tracking-widest inline-block mb-1">Instant Support Channels</span>
            <h3 class="text-lg font-black uppercase tracking-wide">Live Chat Assistance 💬</h3>
            <p class="text-[10px] text-blue-50 font-semibold leading-relaxed mt-1">Connect with our support nodes and get assistance from developers directly. ⚡</p>
        </div>
        <i class="fa-solid fa-comments absolute -right-6 -bottom-6 text-7xl opacity-5"></i>
    </a>

    <!-- Social Grid -->
    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Official Networks</h3>
        <div class="grid grid-cols-2 gap-3">
            <a href="{{ htmlspecialchars($telegramChannel) }}" target="_blank" class="bg-white p-4 rounded-3xl border border-slate-150 shadow-sm flex flex-col justify-between h-28 bouncy-hover text-left">
                <div class="w-9 h-9 bg-sky-50 text-sky-500 rounded-xl flex items-center justify-center text-sm border border-sky-100/50 shadow-inner">
                    <i class="fa-brands fa-telegram-plane"></i>
                </div>
                <div>
                    <h4 class="text-xs font-black text-slate-800 uppercase">Telegram Channel</h4>
                    <span class="text-[9px] text-slate-400 font-bold block mt-0.5">News & Promos</span>
                </div>
            </a>

            <a href="{{ htmlspecialchars($telegramGroup) }}" target="_blank" class="bg-white p-4 rounded-3xl border border-slate-150 shadow-sm flex flex-col justify-between h-28 bouncy-hover text-left">
                <div class="w-9 h-9 bg-blue-50 text-blue-500 rounded-xl flex items-center justify-center text-sm border border-blue-100/30 shadow-inner">
                    <i class="fa-solid fa-users"></i>
                </div>
                <div>
                    <h4 class="text-xs font-black text-slate-800 uppercase">Telegram Group</h4>
                    <span class="text-[9px] text-slate-400 font-bold block mt-0.5">Community Chat</span>
                </div>
            </a>

            <a href="{{ htmlspecialchars($whatsappGroup) }}" target="_blank" class="bg-white p-4 rounded-3xl border border-slate-150 shadow-sm flex flex-col justify-between h-28 bouncy-hover text-left">
                <div class="w-9 h-9 bg-emerald-50 text-emerald-500 rounded-xl flex items-center justify-center text-sm border border-emerald-100/30 shadow-inner">
                    <i class="fa-brands fa-whatsapp"></i>
                </div>
                <div>
                    <h4 class="text-xs font-black text-slate-800 uppercase">WhatsApp Group</h4>
                    <span class="text-[9px] text-slate-400 font-bold block mt-0.5">Instant Support</span>
                </div>
            </a>

            <a href="{{ htmlspecialchars($youtubeSupport) }}" target="_blank" class="bg-white p-4 rounded-3xl border border-slate-150 shadow-sm flex flex-col justify-between h-28 bouncy-hover text-left">
                <div class="w-9 h-9 bg-red-50 text-red-500 rounded-xl flex items-center justify-center text-sm border border-red-100/30 shadow-inner">
                    <i class="fa-brands fa-youtube"></i>
                </div>
                <div>
                    <h4 class="text-xs font-black text-slate-800 uppercase">YouTube Channel</h4>
                    <span class="text-[9px] text-slate-400 font-bold block mt-0.5">Video Guides</span>
                </div>
            </a>
        </div>
    </div>

    <!-- FAQ Accordion -->
    <div class="bg-white p-5 rounded-[2rem] border border-slate-100 shadow-sm space-y-4">
        <h3 class="text-xs font-black text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><i class="fa-solid fa-circle-info text-blue-500"></i> Interactive FAQ</h3>
        <div class="space-y-3">
            @foreach ($systemFaqs as $faq)
                <details class="group border border-slate-100 bg-slate-50/50 rounded-2xl overflow-hidden p-4 transition-all duration-300 text-left">
                    <summary class="list-none text-xs font-extrabold text-slate-800 flex justify-between items-center cursor-pointer select-none outline-none">
                        <span>{{ htmlspecialchars($faq['q']) }}</span>
                        <span class="w-6 h-6 rounded-full bg-white border border-slate-100 flex items-center justify-center text-slate-400 group-open:rotate-180 transition-transform duration-300 shadow-sm">
                            <i class="fa-solid fa-chevron-down text-[9px]"></i>
                        </span>
                    </summary>
                    <p class="text-[10px] text-slate-500 font-semibold leading-relaxed mt-2.5 pt-2.5 border-t border-slate-150/65">
                        {{ htmlspecialchars($faq['a']) }}
                    </p>
                </details>
            @endforeach
        </div>
    </div>
</main>
@endsection