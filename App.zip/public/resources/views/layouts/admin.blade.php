<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>@yield('title', 'Admin Panel')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    @stack('styles')
    <style>
        body {
            background-color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="bg-slate-50 font-sans min-h-screen flex flex-col text-slate-800">

    <!-- Admin Left Navigation Drawer Overlay -->
    <div id="admin-drawer-overlay" onclick="toggleAdminDrawer(false)" class="fixed inset-0 bg-slate-900/30 z-[9990] opacity-0 pointer-events-none transition-opacity duration-200"></div>
    
    <!-- Admin Left Navigation Drawer -->
    <div id="admin-drawer" class="fixed inset-y-0 left-0 w-72 max-w-[80vw] bg-white border-r border-slate-200 shadow-xl z-[9995] -translate-x-full transition-transform duration-200 ease-in-out flex flex-col justify-between p-5 overflow-y-auto no-scrollbar">
        <div class="space-y-6">
            <div class="flex items-center gap-3 border-b border-slate-100 pb-5">
                <div class="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-lg font-black border border-blue-100 shadow-inner">🛡️</div>
                <div>
                    <h4 class="text-xs font-black text-slate-800 uppercase tracking-wide">{{ session('admin_id') }}</h4>
                    <span class="text-[8px] font-black {{ session('admin_role') === 'owner' ? 'bg-amber-100 text-amber-700 border-amber-200' : 'bg-slate-100 text-slate-700' }} px-2.5 py-0.5 rounded uppercase tracking-wider block w-fit mt-0.5">{{ strtoupper(session('admin_role', 'ADMIN')) }}</span>
                </div>
            </div>
            
            <div class="space-y-3">
                <!-- Navigation -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>Navigation</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        <a href="{{ route('admin.dashboard') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.dashboard' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">📊 Dashboard</a>
                    </div>
                </details>
                
                <!-- Directory Hubs -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>Directory Hubs</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        @if(session('admin_role') === 'owner' || in_array('user.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.users') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.users' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">👥 Members list</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('chat.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.chat') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.chat' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">💬 Live Support</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('task.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.tasks') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.tasks' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">📝 Missions</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('gift.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.gift') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.gift' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🎁 Promo Codes</a>
                        @endif
                    </div>
                </details>

                <!-- Financial Core -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>Financial Core</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        @if(session('admin_role') === 'owner' || in_array('payment.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.payment') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.payment' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">💳 Deposits</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('withdraw.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.withdraw') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.withdraw' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">💵 Cashout Audit</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('withdraw2.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.withdraw_feed') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.withdraw_feed' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">⚙️ Voucher Feed</a>
                        @endif
                    </div>
                </details>

                <!-- E-Store System -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>E-Store System</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        @if(session('admin_role') === 'owner' || in_array('products.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.products') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.products' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">📦 Products Directory</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('orders.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.orders') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.orders' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🚚 COD Orders</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('lottery.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.lottery') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.lottery' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🎫 Weekly Draw</a>
                        @endif
                    </div>
                </details>

                <!-- Interactive Node -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>Interactive Node</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        @if(session('admin_role') === 'owner' || in_array('game.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.game') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.game' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🕹️ Games settings</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('mining.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.mining') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.mining' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">⛏️ Mining config</a>
                        @endif
                        @if(session('admin_role') === 'owner' || in_array('vip.php', session('admin_permissions', [])))
                            <a href="{{ route('admin.vip') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.vip' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">👑 VIP configuration</a>
                        @endif
                    </div>
                </details>

                <!-- Management -->
                <details class="group border border-slate-200 bg-white rounded-2xl overflow-hidden p-3 transition-all duration-200" open>
                    <summary class="list-none text-[10px] font-black text-slate-400 flex justify-between items-center cursor-pointer select-none outline-none uppercase tracking-widest">
                        <span>Management</span>
                        <i class="fa-solid fa-chevron-down text-[8px] group-open:rotate-180 transition-transform duration-200"></i>
                    </summary>
                    <div class="space-y-1 pt-3 border-t border-slate-100 mt-3 flex flex-col">
                        @if(session('admin_role') === 'owner')
                            <a href="{{ route('admin.admin_list') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.admin_list' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🛡️ Staff recruitment</a>
                            <a href="{{ route('admin.settings') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.settings' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">⚙️ Core parameters</a>
                            <a href="{{ route('admin.maintenance') }}" class="text-xs font-bold text-slate-600 p-2.5 rounded-xl hover:bg-slate-50 flex items-center gap-2 {{ Route::currentRouteName() === 'admin.maintenance' ? 'bg-blue-50 text-blue-600 font-black' : '' }}">🧹 Maintenance</a>
                        @endif
                    </div>
                </details>
            </div>
        </div>
        <div class="border-t border-slate-200 pt-4 shrink-0">
            <a href="{{ route('admin.logout') }}" class="block w-full text-center py-3 bg-red-50 hover:bg-red-100 text-red-600 border border-red-100 rounded-xl text-[10px] font-black uppercase tracking-widest">🚪 LOGOUT DASHBOARD</a>
        </div>
    </div>

    <!-- Header -->
    <header class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white border-b border-slate-200 z-[9980] shrink-0">
        <div class="flex items-center gap-3">
            <button onclick="toggleAdminDrawer(true)" class="text-slate-500 hover:text-slate-800 active:scale-95 transition-transform p-1.5 bg-slate-50 rounded-xl border border-slate-200 shrink-0">
                <i class="fa-solid fa-bars text-base"></i>
            </button>
            <div>
                @if(Route::currentRouteName() !== 'admin.dashboard')
                    <a href="{{ route('admin.dashboard') }}" class="text-slate-400 hover:text-slate-600 text-xs font-bold mr-1 flex items-center gap-1 inline-flex"><i class="fa-solid fa-arrow-left text-[10px]"></i> Back</a>
                @endif
                <h2 class="text-xs font-black text-slate-900 uppercase tracking-widest leading-none mt-1">@yield('page_title', 'Admin Panel')</h2>
            </div>
        </div>
        <div class="flex items-center gap-2.5 shrink-0">
            <div class="text-right">
                <h5 class="text-[10px] font-black text-slate-800 leading-none">{{ session('admin_id') }}</h5>
                <span class="text-[7px] font-black uppercase text-slate-500 mt-1 block tracking-wider">{{ strtoupper(session('admin_role', 'ADMIN')) }}</span>
            </div>
            <div class="w-8 h-8 rounded-full border border-slate-200 p-0.5 bg-slate-50 shrink-0 flex items-center justify-center text-sm">
                <span>🛡️</span>
            </div>
        </div>
    </header>

    <!-- Main Content Portal -->
    <div class="flex-grow">
        @yield('content')
    </div>

    <!-- Global popup system for admin alerts -->
    @include('common.popup')

    <script>
        function toggleAdminDrawer(isOpen) {
            const drawer = document.getElementById('admin-drawer');
            const overlay = document.getElementById('admin-drawer-overlay');
            if (isOpen) {
                drawer.classList.remove('-translate-x-full');
                overlay.classList.remove('opacity-0', 'pointer-events-none');
                overlay.classList.add('opacity-100');
            } else {
                drawer.classList.add('-translate-x-full');
                overlay.classList.remove('opacity-100');
                overlay.classList.add('opacity-0', 'pointer-events-none');
            }
        }

        document.addEventListener('click', function(e) {
            const target = e.target.closest('button, a, input[type="submit"], [role="button"]');
            if (target && window.navigator && window.navigator.vibrate) {
                window.navigator.vibrate(15);
            }
        });
    </script>
    @stack('scripts')
</body>
</html>