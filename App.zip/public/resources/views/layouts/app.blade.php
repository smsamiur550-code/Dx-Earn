<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>@yield('title', 'DX EARN')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    @stack('styles')
    <style>
        body {
            background-color: #f8fafc;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            overflow-x: hidden;
            -webkit-user-select: none;
            user-select: none;
        }
        .app-container {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            background-color: #ffffff;
        }
        @media (min-width: 640px) {
            .app-container {
                max-width: 480px;
                margin: 0 auto;
                box-shadow: 0 12px 60px rgba(0,0,0,0.05);
                border-left: 1px solid #e2e8f0;
                border-right: 1px solid #e2e8f0;
                min-height: 100vh;
            }
        }
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;
            scrollbar-width: none;
        }
        .color-shifting-btn {
            background-size: 200% auto;
            animation: flowGradient 3s linear infinite;
        }
        @keyframes flowGradient {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .bouncy-hover {
            transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .bouncy-hover:active {
            transform: scale(0.95);
        }
        .btn-glow-blue {
            box-shadow: 0 4px 14px rgba(59, 130, 246, 0.3);
        }
        .btn-glow-emerald {
            box-shadow: 0 4px 14px rgba(16, 185, 129, 0.3);
        }
        .btn-glow-amber {
            box-shadow: 0 4px 14px rgba(245, 158, 11, 0.3);
        }
        .pop-glow-success { box-shadow: 0 0 25px rgba(16, 185, 129, 0.15); border-color: #10b981; }
        .pop-glow-warning { box-shadow: 0 0 25px rgba(245, 158, 11, 0.15); border-color: #f59e0b; }
        .pop-glow-failed { box-shadow: 0 0 25px rgba(239, 68, 68, 0.15); border-color: #ef4444; }
    </style>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <script>
        (function() {
            const tgApp = window.Telegram?.WebApp;
            if (tgApp) {
                tgApp.ready();
                tgApp.expand();
                if (tgApp.BackButton) {
                    const allowedBackPages = ['/', '/login'];
                    const currentPath = window.location.pathname;
                    if (!allowedBackPages.includes(currentPath) && currentPath !== '') {
                        tgApp.BackButton.show();
                        tgApp.BackButton.onClick(function() {
                            tgApp.HapticFeedback?.impactOccurred('medium');
                            window.location.href = "{{ route('home') }}";
                        });
                    } else {
                        tgApp.BackButton.hide();
                    }
                }
            }

            window.triggerVibration = function(style = 'light') {
                if (tgApp && tgApp.HapticFeedback) {
                    tgApp.HapticFeedback.impactOccurred(style);
                } else if (navigator.vibrate) {
                    navigator.vibrate(style === 'heavy' ? 50 : (style === 'medium' ? 30 : 15));
                }
            }

            document.addEventListener('click', function(e) {
                const target = e.target.closest('button, a, [role="button"]');
                if (target) {
                    triggerVibration('light');
                    target.style.transition = 'transform 0.1s cubic-bezier(0.175, 0.885, 0.32, 1.275)';
                    target.style.transform = 'scale(0.96)';
                    setTimeout(() => {
                        target.style.transform = 'none';
                    }, 100);
                }
            });

            document.addEventListener('submit', function(e) {
                const form = e.target;
                const btn = form.querySelector('button[type="submit"]');
                if (btn) {
                    if (btn.dataset.clicked === "true") {
                        e.preventDefault();
                        return false;
                    }
                    
                    triggerVibration('medium');
                    btn.dataset.clicked = "true";
                    btn.classList.add('opacity-75', 'cursor-not-allowed');
                    
                    let loader = document.getElementById('global-page-loader');
                    if (!loader) {
                        loader = document.createElement('div');
                        loader.id = 'global-page-loader';
                        loader.style.position = 'fixed';
                        loader.style.top = '0';
                        loader.style.left = '0';
                        loader.style.width = '100vw';
                        loader.style.height = '100vh';
                        loader.style.background = 'rgba(255, 255, 255, 0.9)';
                        loader.style.backdropFilter = 'blur(8px)';
                        loader.style.display = 'flex';
                        loader.style.justifyContent = 'center';
                        loader.style.alignItems = 'center';
                        loader.style.zIndex = '99999';
                        loader.innerHTML = `
                            <div style="background:white; padding:35px; border-radius:32px; box-shadow:0 20px 40px rgba(0,0,0,0.05); border:1px solid #3b82f6; text-align:center; animation: popUp 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);">
                                <div style="font-size:52px; margin-bottom:15px; animation: spinCoin 1s linear infinite;">🪙</div>
                                <p style="margin:0; font-family:-apple-system, sans-serif; font-size:15px; font-weight:900; color:#1e293b; letter-spacing:-0.3px;">Processing Request... ⚡</p>
                            </div>
                            <style>
                                @keyframes spinCoin {
                                    0% { transform: rotateY(0deg); }
                                    100% { transform: rotateY(360deg); }
                                }
                                @keyframes popUp {
                                    0% { transform: scale(0.8); opacity: 0; }
                                    100% { transform: scale(1); opacity: 1; }
                                }
                            </style>
                        `;
                        document.body.appendChild(loader);
                    }
                    
                    setTimeout(() => {
                        btn.disabled = true;
                    }, 10);
                }
            });
        })();
    </script>
</head>
<body class="h-full">
    <div class="app-container">
        <main class="flex-grow pb-24">
            @yield('content')
        </main>
    </div>

    <!-- Bottom Navigation Bar -->
    @if(in_array(Route::currentRouteName(), ['home', 'mining', 'games', 'reffer', 'profile']))
    <nav class="fixed bottom-4 left-1/2 -translate-x-1/2 w-[calc(100%-2rem)] max-w-[448px] bg-white border border-slate-150 h-16 rounded-3xl flex justify-around items-center shadow-[0_10px_35px_rgba(0,0,0,0.06)] z-50">
        <a href="{{ route('games') }}" class="flex flex-col items-center gap-1 transition-transform duration-100 active:scale-95 nav-btn bouncy-hover">
            <span class="text-xl">🎮</span>
            <span class="text-[9px] font-black uppercase tracking-wider {{ Route::currentRouteName() === 'games' ? 'text-blue-600' : 'text-slate-400' }}">Games</span>
        </a>
        <a href="{{ route('mining') }}" class="flex flex-col items-center gap-1 transition-transform duration-100 active:scale-95 nav-btn bouncy-hover">
            <span class="text-xl">⛏️</span>
            <span class="text-[9px] font-black uppercase tracking-wider {{ Route::currentRouteName() === 'mining' ? 'text-amber-500' : 'text-slate-400' }}">Mining</span>
        </a>
        <a href="{{ route('home') }}" class="flex flex-col items-center -mt-8 transition-transform duration-100 active:scale-95 nav-btn bouncy-hover">
            <div class="w-14 h-14 bg-gradient-to-tr from-blue-500 via-indigo-500 to-purple-600 rounded-full flex items-center justify-center shadow-[0_8px_20px_rgba(79,70,229,0.3)] border-4 border-white">
                <span class="text-2xl">🏠</span>
            </div>
            <span class="text-[9px] font-black uppercase mt-1 text-indigo-600 tracking-wider">Home</span>
        </a>
        <a href="{{ route('reffer') }}" class="flex flex-col items-center gap-1 transition-transform duration-100 active:scale-95 nav-btn bouncy-hover">
            <span class="text-xl">🤝</span>
            <span class="text-[9px] font-black uppercase tracking-wider {{ Route::currentRouteName() === 'reffer' ? 'text-emerald-500' : 'text-slate-400' }}">Team</span>
        </a>
        <a href="{{ route('profile') }}" class="flex flex-col items-center gap-1 transition-transform duration-100 active:scale-95 nav-btn bouncy-hover">
            <span class="text-xl">👤</span>
            <span class="text-[9px] font-black uppercase tracking-wider {{ Route::currentRouteName() === 'profile' ? 'text-purple-500' : 'text-slate-400' }}">Profile</span>
        </a>
    </nav>
    @endif

    <!-- Global System Popup Portal -->
    <div id="global-popup-overlay" class="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-[99999] flex items-center justify-center opacity-0 pointer-events-none transition-opacity duration-200">
        <div id="global-popup-card" class="w-[90%] max-w-[380px] bg-white rounded-[32px] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-slate-100 transform scale-90 opacity-0 transition-all duration-200 relative flex flex-col items-center p-6 text-center">
            <canvas id="pop-confetti-canvas" class="absolute inset-0 w-full h-full pointer-events-none opacity-0 transition-opacity duration-500"></canvas>
            <div id="pop-icon-wrapper" class="w-16 h-16 rounded-full flex items-center justify-center mb-4 text-3xl shadow-inner"></div>
            <h3 id="pop-title" class="text-xl font-black text-slate-800 tracking-tight mb-2"></h3>
            <p id="pop-message" class="text-slate-500 text-sm leading-relaxed mb-6 font-semibold"></p>
            <button id="pop-close-btn" class="w-full py-3.5 px-6 rounded-2xl font-black text-xs uppercase tracking-widest text-white shadow-md active:scale-95 duration-100 bouncy-hover"></button>
        </div>
    </div>

    <script>
    window.GlobalPopup = {
        show: function(type, title, message, sound = true, duration = 0) {
            const overlay = document.getElementById('global-popup-overlay');
            const card = document.getElementById('global-popup-card');
            const icon = document.getElementById('pop-icon-wrapper');
            const titleEl = document.getElementById('pop-title');
            const msgEl = document.getElementById('pop-message');
            const btn = document.getElementById('pop-close-btn');
            const canvas = document.getElementById('pop-confetti-canvas');

            card.className = "w-[90%] max-w-[380px] bg-white rounded-[32px] overflow-hidden border border-slate-100 transform scale-95 transition-all duration-200 relative flex flex-col items-center p-6 text-center pop-glow-" + type;

            if (type === 'success') {
                icon.innerHTML = '✨';
                icon.className = 'w-16 h-16 bg-emerald-50 text-emerald-500 rounded-full flex items-center justify-center mb-4 text-3xl shadow-inner border border-emerald-100';
                btn.className = 'w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover shadow-md';
                btn.innerText = 'Awesome!';
                if (sound) this.playSuccessSound();
                this.triggerConfetti(canvas);
            } else if (type === 'warning') {
                icon.innerHTML = '⚠️';
                icon.className = 'w-16 h-16 bg-amber-50 text-amber-500 rounded-full flex items-center justify-center mb-4 text-3xl shadow-inner border border-amber-100';
                btn.className = 'w-full py-3.5 bg-gradient-to-r from-amber-400 to-orange-500 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover shadow-md';
                btn.innerText = 'Got It';
            } else {
                icon.innerHTML = '❌';
                icon.className = 'w-16 h-16 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mb-4 text-3xl shadow-inner border border-rose-100';
                btn.className = 'w-full py-3.5 bg-gradient-to-r from-rose-500 to-pink-650 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover shadow-md';
                btn.innerText = 'Try Again';
            }

            titleEl.innerText = title;
            msgEl.innerText = message;

            overlay.classList.remove('opacity-0', 'pointer-events-none');
            overlay.classList.add('opacity-100');
            setTimeout(() => {
                card.classList.remove('scale-90', 'opacity-0');
                card.classList.add('scale-100', 'opacity-100');
            }, 50);

            btn.onclick = () => this.close();

            if (duration > 0) {
                setTimeout(() => this.close(), duration);
            }
        },
        close: function() {
            const overlay = document.getElementById('global-popup-overlay');
            const card = document.getElementById('global-popup-card');
            card.classList.add('scale-90', 'opacity-0');
            overlay.classList.remove('opacity-100');
            overlay.classList.add('opacity-0', 'pointer-events-none');
        },
        playSuccessSound: function() {
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const now = ctx.currentTime;
                
                const o1 = ctx.createOscillator();
                const o2 = ctx.createOscillator();
                const g = ctx.createGain();

                o1.type = 'triangle';
                o2.type = 'sine';

                o1.frequency.setValueAtTime(523.25, now);
                o1.frequency.setValueAtTime(659.25, now + 0.1);
                o1.frequency.setValueAtTime(783.99, now + 0.2);
                o1.frequency.setValueAtTime(1046.50, now + 0.3);

                o2.frequency.setValueAtTime(1046.50, now);
                o2.frequency.setValueAtTime(1318.51, now + 0.15);

                g.gain.setValueAtTime(0.15, now);
                g.gain.exponentialRampToValueAtTime(0.01, now + 0.5);

                o1.connect(g);
                o2.connect(g);
                g.connect(ctx.destination);

                o1.start(now);
                o2.start(now);
                o1.stop(now + 0.5);
                o2.stop(now + 0.5);
            } catch(e){}
        },
        triggerConfetti: function(canvas) {
            canvas.style.opacity = '1';
            const ctx = canvas.getContext('2d');
            canvas.width = canvas.parentElement.offsetWidth;
            canvas.height = canvas.parentElement.offsetHeight;
            let particles = [];
            for (let i = 0; i < 45; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height - canvas.height,
                    r: Math.random() * 4 + 2,
                    color: ['#10b981', '#3b82f6', '#f59e0b', '#ec4899', '#8b5cf6'][Math.floor(Math.random() * 5)],
                    vy: Math.random() * 2 + 2,
                    vx: Math.random() * 2 - 1
                });
            }
            function draw() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                let alive = false;
                particles.forEach(p => {
                    p.y += p.vy;
                    p.x += p.vx;
                    if (p.y < canvas.height) alive = true;
                    ctx.beginPath();
                    ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                    ctx.fillStyle = p.color;
                    ctx.fill();
                });
                if (alive) {
                    requestAnimationFrame(draw);
                } else {
                    canvas.style.opacity = '0';
                }
            }
            draw();
        }
    };
    </script>

    @if(session()->has('popup_data'))
        @php $p = session('popup_data'); @endphp
        <script>
        document.addEventListener('DOMContentLoaded', () => {
            GlobalPopup.show(
                "{{ $p['type'] }}", 
                "{{ $p['title'] }}", 
                "{{ $p['message'] }}",
                true,
                {{ intval($p['auto_close'] ?? 0) }}
            );
        });
        </script>
    @endif

    @stack('scripts')
</body>
</html>