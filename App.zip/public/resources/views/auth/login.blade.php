<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>DX EARN - Access Portal</title>
    <script src="https://telegram.org/js/telegram-web-app.js"></script>
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { 
            -webkit-user-select: none; 
            user-select: none; 
            overflow: hidden;
            height: 100vh;
        }
        ::-webkit-scrollbar { display: none; }
        .bg-animate {
            background: linear-gradient(135deg, #fef08a 0%, #d9f99d 50%, #bae6fd 100%);
            background-size: 400% 400%;
            animation: flowBackground 10s ease infinite;
        }
        @keyframes flowBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .container-box {
            max-width: 440px;
            width: 100%;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            border-radius: 40px;
            box-shadow: 0 25px 55px rgba(0, 0, 0, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.7);
            padding: 2.5rem;
            animation: slideUp 0.4s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        @keyframes slideUp {
            0% { transform: translateY(30px); opacity: 0; }
            100% { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body class="bg-animate text-slate-800 font-sans flex justify-center items-center p-4">
    <div class="container-box relative flex flex-col items-center justify-center text-center">
        
        <div id="loader-overlay" class="hidden absolute inset-0 bg-white/95 rounded-[40px] z-50 flex flex-col items-center justify-center p-6">
            <div class="w-14 h-14 border-4 border-slate-100 border-t-blue-500 rounded-full animate-spin mb-4"></div>
            <h3 class="text-xl font-black text-slate-800 animate-pulse">Syncing Secure Node... ⚡</h3>
            <p class="text-xs text-slate-400 mt-2 font-semibold">Verifying cryptographic credential channels</p>
        </div>

        <div class="mb-6">
            <div class="w-20 h-20 bg-gradient-to-tr from-amber-400 via-pink-400 to-indigo-400 rounded-[28px] mx-auto flex items-center justify-center shadow-[0_12px_25px_rgba(99,102,241,0.2)] mb-4 border-4 border-white">
                <span class="text-4xl">⚡</span>
            </div>
            <h1 class="text-3xl font-black text-slate-900 tracking-tight">DX EARN</h1>
            <p class="text-[10px] text-indigo-655 font-black uppercase tracking-widest mt-1.5">Decentralized Cloud Mining Hub ✨</p>
        </div>

        @if(session('error'))
            <div class="bg-rose-50 text-rose-600 border border-rose-200/50 text-xs font-bold p-3.5 rounded-2xl flex items-center gap-2 mb-4 w-full">
                <span>⚠️</span> {{ session('error') }}
            </div>
        @endif

        <div class="space-y-4 w-full">
            <div class="bg-white/90 border border-slate-100 p-5 rounded-[24px] shadow-[0_6px_20px_rgba(0,0,0,0.01)] flex flex-col items-center justify-center gap-3">
                <div class="text-3xl">🚀</div>
                <h3 class="text-sm font-bold text-slate-800">Instant Web Login</h3>
                <p class="text-xs text-slate-500 leading-relaxed font-semibold">Authenticate securely in one-click with Google account to access your mining dashboard.</p>
                <div id="google-btn-wrapper" class="w-full flex justify-center py-2"></div>
            </div>
        </div>

        <div class="mt-6 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
            🔒 Secured by Google OAuth Protocol
        </div>
    </div>

    <script>
        function handleCredentialResponse(response) {
            const loader = document.getElementById('loader-overlay');
            loader.classList.remove('hidden');
            
            const formData = new FormData();
            formData.append('credential', response.credential);
            formData.append('_token', '{{ csrf_token() }}');
            
            fetch("{{ route('login.google') }}", {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    window.location.href = "{{ route('home') }}";
                } else {
                    loader.classList.add('hidden');
                    alert(data.message || 'Authentication failed.');
                }
            })
            .catch(err => {
                loader.classList.add('hidden');
                console.error('Google Sign-In Error:', err);
            });
        }

        window.onload = function () {
            google.accounts.id.initialize({
                client_id: "{{ get_setting_val('google_client_id') }}",
                callback: handleCredentialResponse
            });
            google.accounts.id.renderButton(
                document.getElementById("google-btn-wrapper"),
                { theme: "outline", size: "large", width: "260", shape: "pill" }
            );
            
            const webapp = window.Telegram?.WebApp;
            if (webapp) {
                webapp.ready();
                webapp.expand();
                const initData = webapp.initData;
                if (initData) {
                    const loader = document.getElementById('loader-overlay');
                    loader.classList.remove('hidden');
                    let referred_by = "{{ session('referred_by', '') }}";
                    if (webapp.initDataUnsafe?.start_param) {
                        referred_by = webapp.initDataUnsafe.start_param;
                    }
                    const formData = new FormData();
                    formData.append('initData', initData);
                    formData.append('referred_by', referred_by);
                    formData.append('_token', '{{ csrf_token() }}');
                    
                    fetch("{{ route('login.telegram') }}", {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success' || data.success) {
                            window.location.href = "{{ route('home') }}";
                        } else {
                            loader.classList.add('hidden');
                            alert(data.message || 'Telegram identification validation rejected.');
                        }
                    })
                    .catch(error => {
                        loader.classList.add('hidden');
                        console.error('Telegram signature check failed:', error);
                    });
                }
            }
        }
    </script>
</body>
</html>