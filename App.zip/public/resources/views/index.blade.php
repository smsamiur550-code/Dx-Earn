@extends('layouts.app')

@section('title', 'Home - DX EARN')

@section('content')
<!-- Header User Profile & Alerts -->
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <div class="flex items-center gap-3">
        <div class="w-10 h-10 rounded-full border border-slate-200 p-0.5 shadow-sm bg-white">
            <img src="{{ get_avatar_url($user->profile_pic) }}" class="w-full h-full rounded-full object-cover">
        </div>
        <div>
            <h4 class="text-xs font-black text-slate-900">{{ format_username($user->username) }}</h4>
            <div class="flex items-center gap-1 mt-0.5">
               {!! get_kyc_badge($user->kyc_status) !!}
            </div>
        </div>
    </div>
    <div class="flex items-center gap-2">
        <a href="{{ route('notifications') }}" class="w-9 h-9 rounded-full bg-slate-50 flex items-center justify-center text-slate-600 shadow-sm relative active:scale-95 transition-transform text-base border border-slate-200 bouncy-hover">
            🔔
            @if ($hasUnreadNotifications)
                <span class="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping"></span>
                <span class="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full"></span>
            @endif
        </a>
        <a href="{{ route('support') }}" class="w-9 h-9 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 shadow-sm relative active:scale-95 transition-transform border border-blue-100 text-base bouncy-hover">
            📞
            @if ($hasUnreadChats)
                <span class="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full animate-ping"></span>
                <span class="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full"></span>
            @endif
        </a>
    </div>
</div>

<div class="p-4 space-y-4">
    <!-- Combined Wallet Card -->
    <a href="{{ route('wallet') }}" class="block bg-gradient-to-tr from-blue-600 via-indigo-650 to-purple-600 p-5 rounded-[2rem] text-white shadow-md relative overflow-hidden bouncy-hover duration-150">
        <div class="relative z-10 space-y-3">
            <div class="flex justify-between items-center border-b border-white/10 pb-1.5">
                <span class="text-[9px] font-black uppercase tracking-widest text-slate-100">My Decentralized Wallet 💳</span>
                <span class="text-[8px] bg-white/20 text-white font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider">Managed Node</span>
            </div>
            
            <div class="grid grid-cols-2 gap-x-4 gap-y-2.5 text-left">
                <div>
                    <span class="text-[8px] font-black text-white/70 uppercase tracking-wider block">DX Coins ⛏️</span>
                    <span class="text-xs font-black block mt-0.5">{{ number_format($user->balance_coin, 2) }} DX Coin</span>
                </div>
                <div>
                    <span class="text-[8px] font-black text-white/70 uppercase tracking-wider block">Referral Balance 🤝</span>
                    <span class="text-xs font-black block mt-0.5">{{ number_format($user->balance_referral_dollar * $takaRate, 2) }} ৳</span>
                </div>
                <div>
                    <span class="text-[8px] font-black text-white/70 uppercase tracking-wider block">DX Tokens 🟡</span>
                    <span class="text-xs font-black block mt-0.5">{{ number_format($user->balance_token, 2) }} DX Token</span>
                </div>
                <div>
                    <span class="text-[8px] font-black text-white/70 uppercase tracking-wider block">Main Balance 💳</span>
                    <span class="text-xs font-black block mt-0.5">{{ number_format($user->balance_dollar * $takaRate, 2) }} ৳</span>
                </div>
            </div>
        </div>
        <div class="absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-md"></div>
    </a>

    <!-- Carousel Slider -->
    <div class="relative w-full h-32 rounded-3xl overflow-hidden shadow-sm border border-slate-100 bg-white">
        <div class="absolute bottom-3 left-0 right-0 flex justify-center gap-1.5 z-20" id="sliderDots"></div>
        <div class="w-full h-full relative" id="sliderContainer">
            @foreach($sliders as $index => $slide)
                @php $targetUrl = !empty($slide->redirect_url) ? $slide->redirect_url : '#'; @endphp
                <a href="{{ $targetUrl }}" class="slide-item absolute inset-0 w-full h-full {{ $index === 0 ? 'block' : 'hidden' }}" id="slide-{{ $index }}">
                    @if(!empty($slide->image_path))
                        <img src="{{ asset($slide->image_path) }}" class="w-full h-full object-cover">
                    @else
                        <div class="w-full h-full bg-gradient-to-tr {{ $slide->grad ?? 'from-indigo-400 to-indigo-650' }} p-4 flex flex-col justify-center text-white">
                            <div class="relative z-10 space-y-1">
                                <h3 class="text-xs font-black uppercase tracking-wider text-yellow-300">{{ $slide->title }}</h3>
                                <p class="text-[10px] text-white/95 font-semibold leading-relaxed max-w-[85%]">{{ $slide->desc_text ?? $slide->desc }}</p>
                            </div>
                            <div class="absolute -right-6 -bottom-6 w-24 h-24 bg-white/10 rounded-full blur-md"></div>
                        </div>
                    @endif
                </a>
            @endforeach
        </div>
    </div>

    <!-- Grid Menu Buttons (4x2 Layout) -->
    <div class="grid grid-cols-4 gap-3 p-4 rounded-[2.5rem] bg-white border border-slate-100 shadow-sm">
        <a href="{{ route('reward') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                🎁
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Reward</span>
        </a>
        <a href="{{ route('gift') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                💝
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Gift</span>
        </a>
        <a href="{{ route('vip') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                👑
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">VIP</span>
        </a>
        <a href="{{ route('lottery') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                🎫
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Lottery</span>
        </a>
        <a href="{{ route('shop') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                🛍️
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Shop</span>
        </a>
        <a href="{{ route('convert') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                🔄
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Convert</span>
        </a>
        <a href="{{ route('withdraw') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                💵
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Withdraw</span>
        </a>
        <!-- Leader Button redirected to actual leaderboard now -->
        <a href="{{ route('leaderboard') }}" class="flex flex-col items-center justify-center p-2 gap-1 bouncy-hover">
            <div class="w-10 h-10 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-700 border border-slate-100 shadow-inner text-lg">
                🏆
            </div>
            <span class="text-[9px] font-black text-slate-700 uppercase tracking-wide text-center">Leader</span>
        </a>
    </div>

    <!-- Live Market Widget -->
    <div class="bg-white p-4 rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div class="flex justify-between items-center mb-3">
            <div class="flex items-center gap-1.5">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <h3 class="text-[10px] font-black text-slate-800 uppercase tracking-wider">Live Market Graph</h3>
            </div>
            <span class="text-[8px] bg-slate-50 text-slate-500 font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider border border-slate-100">Realtime</span>
        </div>
        <div class="w-full h-40 rounded-2xl overflow-hidden border border-slate-100">
            <iframe src="{{ $liveMarketLink }}" 
                    class="w-full h-full" 
                    style="border: none;"
                    scrolling="no">
            </iframe>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const slides = document.querySelectorAll('.slide-item');
        const dotsContainer = document.getElementById('sliderDots');
        let currentSlide = 0;

        if (slides.length > 0 && dotsContainer) {
            slides.forEach((_, idx) => {
                const dot = document.createElement('span');
                dot.className = `w-1.5 h-1.5 rounded-full transition-all duration-300 ${idx === 0 ? 'bg-white w-4' : 'bg-white/40'}`;
                dot.id = `slider-dot-${idx}`;
                dotsContainer.appendChild(dot);
            });

            function rotateSlides() {
                slides[currentSlide].classList.add('hidden');
                let dotOld = document.getElementById(`slider-dot-${currentSlide}`);
                if (dotOld) {
                    dotOld.className = 'w-1.5 h-1.5 rounded-full bg-white/40 transition-all duration-300';
                }

                currentSlide = (currentSlide + 1) % slides.length;
                
                slides[currentSlide].classList.remove('hidden');
                let dotNew = document.getElementById(`slider-dot-${currentSlide}`);
                if (dotNew) {
                    dotNew.className = 'w-4 h-1.5 rounded-full bg-white transition-all duration-300';
                }
            }

            setInterval(rotateSlides, 4000);
        }
    });
</script>
@endpush