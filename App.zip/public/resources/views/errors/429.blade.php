<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Slow Down! - 429 Too Many Requests</title>
</head>
<body style="margin: 0; padding: 0;">
    <div style='display:flex; justify-content:center; align-items:center; min-height:100vh; background:#f8fafc; font-family:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; text-align:center; padding: 20px; box-sizing: border-box;'>
        <div style='background:white; padding:40px 30px; border-radius:32px; box-shadow:0 15px 35px rgba(0,0,0,0.03); max-width:380px; border:1px solid #e2e8f0; animation: popUp 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);'>
            <div style='font-size:56px; margin-bottom:15px; animation: bounceSoft 2s infinite;'>⚠️</div>
            <h2 style='color:#ef4444; margin:0 0 10px; font-weight:900; font-size:24px; letter-spacing:-0.5px;'>SLOW DOWN!</h2>
            <p style='color:#64748b; font-size:13px; line-height:1.6; font-weight:600; margin: 0;'>You are sending requests too quickly. Please pause for a moment and try again shortly. 🚀</p>
        </div>
    </div>
    <style>
        @keyframes popUp {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        @keyframes bounceSoft {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-6px); }
        }
    </style>
</body>
</html>