@extends('layouts.app')

@section('title', 'Emoji Match - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Emoji Match 🎭</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Matches Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Moves Count</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="moves-label">0</p>
        </div>
    </div>

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center space-y-6">
        <div class="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-center shadow-inner relative">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-4">Flip & Match the Pairs</span>
            
            <div id="game-controls-wrapper" class="w-full">
                @if ($isSessionLocked)
                    <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                        Unlock 🔓 (Watch Ad)
                    </button>
                @else
                    <div class="grid-container" id="grid">
                    </div>
                @endif
            </div>
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Match History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Emoji Match</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No matching events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .grid-container { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; max-width: 320px; margin: 20px auto; }
    .card-tile {
        height: 70px;
        background: #ffffff;
        border-radius: 1.25rem;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        cursor: pointer;
        box-shadow: 0 4px 10px rgba(0,0,0,0.03), inset 0 -4px 0 #f1f5f9;
        border: 2px solid rgba(226, 232, 240, 0.8);
        transition: transform 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        will-change: transform;
    }
    @keyframes cardPop {
        0% { transform: scale(1); }
        50% { transform: scale(1.15) rotate(6deg); }
        100% { transform: scale(1) rotate(0deg); }
    }
    .card-pop {
        animation: cardPop 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
    }
    .card-tile.flipped { background: #eff6ff; border-color: #2563eb; transform: scale(1.05); }
    .card-tile.matched { background: #ecfdf5; border-color: #10b981; cursor: default; }
</style>
@endpush

@push('scripts')
<script>
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    let emojis = ['🦁', '🦊', '🐯', '🐱', '🐼', '🐨', '🦁', '🦊', '🐯', '🐱', '🐼', '🐨'];
    let shuffledEmojis = [];
    let flippedCards = [];
    let matchedPairsCount = 0;
    let movesCount = 0;
    let inputActive = true;

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    function shuffleEmojis() {
        shuffledEmojis = [...emojis];
        for (let i = shuffledEmojis.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffledEmojis[i], shuffledEmojis[j]] = [shuffledEmojis[j], shuffledEmojis[i]];
        }
    }

    function renderBoard() {
        const grid = document.getElementById('grid');
        if (!grid) return;
        shuffleEmojis();
        grid.innerHTML = '';
        shuffledEmojis.forEach((emoji, idx) => {
            const tile = document.createElement('div');
            tile.className = 'card-tile';
            tile.dataset.emoji = emoji;
            tile.dataset.index = idx;
            tile.innerHTML = '❓';
            tile.onclick = () => selectTile(tile);
            grid.appendChild(tile);
        });
    }

    function selectTile(tile) {
        if (!inputActive || flippedCards.includes(tile) || tile.classList.contains('matched')) return;

        tile.classList.add('flipped', 'card-pop');
        tile.innerHTML = tile.dataset.emoji;
        flippedCards.push(tile);

        triggerVibration('light');

        if (flippedCards.length === 2) {
            inputActive = false;
            movesCount++;
            const labelEl = document.getElementById('moves-label');
            if (labelEl) labelEl.innerText = movesCount;

            const [t1, t2] = flippedCards;
            if (t1.dataset.emoji === t2.dataset.emoji) {
                t1.classList.remove('flipped');
                t2.classList.remove('flipped');
                t1.classList.add('matched');
                t2.classList.add('matched');
                matchedPairsCount++;
                flippedCards = [];
                inputActive = true;

                if (matchedPairsCount === 6) {
                    claimVictory();
                }
            } else {
                setTimeout(() => {
                    t1.classList.remove('flipped', 'card-pop');
                    t2.classList.remove('flipped', 'card-pop');
                    t1.innerHTML = '❓';
                    t2.innerHTML = '❓';
                    flippedCards = [];
                    inputActive = true;
                }, 1000);
            }
        }
    }

    function claimVictory() {
        const fd = new FormData();
        fd.append('action', 'claim_victory');
        fd.append('moves', movesCount);
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.emoji') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (window.GlobalPopup) {
                    GlobalPopup.show('success', 'Pairs Matched!', `You solved the match-board in ${movesCount} moves! claimed 🪙 {{ number_format(get_setting_val('emoji_reward') ?: 20, 2) }}! 🎉`, true);
                } else {
                    alert(`You solved the match-board in ${movesCount} moves! Claimed 🪙 {{ number_format(get_setting_val('emoji_reward') ?: 20, 2) }}!`);
                }
                setTimeout(() => { window.location.reload(); }, 1800);
            } else {
                alert(data.message);
                window.location.reload();
            }
        });
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.emoji') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.emoji') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }

    renderBoard();
</script>
@endpush