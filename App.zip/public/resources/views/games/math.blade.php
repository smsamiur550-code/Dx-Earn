@extends('layouts.app')

@section('title', 'Math Solver - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Math Solver 🧮</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Solves Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Next Refill</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="refill-timer">--:--:--</p>
        </div>
    </div>

    @php
        // Purely local mathematical dynamic equation seed generator
        $num1 = mt_rand(1, 25);
        $num2 = mt_rand(1, 25);
        $operators = ['+', '-', '*'];
        $op = $operators[array_rand($operators)];
        
        if ($op === '+') {
            $answer = $num1 + $num2;
        } elseif ($op === '-') {
            $answer = $num1 - $num2;
        } else {
            $answer = $num1 * $num2;
        }
        
        session(['math_equation' => "$num1 $op $num2", 'math_answer' => $answer]);
    @endphp

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center space-y-6 bg-equations">
        <div class="math-symbol" style="left: 10%; top: 20%; animation-delay: 0s;">+</div>
        <div class="math-symbol" style="right: 15%; top: 40%; animation-delay: 2s;">-</div>
        <div class="math-symbol" style="left: 20%; bottom: 15%; animation-delay: 4s;">*</div>
        <div class="math-symbol" style="right: 25%; bottom: 30%; animation-delay: 1s;">=</div>

        <div class="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center shadow-inner relative z-10">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-2">Solve this Equation</span>
            <h2 class="text-4xl font-black text-slate-800 tracking-tight" id="equation-display">{{ session('math_equation') }} = ?</h2>
        </div>

        <div id="game-controls-wrapper" class="w-full space-y-4 relative z-10">
            @if ($isSessionLocked)
                <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                    Unlock 🔓 (Watch Ad)
                </button>
            @else
                <div class="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between shadow-inner focus-within:ring-2 focus-within:ring-blue-500/10 transition-all duration-200">
                    <input type="number" id="answer-input" placeholder="Your Answer" class="bg-transparent text-sm font-black text-slate-800 w-full outline-none text-center">
                </div>
                <button id="submitBtn" onclick="submitAnswer()" {{ ($isLimitReached && $remainingTime > 0) ? 'disabled' : '' }} class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 disabled:from-slate-100 disabled:to-slate-100 disabled:text-slate-400 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-blue">
                    {{ ($isLimitReached && $remainingTime > 0) ? 'REFILLING AT MIDNIGHT' : 'Submit Answer ⚡' }}
                </button>
            @endif
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Solver History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Math Solver</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No solver events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .bg-equations { position: relative; overflow: hidden; }
    .math-symbol {
        position: absolute;
        font-size: 14px;
        font-weight: 900;
        color: rgba(99, 102, 241, 0.08);
        pointer-events: none;
        user-select: none;
        animation: floatSlow 8s linear infinite;
    }
    @keyframes floatSlow {
        0% { transform: translateY(110%) rotate(0deg); opacity: 0; }
        10% { opacity: 1; }
        90% { opacity: 1; }
        100% { transform: translateY(-10%) rotate(360deg); opacity: 0; }
    }
</style>
@endpush

@push('scripts')
<script>
    const timerEl = document.getElementById('refill-timer');
    let timeLeft = {{ $remainingTime }};
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    function updateTimer() {
        if (timeLeft <= 0) {
            if (timerEl) timerEl.innerText = "READY";
            return;
        }
        let h = Math.floor(timeLeft / 3600);
        let m = Math.floor((timeLeft % 3600) / 60);
        let s = timeLeft % 60;
        if (timerEl) timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
        timeLeft--;
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    function submitAnswer() {
        const ansInput = document.getElementById('answer-input');
        const ansValue = ansInput ? ansInput.value.trim() : "";
        if (ansValue === "") {
            alert("Please input an answer first!");
            return;
        }

        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerText = "VERIFYING...";
        }

        const fd = new FormData();
        fd.append('action', 'submit_answer');
        fd.append('user_answer', ansValue);
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.math') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (data.correct) {
                    if (window.GlobalPopup) {
                        GlobalPopup.show('success', 'Correct Answer!', `Brilliant math skills! You claimed 🪙 {{ number_format(get_setting_val('math_reward') ?: 10, 2) }}! 🎉`, true);
                    } else {
                        alert(`Correct Answer! You claimed 🪙 {{ number_format(get_setting_val('math_reward') ?: 10, 2) }}!`);
                    }
                    setTimeout(() => { window.location.reload(); }, 1500);
                } else {
                    alert(data.message);
                    window.location.reload();
                }
            } else {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.innerText = "Submit Answer ⚡";
                }
                alert(data.message || 'System Error!');
            }
        })
        .catch(err => {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerText = "Submit Answer ⚡";
            }
            console.error(err);
        });
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.math') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.math') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush