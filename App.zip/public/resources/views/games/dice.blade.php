@extends('layouts.app')

@section('title', 'Dice Master - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Dice Master 🎲</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-header">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Rolls Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Next Refill</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="refill-timer">--:--:--</p>
        </div>
    </div>

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center">
        <p id="status-text" class="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Roll for Fortune</p>
        <h2 class="text-4xl font-black text-slate-800 tracking-tight" id="reward-display">🪙 0.00</h2>
        <p class="text-[9px] text-blue-600 font-bold mt-2 uppercase tracking-wide">1 point = 🪙 {{ number_format(get_setting_val('dice_point_value') ?: 10.00, 2) }}</p>

        <div class="dice-container">
            <div id="dice1" class="dice"><i class="fa-solid fa-dice-one"></i></div>
            <div id="dice2" class="dice"><i class="fa-solid fa-dice-one"></i></div>
        </div>

        <div id="game-controls-wrapper" class="w-full">
            @if ($isSessionLocked)
                <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                    Unlock 🔓 (Watch Ad)
                </button>
            @else
                <button type="button" id="rollBtn" onclick="rollDices()" {{ ($isLimitReached && $remainingTime > 0) ? 'disabled' : '' }} 
                    class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 disabled:from-slate-100 disabled:to-slate-100 text-white disabled:text-slate-400 rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-blue">
                    {{ ($isLimitReached && $remainingTime > 0) ? 'REFILLING AT MIDNIGHT' : 'Roll Dices 🎲' }}
                </button>
            @endif
        </div>

        <div class="mt-4 p-3 bg-amber-50 rounded-xl border border-amber-100 shadow-inner">
            <p class="text-[9px] text-amber-600 font-bold leading-relaxed text-center">
                ⭐ Score duplicate dice faces (e.g. 3:3, 5:5) to claim double point jackpots!
            </p>
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Roll History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Dice Game</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No roll events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .dice-container { perspective: 1000px; display: flex; gap: 20px; justify-content: center; margin: 30px 0; }
    .dice { 
        width: 75px; height: 75px; background: #ffffff; border-radius: 1.5rem; 
        box-shadow: 0 8px 20px rgba(0,0,0,0.02), inset 0 -5px 0 #f1f5f9;
        display: flex; align-items: center; justify-content: center;
        font-size: 2.2rem; color: #2563eb; transition: all 0.3s;
        border: 1px solid rgba(226, 232, 240, 0.8);
        will-change: transform;
        transform: translate3d(0,0,0);
    }
    @keyframes advanced-roll {
        0% { transform: translate3d(0,0,0) rotateX(0deg) rotateY(0deg) rotateZ(0deg) scale(1); }
        15% { transform: translate3d(0,0,0) rotateX(120deg) rotateY(45deg) rotateZ(90deg) scale(1.1); }
        30% { transform: translate3d(0,0,0) rotateX(240deg) rotateY(180deg) rotateZ(180deg) scale(0.9); }
        45% { transform: translate3d(0,0,0) rotateX(360deg) rotateY(270deg) rotateZ(360deg) scale(1.15); }
        60% { transform: translate3d(0,0,0) rotateX(480deg) rotateY(360deg) rotateZ(450deg) scale(0.95); }
        75% { transform: translate3d(0,0,0) rotateX(600deg) rotateY(420deg) rotateZ(540deg) scale(1.05); }
        90% { transform: translate3d(0,0,0) rotateX(680deg) rotateY(480deg) rotateZ(630deg) scale(0.98); }
        100% { transform: translate3d(0,0,0) rotateX(720deg) rotateY(540deg) rotateZ(720deg) scale(1); }
    }
    .rolling { 
        animation: advanced-roll 1.5s cubic-bezier(0.25, 1, 0.5, 1) infinite; 
    }
    @keyframes bounce-stop {
        0% { transform: translate3d(0,0,0) scale(0.5) rotate(15deg); }
        70% { transform: translate3d(0,0,0) scale(1.2) rotate(-10deg); }
        90% { transform: translate3d(0,0,0) scale(0.95) rotate(3deg); }
        100% { transform: translate3d(0,0,0) scale(1) rotate(0deg); }
    }
    .bouncing {
        animation: bounce-stop 0.6s cubic-bezier(0.25, 1, 0.5, 1);
    }
    .double-glow { 
        box-shadow: 0 0 20px rgba(245, 158, 11, 0.15); 
        border: 2px solid #f59e0b; 
        color: #f59e0b; 
    }
</style>
@endpush

@push('scripts')
<script>
    let timeLeft = {{ $remainingTime }};
    let hardLockRemaining = {{ $hardLockRemaining }};
    const timerEl = document.getElementById('refill-timer');
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    function updateTimer() {
        if (timeLeft <= 0) {
            if (timerEl) timerEl.innerText = "READY";
            return;
        }
        let h = Math.floor(timeLeft / 3600);
        let m = Math.floor((timeLeft % 3600) / 60);
        let s = timeLeft % 60;
        if (timerEl) timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
        timeLeft--;
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    const diceIconMap = ['', 'fa-dice-one', 'fa-dice-two', 'fa-dice-three', 'fa-dice-four', 'fa-dice-five', 'fa-dice-six'];
    let inProgress = false;

    function rollDices() {
        if (inProgress) return;
        inProgress = true;

        const d1 = document.getElementById('dice1');
        const d2 = document.getElementById('dice2');
        const rollBtn = document.getElementById('rollBtn');
        const rewardDisp = document.getElementById('reward-display');
        const statusTxt = document.getElementById('status-text');
        const balHeader = document.getElementById('balance-header');
        const playsCount = document.getElementById('plays-count');

        if (rollBtn) {
            rollBtn.disabled = true;
            rollBtn.innerText = "ROLLING...";
        }
        d1.className = "dice";
        d2.className = "dice";
        d1.classList.add('rolling');
        d2.classList.add('rolling');
        statusTxt.className = "text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1";
        statusTxt.innerText = "ROLLING...";

        const fd = new FormData();
        fd.append('action', 'claim_dice');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.dice') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                setTimeout(() => {
                    d1.classList.remove('rolling');
                    d2.classList.remove('rolling');
                    
                    d1.classList.add('bouncing');
                    d2.classList.add('bouncing');

                    d1.innerHTML = `<i class="fa-solid ${diceIconMap[data.dice1]}"></i>`;
                    d2.innerHTML = `<i class="fa-solid ${diceIconMap[data.dice2]}"></i>`;

                    if (data.is_double) {
                        d1.classList.add('double-glow');
                        d2.classList.add('double-glow');
                        statusTxt.innerText = "DOUBLE JACKPOT HIT! 🎉";
                        statusTxt.className = "text-[9px] font-black text-amber-500 uppercase tracking-widest mb-1";
                    } else {
                        statusTxt.innerText = "ROLL COMPLETED ✨";
                    }

                    rewardDisp.innerText = '🪙 ' + data.earned.toFixed(2);
                    rewardDisp.classList.add('text-emerald-600', 'scale-105');

                    balHeader.innerText = `🪙 ${data.new_balance}`;
                    playsCount.innerText = `${data.plays_today} / {{ $finalLimit }}`;

                    setTimeout(() => {
                        if (window.GlobalPopup) {
                            GlobalPopup.show('success', 'Dice Roll Victory!', `You rolled ${data.dice1}:${data.dice2} and won 🪙 ${data.earned.toFixed(2)}! 🎉`, true);
                        } else {
                            alert(`You rolled ${data.dice1}:${data.dice2} and won 🪙 ${data.earned.toFixed(2)}!`);
                        }
                        
                        d1.classList.remove('bouncing');
                        d2.classList.remove('bouncing');
                        rewardDisp.classList.remove('text-emerald-600', 'scale-105');
                        inProgress = false;
                        
                        if (data.session_locked) {
                            window.location.reload();
                        } else if (data.limit_reached) {
                            rollBtn.disabled = true;
                            rollBtn.innerText = "REFILLING AT MIDNIGHT";
                            timeLeft = data.remaining_time;
                            updateTimer();
                        } else {
                            rollBtn.disabled = false;
                            rollBtn.innerText = "Roll Dices 🎲";
                        }
                    }, 1200);

                }, 1800);
            } else {
                inProgress = false;
                rollBtn.disabled = false;
                rollBtn.innerText = "Roll Dices 🎲";
                d1.classList.remove('rolling');
                d2.classList.remove('rolling');
                alert(data.message || 'System Error!');
            }
        })
        .catch(err => {
            inProgress = false;
            if (rollBtn) {
                rollBtn.disabled = false;
                rollBtn.innerText = "Roll Dices 🎲";
            }
            d1.classList.remove('rolling');
            d2.classList.remove('rolling');
            console.error("Transmission error: ", err);
        });
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.dice') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.dice') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush