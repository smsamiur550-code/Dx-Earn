@extends('layouts.app')

@section('title', 'Scratch Hub - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Scratch Lotto 🎫</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Tickets Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Next Refill</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="refill-timer">--:--:--</p>
        </div>
    </div>

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center space-y-6">
        <div class="canvas-area">
            <div class="prize-holder">
                <span class="text-[8px] text-slate-400 font-extrabold uppercase tracking-widest block" id="outcome-title">Outcome</span>
                <span class="text-2xl font-black text-slate-400 animate-pulse mt-1" id="prize-text">❓ Locked</span>
            </div>
            <canvas id="scratchCanvas" class="hidden"></canvas>
        </div>

        <div class="space-y-1">
            <h3 class="text-sm font-black text-slate-900 uppercase tracking-wide">Interactive Scratch Card</h3>
            <p class="text-[10px] text-emerald-500 font-extrabold uppercase tracking-wider">✨ Guaranteed Wins • 100% Free</p>
        </div>

        <div id="game-controls-wrapper" class="w-full">
            @if ($isSessionLocked)
                <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                    Unlock 🔓 (Watch Ad)
                </button>
            @else
                <button id="buyBtn" onclick="buyCard()" {{ ($isLimitReached && $remainingTime > 0) ? 'disabled' : '' }} class="w-full py-4 color-shifting-btn bg-gradient-to-r from-rose-500 via-pink-500 to-rose-600 disabled:from-slate-100 disabled:to-slate-100 text-white disabled:text-slate-400 rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-rose">
                    {{ ($isLimitReached && $remainingTime > 0) ? 'REFILLING AT MIDNIGHT' : 'Claim Free Scratch Card 🎫' }}
                </button>
            @endif
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Scratch History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Scratch Card</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No scratch events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .canvas-area {
        position: relative;
        width: 280px;
        height: 160px;
        margin: 0 auto;
        border-radius: 1.5rem;
        overflow: hidden;
        box-shadow: inset 0 2px 8px rgba(0,0,0,0.02);
        background: #f8fafc;
        border: 2px solid rgba(226, 232, 240, 0.8);
        will-change: transform;
        transform: translate3d(0,0,0);
    }
    .prize-holder {
        position: absolute;
        inset: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 5;
    }
    #scratchCanvas {
        position: absolute;
        inset: 0;
        z-index: 10;
        cursor: pointer;
        will-change: transform;
        transform: translate3d(0,0,0);
    }
    .btn-glow-rose {
        box-shadow: 0 4px 14px rgba(244, 63, 94, 0.35);
    }
</style>
@endpush

@push('scripts')
<script>
    const canvas = document.getElementById('scratchCanvas');
    const ctx = canvas ? canvas.getContext('2d') : null;
    const buyBtn = document.getElementById('buyBtn');
    const prizeText = document.getElementById('prize-text');
    const outcomeTitle = document.getElementById('outcome-title');
    const balHeader = document.getElementById('balance-display');
    const playsCount = document.getElementById('plays-count');
    const timerEl = document.getElementById('refill-timer');

    let isDrawing = false;
    let cardReady = false;
    let serverData = null;

    let timeLeft = {{ $remainingTime }};
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    function updateTimer() {
        if (timeLeft <= 0) {
            if (timerEl) timerEl.innerText = "READY";
            return;
        }
        let h = Math.floor(timeLeft / 3600);
        let m = Math.floor((timeLeft % 3600) / 60);
        let s = timeLeft % 60;
        if (timerEl) timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
        timeLeft--;
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    function buyCard() {
        if (cardReady) return;
        if (buyBtn) {
            buyBtn.disabled = true;
            buyBtn.innerText = "GENERATING TICKET...";
        }

        const fd = new FormData();
        fd.append('action', 'scratch');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.scratch') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                serverData = data;
                
                prizeText.innerText = "SWIPE SCREEN TO REVEAL";
                prizeText.className = "text-xs font-black text-slate-500 animate-pulse mt-1";
                
                canvas.classList.remove('hidden');
                canvas.width = 280;
                canvas.height = 160;

                ctx.fillStyle = '#cbd5e1'; 
                ctx.fillRect(0,0, canvas.width, canvas.height);
                
                ctx.fillStyle = '#475569';
                ctx.font = 'bold 9px sans-serif';
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.fillText('⚡ SWIPE TO REVEAL SECRETS ⚡', canvas.width/2, canvas.height/2 + 3);

                cardReady = true;
                if (buyBtn) buyBtn.innerText = "SWIPE THE COVER ABOVE";
            } else {
                if (buyBtn) {
                    buyBtn.disabled = false;
                    buyBtn.innerText = "Claim Free Scratch Card 🎫";
                }
                alert(data.message || 'System Error!');
            }
        })
        .catch(err => {
            if (buyBtn) {
                buyBtn.disabled = false;
                buyBtn.innerText = "Claim Free Scratch Card 🎫";
            }
            console.error(err);
        });
    }

    function scratch(e) {
        if (e.touches) {
            e.preventDefault(); 
        }
        if (!cardReady || !isDrawing || !ctx) return;
        const rect = canvas.getBoundingClientRect();
        
        let x, y;
        if (e.touches && e.touches.length > 0) {
            x = e.touches[0].clientX - rect.left;
            y = e.touches[0].clientY - rect.top;
        } else {
            x = e.clientX - rect.left;
            y = e.clientY - rect.top;
        }

        ctx.globalCompositeOperation = 'destination-out';
        ctx.beginPath();
        ctx.arc(x, y, 18, 0, Math.PI * 2);
        ctx.fill();

        checkClearedPercentage();
    }

    function checkClearedPercentage() {
        const imgData = ctx.getImageData(0,0, canvas.width, canvas.height);
        const totalPixels = imgData.data.length / 4;
        let clearedCount = 0;

        for (let i = 3; i < imgData.data.length; i += 4) {
            if (imgData.data[i] === 0) clearedCount++;
        }

        const pct = (clearedCount / totalPixels) * 100;
        if (pct >= 50) { 
            cardReady = false;
            canvas.classList.add('hidden'); 
            
            prizeText.innerText = serverData.label;
            prizeText.className = "text-2xl font-black text-emerald-600 scale-105 transition-all mt-1";
            outcomeTitle.innerText = "🎉 REVEALED PRIZE CLAIMED!";
            outcomeTitle.className = "text-[8px] font-black text-emerald-600 uppercase tracking-widest block";

            if (window.GlobalPopup) {
                GlobalPopup.show('success', 'Scratch Victory!', `You scratched and won ${serverData.label}! 🎉`, true);
            } else {
                alert(`You won ${serverData.label}!`);
            }
            
            balHeader.innerText = `🪙 ${serverData.new_balance}`;
            playsCount.innerText = `${serverData.plays_today} / {{ $finalLimit }}`;
            
            if (serverData.session_locked) {
                window.location.reload();
            } else if (serverData.limit_reached) {
                if (buyBtn) {
                    buyBtn.disabled = true;
                    buyBtn.innerText = "REFILLING AT MIDNIGHT";
                }
                timeLeft = serverData.remaining_time;
                updateTimer();
            } else {
                if (buyBtn) {
                    buyBtn.disabled = false;
                    buyBtn.innerText = "Claim Free Scratch Card 🎫";
                }
            }
        }
    }

    if (canvas) {
        canvas.addEventListener('mousedown', () => isDrawing = true);
        canvas.addEventListener('touchstart', (e) => {
            isDrawing = true;
            scratch(e);
        });
        window.addEventListener('mouseup', () => isDrawing = false);
        window.addEventListener('touchend', () => isDrawing = false);
        canvas.addEventListener('mousemove', scratch);
        canvas.addEventListener('touchmove', scratch);
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.scratch') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.scratch') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush