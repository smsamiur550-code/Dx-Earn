@extends('layouts.app')

@section('title', 'DX PlayZone - DX EARN')

@section('content')
<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('home') }}" class="text-slate-400 active:scale-90 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">DX PlayZone 🎮</h1>
    <div class="px-3 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<div class="p-4 space-y-4">
    <!-- PlayZone Banner -->
    <div class="bg-gradient-to-tr from-blue-600 to-indigo-650 p-6 rounded-[2rem] text-white shadow-md relative overflow-hidden">
        <div class="relative z-10 space-y-2 text-left">
            <span class="text-[9px] bg-white/20 px-2.5 py-1 rounded-full text-white font-extrabold uppercase tracking-widest inline-block">Instant Coin Drops ✨</span>
            <h2 class="text-xl font-black uppercase tracking-wide">Play & Earn Center</h2>
            <p class="text-[11px] text-white/95 leading-relaxed font-semibold">Unlock daily multiplier stacks by engaging in our premium interactive games. Complete streak quests to double payouts!</p>
        </div>
        <i class="fa-solid fa-gamepad absolute -right-6 -bottom-6 text-[10rem] opacity-10"></i>
    </div>

    <!-- Games Grid -->
    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-700 uppercase tracking-wider pl-1 text-left">Mini Games Arena 🎰</h3>
        <div class="grid grid-cols-2 gap-3.5">
            @php
                $gamesList = [
                    [
                        'name' => 'Lucky Spin',
                        'icon' => '🎡',
                        'link' => route('games.spin'),
                        'desc' => 'Spin the wheel of fortune to win multipliers.',
                        'gradient' => 'from-amber-400 via-orange-400 to-amber-500',
                        'shadow' => 'shadow-orange-500/10',
                        'badge' => 'SPIN 🎡'
                    ],
                    [
                        'name' => 'Dice Roll',
                        'icon' => '🎲',
                        'link' => route('games.dice'),
                        'desc' => 'Predict dice outcome & roll for multipliers.',
                        'gradient' => 'from-blue-400 via-indigo-400 to-purple-500',
                        'shadow' => 'shadow-indigo-500/10',
                        'badge' => 'ROLL 🎲'
                    ],
                    [
                        'name' => 'Scratch Card',
                        'icon' => '🎫',
                        'link' => route('games.scratch'),
                        'desc' => 'Scratch premium cards for instant coin prizes.',
                        'gradient' => 'from-rose-400 via-pink-400 to-rose-500',
                        'shadow' => 'shadow-rose-500/10',
                        'badge' => 'SCRATCH 🎫'
                    ],
                    [
                        'name' => 'Treasure Box',
                        'icon' => '🏴‍☠️',
                        'link' => route('games.treasure'),
                        'desc' => 'Unlock legendary boxes for hidden multipliers.',
                        'gradient' => 'from-emerald-400 via-teal-400 to-cyan-500',
                        'shadow' => 'shadow-emerald-500/10',
                        'badge' => 'MYSTERY 🏴‍☠️'
                    ],
                    [
                        'name' => 'Math Solving',
                        'icon' => '🧮',
                        'link' => route('games.math'),
                        'desc' => 'Solve fast arithmetic blocks to score rewards.',
                        'gradient' => 'from-cyan-400 via-sky-400 to-blue-500',
                        'shadow' => 'shadow-sky-500/10',
                        'badge' => 'SOLVE 🧮'
                    ],
                    [
                        'name' => 'Word Game',
                        'icon' => '📝',
                        'link' => route('games.word'),
                        'desc' => 'Arrange letters and build correct words.',
                        'gradient' => 'from-purple-400 via-fuchsia-400 to-pink-500',
                        'shadow' => 'shadow-fuchsia-500/10',
                        'badge' => 'WORDS 📝'
                    ],
                    [
                        'name' => 'Easy Quiz',
                        'icon' => '🧠',
                        'link' => route('games.quiz'),
                        'desc' => 'Answer fast trivia queries to test your brain.',
                        'gradient' => 'from-teal-400 via-emerald-400 to-green-500',
                        'shadow' => 'shadow-teal-500/10',
                        'badge' => 'QUIZ 🧠'
                    ],
                    [
                        'name' => 'Brain Game',
                        'icon' => '💡',
                        'link' => route('games.brain'),
                        'desc' => 'Test your mental memory, reaction and focus.',
                        'gradient' => 'from-yellow-400 via-amber-400 to-orange-500',
                        'shadow' => 'shadow-yellow-500/10',
                        'badge' => 'FOCUS 💡'
                    ],
                    [
                        'name' => 'Puzzle Block',
                        'icon' => '🧩',
                        'link' => route('games.puzzle'),
                        'desc' => 'Combine scattered blocks and form full pictures.',
                        'gradient' => 'from-indigo-400 via-violet-400 to-purple-600',
                        'shadow' => 'shadow-violet-500/10',
                        'badge' => 'PUZZLE 🧩'
                    ],
                    [
                        'name' => 'Emoji Match',
                        'icon' => '🎭',
                        'link' => route('games.emoji'),
                        'desc' => 'Find the matching pairs of expressions fast.',
                        'gradient' => 'from-rose-400 via-orange-400 to-red-500',
                        'shadow' => 'shadow-rose-500/10',
                        'badge' => 'EMOJIS 🎭'
                    ]
                ];
            @endphp
            @foreach ($gamesList as $game)
                <a href="{{ $game['link'] }}" class="bouncy-hover bg-gradient-to-tr {{ $game['gradient'] }} p-4 rounded-[2rem] text-white flex flex-col justify-between h-40 shadow-sm {{ $game['shadow'] }} relative overflow-hidden">
                    <div class="flex justify-between items-start">
                        <div class="w-10 h-10 bg-white/20 rounded-2xl flex items-center justify-center text-xl border border-white/10 shadow-inner">
                            {{ $game['icon'] }}
                        </div>
                        <span class="text-[7px] font-black text-white bg-black/15 px-2 py-0.5 rounded-full uppercase tracking-widest">
                            {{ $game['badge'] }}
                        </span>
                    </div>
                    <div class="space-y-0.5 text-left">
                        <h4 class="text-xs font-black uppercase tracking-wider block">{{ htmlspecialchars($game['name']) }}</h4>
                        <span class="text-[8px] text-white/90 font-bold block leading-tight">{{ htmlspecialchars($game['desc']) }}</span>
                    </div>
                    <div class="absolute -right-4 -bottom-4 w-12 h-12 bg-white/10 rounded-full"></div>
                </a>
            @endforeach
        </div>
    </div>
</div>
@endsection