@extends('layouts.app')

@section('title', 'Puzzle Block - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Puzzle Tile 🧩</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Puzzles Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Moves Count</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="moves-label">0</p>
        </div>
    </div>

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center space-y-6">
        <div class="bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center shadow-inner">
            <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block mb-4">Arrange Tiles in numerical sequence: 1-8</span>
            
            <div class="puzzle-grid" id="grid">
            </div>
        </div>

        <div id="game-controls-wrapper" class="w-full">
            @if ($isSessionLocked)
                <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                    Unlock 🔓 (Watch Ad)
                </button>
            @else
                <button id="shuffleBtn" onclick="shuffleTiles()" class="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest bouncy-hover btn-glow-blue">
                    Shuffle & Start 🧩
                </button>
            @endif
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Puzzle History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Puzzle Block</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No puzzle events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .puzzle-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; width: 240px; height: 240px; margin: 0 auto; }
    .puzzle-tile {
        background: #ffffff;
        border-radius: 1.25rem;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        font-weight: 900;
        color: #2563eb;
        cursor: pointer;
        box-shadow: 0 4px 10px rgba(0,0,0,0.03), inset 0 -4px 0 #f1f5f9;
        border: 2px solid rgba(226, 232, 240, 0.8);
        transition: transform 0.15s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        will-change: transform;
    }
    .puzzle-tile:active {
        transform: scale(0.93);
    }
    .puzzle-tile.empty { background: transparent; box-shadow: none; border: none; cursor: default; }
</style>
@endpush

@push('scripts')
<script>
    const gridEl = document.getElementById('grid');
    const movesLabel = document.getElementById('moves-label');
    const shuffleBtn = document.getElementById('shuffleBtn');
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    let tiles = [1, 2, 3, 4, 5, 6, 7, 8, ''];
    let isGameActive = false;
    let moveCount = 0;

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    function renderTiles() {
        gridEl.innerHTML = '';
        tiles.forEach((tile, index) => {
            const tileEl = document.createElement('div');
            tileEl.className = 'puzzle-tile' + (tile === '' ? ' empty' : '');
            tileEl.innerText = tile;
            tileEl.onclick = () => handleTileClick(index);
            gridEl.appendChild(tileEl);
        });
    }

    function shuffleTiles() {
        if (isGameActive) return;
        
        do {
            for (let i = tiles.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [tiles[i], tiles[j]] = [tiles[j], tiles[i]];
            }
        } while (!isSolvable() || isSolved());

        isGameActive = true;
        moveCount = 0;
        movesLabel.innerText = "0";
        if (shuffleBtn) {
            shuffleBtn.disabled = true;
            shuffleBtn.className = "w-full py-4 bg-slate-100 text-slate-400 border border-slate-200 rounded-2xl text-xs font-black uppercase tracking-widest cursor-not-allowed select-none";
            shuffleBtn.innerText = "Puzzle Solving in progress...";
        }
        renderTiles();
    }

    function isSolvable() {
        let inversions = 0;
        const cleanList = tiles.filter(t => t !== '');
        for (let i = 0; i < cleanList.length; i++) {
            for (let j = i + 1; j < cleanList.length; j++) {
                if (cleanList[i] > cleanList[j]) inversions++;
            }
        }
        return inversions % 2 === 0;
    }

    function handleTileClick(index) {
        if (!isGameActive) return;
        const emptyIndex = tiles.indexOf('');
        const validMoves = [
            emptyIndex - 1, emptyIndex + 1, 
            emptyIndex - 3, emptyIndex + 3
        ];

        if (validMoves.includes(index)) {
            if (emptyIndex % 3 === 0 && index === emptyIndex - 1) return;
            if (emptyIndex % 3 === 2 && index === emptyIndex + 1) return;

            [tiles[emptyIndex], tiles[index]] = [tiles[index], tiles[emptyIndex]];
            moveCount++;
            movesLabel.innerText = moveCount;
            renderTiles();

            triggerVibration('light');

            if (isSolved()) {
                isGameActive = false;
                claimVictory();
            }
        }
    }

    function isSolved() {
        const solvedState = [1, 2, 3, 4, 5, 6, 7, 8, ''];
        return tiles.every((val, idx) => val === solvedState[idx]);
    }

    function claimVictory() {
        const fd = new FormData();
        fd.append('action', 'claim_victory');
        fd.append('moves', moveCount);
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.puzzle') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                if (window.GlobalPopup) {
                    GlobalPopup.show('success', 'Sequence Complete!', `You solved the puzzle in ${moveCount} moves! claimed 🪙 {{ number_format(get_setting_val('puzzle_reward') ?: 25, 2) }}! 🎉`, true);
                } else {
                    alert(`You solved the puzzle in ${moveCount} moves! Claimed 🪙 {{ number_format(get_setting_val('puzzle_reward') ?: 25, 2) }}!`);
                }
                setTimeout(() => { window.location.reload(); }, 1800);
            } else {
                alert(data.message);
                window.location.reload();
            }
        });
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.puzzle') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.puzzle') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }

    renderTiles();
</script>
@endpush