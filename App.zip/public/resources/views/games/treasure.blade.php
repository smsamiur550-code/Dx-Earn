@extends('layouts.app')

@section('title', 'Treasure Chest - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-all p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Treasure Hunt 💎</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Attempts Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-455 uppercase tracking-wider">Next Refill</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="refill-timer">--:--:--</p>
        </div>
    </div>

    <div class="bg-gradient-to-tr from-teal-500 to-emerald-600 p-5 rounded-[2rem] text-white text-center shadow-md">
        <h3 class="text-xs font-black uppercase tracking-wider mb-1">Pick 3 Chests 🗝️</h3>
        <p class="text-[10px] text-teal-50 font-semibold leading-relaxed">Choose exactly 3 of the 9 legendary boxes below. First yields 💎, second 🪙, and third 💵. Combined values will be credited! 100% Free.</p>
    </div>

    <div id="game-controls-wrapper" class="w-full">
        @if ($isSessionLocked)
            <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                Unlock 🔓 (Watch Ad)
            </button>
        @endif
    </div>

    <div class="grid grid-cols-3 gap-3 {{ $isSessionLocked ? 'hidden' : '' }}" id="chestContainer">
        @for ($i = 0; $i < 9; $i++)
            <div onclick="openChest(this, {{ $i }})" class="chest-box bg-white border border-slate-200 rounded-[1.8rem] p-4 h-28 flex flex-col items-center justify-center cursor-pointer shadow-sm relative overflow-hidden bouncy-hover">
                <div class="text-amber-500 text-2xl transition-transform duration-300" id="icon-{{ $i }}">
                    <i class="fa-solid fa-box"></i>
                </div>
                <span class="text-[8px] font-black text-slate-400 block mt-2.5 uppercase tracking-wider">Box {{ $i + 1 }}</span>
            </div>
        @endfor
    </div>

    <div id="cooldown-wrapper" class="hidden bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm text-center">
        <span class="text-4xl mb-2 block animate-bounce">⏳</span>
        <h4 class="text-xs font-black text-slate-900 uppercase tracking-wider">Refilling Energy...</h4>
        <p class="text-[9px] text-slate-400 font-bold uppercase mt-1">Daily attempts limit reached. Check back at Midnight.</p>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Treasure History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Treasure Box</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No treasure events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('styles')
<style>
    .chest-box { transition: all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    .chest-box:active { transform: scale(0.95); }
    @keyframes popOpen {
        0% { transform: scale(1); }
        50% { transform: scale(1.15) rotate(6deg); }
        100% { transform: scale(1) rotate(0deg); }
    }
    .pop-open {
        animation: popOpen 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
    }
    .btn-glow-purple {
        box-shadow: 0 4px 14px rgba(167, 139, 250, 0.35);
    }
</style>
@endpush

@push('scripts')
<script>
    let playing = false;
    let limitReached = {{ $isLimitReached ? 'true' : 'false' }};
    let selectedBoxes = [];

    const balDisplay = document.getElementById('balance-display');
    const playsCount = document.getElementById('plays-count');
    const timerEl = document.getElementById('refill-timer');
    const chestContainer = document.getElementById('chestContainer');
    const cooldownWrapper = document.getElementById('cooldown-wrapper');

    let timeLeft = {{ $remainingTime }};
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    function updateTimer() {
        if (timeLeft <= 0) {
            if (timerEl) timerEl.innerText = "READY";
            return;
        }
        let h = Math.floor(timeLeft / 3600);
        let m = Math.floor((timeLeft % 3600) / 60);
        let s = timeLeft % 60;
        if (timerEl) timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
        timeLeft--;
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    if (limitReached) {
        if (chestContainer) chestContainer.classList.add('hidden');
        if (cooldownWrapper) cooldownWrapper.classList.remove('hidden');
    }

    function openChest(element, index) {
        if (playing || limitReached) return;
        if (selectedBoxes.includes(index)) return;

        playing = true;
        selectedBoxes.push(index);

        const iconDiv = element.querySelector('.text-amber-500') || element.querySelector('.text-emerald-500') || element.querySelector('.text-blue-500');
        iconDiv.innerHTML = `<i class="fa-solid fa-circle-notch fa-spin"></i>`;
        iconDiv.className = "text-blue-500 text-2xl";

        const formData = new FormData();
        formData.append('action', 'open_box');
        formData.append('box_index', index + 1);
        formData.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.treasure') }}", { 
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                element.classList.add('pop-open');
                triggerVibration('light');

                setTimeout(() => {
                    let openCount = data.consecutive_plays % 5;
                    let emoji = '💎';
                    if (openCount === 2) emoji = '🪙';
                    if (openCount === 3 || openCount === 0) emoji = '💵';

                    iconDiv.innerHTML = `<span class="text-3xl">${emoji}</span>`;
                    iconDiv.className = `text-emerald-500 text-2xl`;
                    
                    const valSpan = document.createElement('span');
                    valSpan.className = 'text-[9px] font-black text-emerald-500 mt-1 block';
                    valSpan.innerText = `🪙 +${data.box_value}`;
                    element.appendChild(valSpan);

                    playing = false;

                    if (data.limit_reached) {
                        limitReached = true;
                        if (chestContainer) chestContainer.classList.add('hidden');
                        if (cooldownWrapper) cooldownWrapper.classList.remove('hidden');
                        timeLeft = data.remaining_time;
                        updateTimer();
                    }

                    if (window.GlobalPopup) {
                        GlobalPopup.show('success', 'Treasure Box Opened!', `You unlocked box #${index + 1} and claimed 🪙 ${data.box_value.toFixed(2)}! 🎉`, true);
                    } else {
                        alert(`You unlocked box #${index + 1} and claimed 🪙 ${data.box_value.toFixed(2)}!`);
                    }

                    setTimeout(() => { window.location.reload(); }, 2000);
                }, 800);
            } else {
                playing = false;
                selectedBoxes.pop();
                iconDiv.innerHTML = `<i class="fa-solid fa-box"></i>`;
                iconDiv.className = "text-amber-500 text-2xl";
                alert(data.message || 'System Error!');
            }
        })
        .catch(err => {
            playing = false;
            selectedBoxes.pop();
            iconDiv.innerHTML = `<i class="fa-solid fa-box"></i>`;
            console.error("Networking error: ", err);
        });
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.treasure') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.treasure') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush