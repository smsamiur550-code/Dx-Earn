@extends('layouts.app')

@section('title', 'Lucky Spin - DX EARN')

@section('content')
@if ($isHardLocked)
    <div class="absolute inset-0 bg-white/95 backdrop-blur-md z-50 flex flex-col items-center justify-center p-8 text-center animate-fadeIn">
        <div class="w-16 h-16 bg-rose-50 border border-rose-100 rounded-full flex items-center justify-center text-rose-500 text-3xl shadow-inner mb-4">🔒</div>
        <h3 class="text-xl font-black text-rose-600 uppercase">Spoofing Penalty Lock</h3>
        <p class="text-xs font-semibold text-slate-400 mt-2 max-w-[80%] leading-relaxed">System detected a forceful unlock attempt without completing the required 5-second advertisement timer. You are penalized for 2 minutes.</p>
        <div class="mt-6 bg-rose-50 border border-rose-100 px-4 py-2.5 rounded-full text-rose-600 text-sm font-black font-mono" id="hard-lock-timer">02:00</div>
    </div>
@endif

<div class="px-6 py-4 flex items-center justify-between sticky top-0 bg-white/95 backdrop-blur-md z-45 border-b border-slate-100 shadow-sm shrink-0">
    <a href="{{ route('games') }}" class="text-slate-400 active:scale-95 transition-transform p-1 bouncy-hover">
        <i class="fa-solid fa-chevron-left text-lg"></i>
    </a>
    <h1 class="text-xs font-black text-slate-900 uppercase tracking-widest">Lucky Spin 🎡</h1>
    <div class="px-3.5 py-1.5 bg-blue-50 border border-blue-100 text-blue-600 rounded-full font-black text-[10px]" id="balance-display">
        🪙 {{ number_format($user->balance_coin, 2) }}
    </div>
</div>

<main class="p-4 space-y-4 flex-1">
    <div class="grid grid-cols-2 gap-3">
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Spins Today</p>
            <p class="text-sm font-black text-slate-700 mt-1" id="plays-count">{{ $playsToday }} / {{ $finalLimit }}</p>
        </div>
        <div class="bg-white p-4 rounded-3xl border border-slate-100 text-center shadow-sm">
            <p class="text-[9px] font-black text-slate-400 uppercase tracking-wider">Next Refill</p>
            <p class="text-sm font-black text-blue-600 mt-1" id="refill-timer">--:--:--</p>
        </div>
    </div>

    <div class="bg-white p-6 rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.01)] text-center space-y-6">
        <div class="flex flex-col items-center relative py-4">
            <div class="arrow-indicator absolute -top-1 z-20"></div>
            <div class="relative w-64 h-64 rounded-full border-[10px] border-slate-800 bg-white shadow-lg overflow-hidden flex items-center justify-center">
                <canvas id="wheel-canvas" width="240" height="240"></canvas>
                <div class="absolute w-12 h-12 bg-slate-800 border-4 border-white rounded-full flex items-center justify-center text-white font-black text-xs shadow-md z-15">
                    🎡
                </div>
            </div>
        </div>

        <div id="game-controls-wrapper" class="w-full">
            @if ($isSessionLocked)
                <button id="unlock-btn" onclick="startUnlockFlow()" class="w-full py-4 color-shifting-btn bg-gradient-to-tr from-violet-500 via-fuchsia-500 to-pink-500 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-purple">
                    Unlock 🔓 (Watch Ad)
                </button>
            @else
                <button id="spinBtn" onclick="spinWheel()" {{ ($isLimitReached && $remainingTime > 0) ? 'disabled' : '' }} class="w-full py-4 color-shifting-btn bg-gradient-to-r from-blue-600 to-indigo-650 disabled:from-slate-100 disabled:to-slate-100 disabled:text-slate-400 text-white rounded-2xl font-black text-xs shadow-md uppercase tracking-widest bouncy-hover btn-glow-blue">
                    {{ ($isLimitReached && $remainingTime > 0) ? 'REFILLING AT MIDNIGHT' : 'Spin Now ⚡' }}
                </button>
            @endif
        </div>
    </div>

    <div class="space-y-3">
        <h3 class="text-xs font-black text-slate-900 uppercase tracking-widest ml-1 text-left">Last 24 Hours Spin History</h3>
        <div class="space-y-2">
            @foreach ($history as $log)
                <div class="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex justify-between items-center text-xs animate-fadeIn">
                    <div class="space-y-0.5 text-left">
                        <span class="text-[8px] font-black text-slate-400 uppercase tracking-widest block">Lucky Spin</span>
                        <span class="font-extrabold text-slate-700">{{ htmlspecialchars($log->label) }}</span>
                        <span class="text-[8px] font-bold text-slate-400 block">{{ $log->created_at->format('h:i A') }}</span>
                    </div>
                    <div class="text-right">
                        <span class="font-black text-emerald-600 block">🪙 +{{ number_format($log->val, 2) }}</span>
                    </div>
                </div>
            @endforeach

            @if ($history->isEmpty())
                <p class="text-center text-slate-400 text-[10px] font-bold uppercase tracking-wider py-6 bg-white rounded-2xl border border-slate-100">No spin events logged today.</p>
            @endif
        </div>
    </div>
</main>
@endsection

@push('scripts')
<script>
    const timerEl = document.getElementById('refill-timer');
    let timeLeft = {{ $remainingTime }};
    let hardLockRemaining = {{ $hardLockRemaining }};
    const monetagDirectLink = "{{ $monetagLink }}";
    const isAdRestricted = {{ $adRestricted ? 'true' : 'false' }};

    function updateTimer() {
        if (timeLeft <= 0) {
            if (timerEl) timerEl.innerText = "READY";
            return;
        }
        let h = Math.floor(timeLeft / 3600);
        let m = Math.floor((timeLeft % 3600) / 60);
        let s = timeLeft % 60;
        if (timerEl) timerEl.innerText = `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')}`;
        timeLeft--;
    }
    setInterval(updateTimer, 1000);
    updateTimer();

    if (hardLockRemaining > 0) {
        const lockTimerEl = document.getElementById('hard-lock-timer');
        const lockInterval = setInterval(() => {
            hardLockRemaining--;
            let m = Math.floor(hardLockRemaining / 60);
            let s = hardLockRemaining % 60;
            if (lockTimerEl) lockTimerEl.innerText = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
            if (hardLockRemaining <= 0) {
                clearInterval(lockInterval);
                window.location.reload();
            }
        }, 1000);
    }

    const canvas = document.getElementById('wheel-canvas');
    const ctx = canvas.getContext('2d');
    
    // Explicit slice configs
    const prizes = [
        {{ floatval(get_setting_val('spin_prize_0_val') ?: 5) }},
        {{ floatval(get_setting_val('spin_prize_1_val') ?: 10) }},
        {{ floatval(get_setting_val('spin_prize_2_val') ?: 15) }},
        {{ floatval(get_setting_val('spin_prize_3_val') ?: 50) }},
        {{ floatval(get_setting_val('spin_prize_4_val') ?: 20) }},
        {{ floatval(get_setting_val('spin_prize_5_val') ?: 25) }},
        {{ floatval(get_setting_val('spin_prize_6_val') ?: 100) }},
        {{ floatval(get_setting_val('spin_prize_7_val') ?: 30) }}
    ];
    const colors = ['#f8fafc', '#eff6ff', '#f8fafc', '#eff6ff', '#f8fafc', '#eff6ff', '#f8fafc', '#eff6ff'];
    const textColors = ['#1e293b', '#2563eb', '#1e293b', '#2563eb', '#1e293b', '#2563eb', '#1e293b', '#2563eb'];

    function drawWheel() {
        const numSlices = prizes.length;
        const sliceAngle = (2 * Math.PI) / numSlices;
        const radius = canvas.width / 2;

        ctx.clearRect(0, 0, canvas.width, canvas.height);

        for (let i = 0; i < numSlices; i++) {
            const angle = i * sliceAngle;
            
            ctx.beginPath();
            ctx.moveTo(radius, radius);
            ctx.arc(radius, radius, radius, angle, angle + sliceAngle);
            ctx.fillStyle = colors[i];
            ctx.fill();
            ctx.strokeStyle = '#cbd5e1';
            ctx.lineWidth = 1.5;
            ctx.stroke();

            ctx.save();
            ctx.translate(radius, radius);
            ctx.rotate(angle + sliceAngle / 2);
            ctx.textAlign = 'right';
            ctx.fillStyle = textColors[i];
            ctx.font = 'bold 10px sans-serif';
            ctx.fillText("🪙 " + prizes[i], radius - 15, 4);
            ctx.restore();
        }
    }
    drawWheel();

    let isSpinning = false;

    function spinWheel() {
        if (isSpinning) return;
        isSpinning = true;

        const spinBtn = document.getElementById('spinBtn');
        if (spinBtn) spinBtn.disabled = true;

        const winningIndex = Math.floor(Math.random() * prizes.length);
        const sliceAngle = 360 / prizes.length;

        const targetDeg = (360 - (winningIndex * sliceAngle)) - (sliceAngle / 2) + 270;
        const totalDeg = targetDeg + (360 * 5); 

        const wheel = document.getElementById('wheel-canvas');
        wheel.style.transform = `rotate(${totalDeg}deg)`;

        setTimeout(() => {
            const fd = new FormData();
            fd.append('action', 'claim_spin');
            fd.append('slice_index', winningIndex);
            fd.append('_token', '{{ csrf_token() }}');

            fetch("{{ route('games.spin') }}", { method: 'POST', body: fd })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    if (window.GlobalPopup) {
                        GlobalPopup.show('success', 'Winner!', `The Wheel landed on slice #${winningIndex}! You claimed 🪙 ${data.slice_value.toFixed(2)}! 🎉`, true);
                    } else {
                        alert(`The Wheel landed on slice #${winningIndex}! Claimed 🪙 ${data.slice_value.toFixed(2)}!`);
                    }
                    setTimeout(() => { window.location.reload(); }, 2200);
                } else {
                    alert(data.message);
                    window.location.reload();
                }
            })
            .catch(() => {
                alert('Connection lost.');
                window.location.reload();
            });
        }, 4200);
    }

    function startUnlockFlow() {
        if (isAdRestricted) {
            if (window.GlobalPopup) {
                GlobalPopup.show('failed', 'Access Restricted', 'Multi-account ad viewing detected on this device. Ad privileges are restricted.');
            } else {
                alert('🚨 Access Restricted: Multi-account ad viewing detected on this device.');
            }
            return;
        }
        const btn = document.getElementById('unlock-btn');
        btn.disabled = true;
        btn.innerText = "Initializing Ad...";

        const fd = new FormData();
        fd.append('action', 'start_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.spin') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.open(monetagDirectLink, '_blank');
                let waitSeconds = 5;
                const interval = setInterval(() => {
                    if (waitSeconds > 0) {
                        btn.innerText = `Unlock in: ${waitSeconds}s ⏱️`;
                        waitSeconds--;
                    } else {
                        clearInterval(interval);
                        btn.innerText = "Verifying Unlock...";
                        verifyUnlock();
                    }
                }, 1000);
            } else {
                btn.disabled = false;
                btn.innerText = "Unlock 🔓 (Watch Ad)";
            }
        })
        .catch(() => {
            btn.disabled = false;
            btn.innerText = "Unlock 🔓 (Watch Ad)";
        });
    }

    function verifyUnlock() {
        const fd = new FormData();
        fd.append('action', 'verify_unlock');
        fd.append('_token', '{{ csrf_token() }}');

        fetch("{{ route('games.spin') }}", { method: 'POST', body: fd })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'success') {
                window.location.reload();
            } else {
                alert(data.message || 'Verification failed.');
                window.location.reload();
            }
        })
        .catch(() => {
            alert('System connection lost.');
            window.location.reload();
        });
    }
</script>
@endpush