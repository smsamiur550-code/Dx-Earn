<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

return new class extends Migration
{
    public function up(): void
    {
        // 1. users table
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username', 255)->unique();
            $table->string('password', 255);
            $table->string('full_name', 255);
            $table->string('email', 255)->unique();
            $table->string('profile_pic', 255)->default('default_avatar.png');
            $table->string('referral_code', 50)->nullable()->unique();
            $table->string('referred_by', 50)->nullable();
            $table->string('telegram_id', 100)->nullable();
            $table->decimal('balance_coin', 20, 6)->default(0.000000);
            $table->decimal('balance_token', 20, 6)->default(0.000000);
            $table->decimal('balance_dollar', 20, 2)->default(0.00);
            $table->decimal('balance_referral_dollar', 20, 2)->default(0.00);
            $table->tinyInteger('is_banned')->default(0);
            $table->string('kyc_status', 50)->default('unverified');
            $table->dateTime('kyc_submitted_at')->nullable();
            $table->string('device_uid', 255)->nullable();
            $table->tinyInteger('coin_convert_unlocked')->default(0);
            $table->decimal('coin_convert_used', 20, 2)->default(0.00);
            $table->tinyInteger('profile_edited')->default(0);
            $table->string('shop_country', 100)->nullable();
            $table->dateTime('hard_lock_expires_at')->nullable();
            $table->dateTime('created_at');
        });

        // 2. admins table
        Schema::create('admins', function (Blueprint $table) {
            $table->id();
            $table->string('username', 255)->unique();
            $table->string('password', 255);
            $table->text('permissions')->nullable();
            $table->tinyInteger('is_active')->default(1);
            $table->dateTime('created_at');
        });

        // 3. settings table
        Schema::create('settings', function (Blueprint $table) {
            $table->string('name', 255)->primary();
            $table->text('val')->nullable();
        });

        // 4. payment_requests table
        Schema::create('payment_requests', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('payment_type', 100);
            $table->decimal('amount', 20, 2);
            $table->string('screenshot_pic', 255);
            $table->text('meta_data')->nullable();
            $table->string('status', 50)->default('pending');
            $table->dateTime('created_at');
        });

        // 5. withdrawals table
        Schema::create('withdrawals', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->decimal('amount', 20, 2);
            $table->string('payment_method', 255);
            $table->string('account_number', 255);
            $table->string('status', 50)->default('pending');
            $table->string('withdrawal_type', 50)->default('main_usd');
            $table->string('ticket_number', 100);
            $table->dateTime('requested_at');
        });

        // 6. categories table
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
        });

        // 7. products table
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
            $table->string('image', 255);
            $table->decimal('price', 20, 2);
            $table->integer('stock');
            $table->text('description')->nullable();
            $table->unsignedBigInteger('category_id')->nullable();
            $table->string('country', 100)->default('Bangladesh');
            $table->string('company_name', 255)->nullable();
            $table->string('company_logo', 255)->nullable();
        });

        // 8. orders table
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('product_id');
            $table->string('name', 255);
            $table->string('phone', 255);
            $table->text('address');
            $table->decimal('total_price', 20, 2);
            $table->decimal('coin_deducted', 20, 2);
            $table->integer('coin_percentage');
            $table->decimal('discount_cash', 20, 2);
            $table->decimal('delivery_charge', 20, 2);
            $table->string('delivery_location', 100);
            $table->decimal('cod_amount', 20, 2);
            $table->string('status', 50)->default('pending');
            $table->dateTime('created_at');
        });

        // 9. lottery_tickets table
        Schema::create('lottery_tickets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('order_id')->nullable();
            $table->string('ticket_number', 100);
            $table->string('status', 50)->default('pending');
            $table->decimal('prize_amount', 20, 2)->default(0.00);
            $table->dateTime('created_at');
        });

        // 10. transactions table
        DB::statement("CREATE TABLE IF NOT EXISTS transactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            category VARCHAR(100) NOT NULL,
            type VARCHAR(100) NOT NULL,
            currency VARCHAR(100) NOT NULL,
            amount DECIMAL(20,4) NOT NULL,
            description TEXT NULL,
            status VARCHAR(50) DEFAULT 'completed',
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 11. notifications table
        DB::statement("CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type VARCHAR(100) NOT NULL,
            message TEXT NOT NULL,
            status VARCHAR(50) DEFAULT 'unread',
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 12. user_vip table (Exemption check line removed here)
        DB::statement("CREATE TABLE IF NOT EXISTS user_vip (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL UNIQUE,
            vip_id INT NOT NULL,
            expires_at DATETIME NOT NULL,
            last_bonus_claim DATETIME NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 13. vip_plans table
        DB::statement("CREATE TABLE IF NOT EXISTS vip_plans (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            price DECIMAL(20,2) NOT NULL,
            duration_days INT NOT NULL,
            benefits TEXT NULL,
            extra_mining_income DECIMAL(5,2) DEFAULT 2.00,
            faster_mining_speed DECIMAL(5,2) DEFAULT 2.00,
            daily_bonus DECIMAL(5,2) DEFAULT 2.00
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 14. chat table
        DB::statement("CREATE TABLE IF NOT EXISTS chat (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            message TEXT NOT NULL,
            is_admin TINYINT DEFAULT 0,
            is_seen TINYINT DEFAULT 0,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 15. tasks table
        DB::statement("CREATE TABLE IF NOT EXISTS tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            link VARCHAR(255) NOT NULL,
            reward_amount DECIMAL(20,4) NOT NULL,
            task_type VARCHAR(100) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 16. user_tasks table
        DB::statement("CREATE TABLE IF NOT EXISTS user_tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            task_id INT NOT NULL,
            completed_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 17. user_game_plays table
        DB::statement("CREATE TABLE IF NOT EXISTS user_game_plays (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            game_id INT NOT NULL,
            plays_today INT DEFAULT 0,
            last_played DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 18. game_history table
        DB::statement("CREATE TABLE IF NOT EXISTS game_history (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            game_id INT NOT NULL,
            val DECIMAL(20,4) NOT NULL,
            label VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 19. gift_codes table
        DB::statement("CREATE TABLE IF NOT EXISTS gift_codes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            code VARCHAR(100) NOT NULL UNIQUE,
            coin_amount DECIMAL(20,2) NOT NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 20. user_gift_claims table
        DB::statement("CREATE TABLE IF NOT EXISTS user_gift_claims (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            code_id INT NOT NULL,
            claimed_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 21. mining table
        DB::statement("CREATE TABLE IF NOT EXISTS mining (
            user_id INT PRIMARY KEY,
            time_level INT DEFAULT 1,
            income_level INT DEFAULT 1,
            speed_level INT DEFAULT 1,
            mining_start_time DATETIME NULL,
            last_claim_time DATETIME NULL,
            boost_expires_at DATETIME NULL,
            last_boost_time DATETIME NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 22. ad_views table
        DB::statement("CREATE TABLE IF NOT EXISTS ad_views (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            device_uid VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 23. referrals table
        DB::statement("CREATE TABLE IF NOT EXISTS referrals (
            id INT AUTO_INCREMENT PRIMARY KEY,
            referrer_id INT NOT NULL,
            referee_id INT NOT NULL,
            bonus_amount DECIMAL(20,2) NOT NULL,
            referee_bonus DECIMAL(20,2) NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 24. kyc table
        DB::statement("CREATE TABLE IF NOT EXISTS kyc (
            user_id INT PRIMARY KEY,
            nid_number VARCHAR(100) NOT NULL,
            full_name VARCHAR(255) NOT NULL,
            dob DATE NOT NULL,
            front_img VARCHAR(255) NOT NULL,
            back_img VARCHAR(255) NOT NULL,
            selfie_img VARCHAR(255) NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            submitted_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 25. daily_rewards table
        DB::statement("CREATE TABLE IF NOT EXISTS daily_rewards (
            user_id INT PRIMARY KEY,
            streak INT DEFAULT 0,
            last_claim_date DATE NULL,
            total_claimed INT DEFAULT 0,
            cycle_start DATE NULL,
            streak_mask VARCHAR(10) DEFAULT '0000000'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 26. conversions table
        DB::statement("CREATE TABLE IF NOT EXISTS conversions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            amount_from DECIMAL(20,4) NOT NULL,
            amount_to DECIMAL(20,4) NOT NULL,
            type VARCHAR(100) NOT NULL,
            status VARCHAR(50) DEFAULT 'completed',
            rate DECIMAL(20,6) NOT NULL,
            created_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

        // 27. homepage_sliders table
        Schema::create('homepage_sliders', function (Blueprint $table) {
            $table->id();
            $table->string('grad', 255)->nullable();
            $table->string('title', 255);
            $table->text('desc_text');
            $table->string('image_path', 255)->nullable();
            $table->string('redirect_url', 255)->nullable();
        });

        // Seed initial system configurations
        $this->seedDefaultSettings();
    }

    public function down(): void
    {
        Schema::dropIfExists('homepage_sliders');
        Schema::dropIfExists('conversions');
        Schema::dropIfExists('daily_rewards');
        Schema::dropIfExists('kyc');
        Schema::dropIfExists('referrals');
        Schema::dropIfExists('ad_views');
        Schema::dropIfExists('mining');
        Schema::dropIfExists('user_gift_claims');
        Schema::dropIfExists('gift_codes');
        Schema::dropIfExists('game_history');
        Schema::dropIfExists('user_game_plays');
        Schema::dropIfExists('user_tasks');
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('chat');
        Schema::dropIfExists('vip_plans');
        Schema::dropIfExists('user_vip');
        Schema::dropIfExists('notifications');
        Schema::dropIfExists('transactions');
        Schema::dropIfExists('lottery_tickets');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('products');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('withdrawals');
        Schema::dropIfExists('payment_requests');
        Schema::dropIfExists('settings');
        Schema::dropIfExists('admins');
        Schema::dropIfExists('users');
    }

    private function seedDefaultSettings(): void
    {
        $defaultSettings = [
            'min_withdraw' => '5.00',
            'coin_to_token_rate' => '0.1000',
            'min_convert' => '100.00',
            'max_convert' => '10000.00',
            'convert_fee' => '1.50',
            'token_to_dollar_rate' => '0.25',
            'token_to_dollar_enabled' => '1',
            'admin_username' => 'admin',
            'admin_password_hash' => Hash::make('admin123'), // hash_hash typo fixed
            'bot_token' => '',
            'cron_key' => 'SECURE_CRON_KEY_123',
            'live_feed_status' => '1',
            'withdraw_ticket_start' => '1000',
            'google_client_id' => '',
            'google_client_secret' => '',
            'google_redirect_url' => '',
            'monetag_direct_link' => 'https://www.google.com',
            'live_market_link' => '',
            'usd_to_bdt_rate' => '120.00',
            'ref_bonus_referrer' => '0.50',
            'ref_bonus_referee' => '0.20',
            'coin_symbol' => '🪙',
            'token_symbol' => '🟡',
            'btn_name_games' => 'Games',
            'btn_name_mining' => 'Mining',
            'token_per_currency_bangladesh' => '4.0',
            'delivery_inside_dhaka' => '60.00',
            'delivery_outside_dhaka' => '120.00',
            'shop_allow_discount_20' => '1',
            'shop_allow_discount_30' => '1',
            'shop_allow_discount_40' => '1',
            'next_lottery_draw_time' => 'next Sunday 20:00:00',
            'lottery_ticket_price' => '50.00',
            'lottery_prize_1_amount' => '100000.00',
            'daily_task_limit' => '10',
            'task_wait_seconds' => '5',
            'mining_base_duration_hours' => '4.0',
            'mining_base_yield_hourly' => '200.00',
            'mining_boost_ad_wait_seconds' => '5',
            'mining_boost_multiplier' => '2.0',
            'mining_boost_duration_hours' => '2.0',
            'mining_boost_cooldown_hours' => '4.0',
            'dice_limit' => '10',
            'dice_point_value' => '10.00',
            'scratch_limit' => '5',
            'scratch_min_prize' => '5.00',
            'scratch_max_prize' => '50.00',
            'spin_limit' => '5',
            'spin_reward' => '10.00',
            'spin_prize_0_val' => '5.00',
            'spin_prize_1_val' => '10.00',
            'spin_prize_2_val' => '15.00',
            'spin_prize_3_val' => '50.00',
            'spin_prize_4_val' => '20.00',
            'spin_prize_5_val' => '25.00',
            'spin_prize_6_val' => '100.00',
            'spin_prize_7_val' => '30.00',
            'treasure_limit' => '5',
            'treasure_val_1' => '10.00',
            'treasure_val_2' => '20.00',
            'treasure_val_3' => '30.00',
            'treasure_val_4' => '50.00',
            'treasure_val_5' => '80.00',
            'treasure_val_6' => '100.00',
            'treasure_val_7' => '150.00',
            'treasure_val_8' => '200.00',
            'treasure_val_9' => '500.00',
            'math_limit' => '10',
            'math_reward' => '10.00',
            'word_limit' => '10',
            'word_reward' => '15.00',
            'quiz_limit' => '10',
            'quiz_reward' => '20.00',
            'brain_limit' => '10',
            'brain_reward' => '20.00',
            'puzzle_limit' => '10',
            'puzzle_reward' => '25.00',
            'emoji_limit' => '10',
            'emoji_reward' => '20.00',
            'daily_reward_day_1' => '150.00',
            'daily_reward_day_2' => '250.00',
            'daily_reward_day_3' => '400.00',
            'daily_reward_day_4' => '600.00',
            'daily_reward_day_5' => '850.00',
            'daily_reward_day_6' => '1200.00',
            'daily_reward_day_7' => '2000.00',
            'daily_reward_7day_extra' => '5000.00'
        ];

        foreach ($defaultSettings as $key => $val) {
            DB::table('settings')->updateOrInsert(['name' => $key], ['val' => $val]);
        }

        // Seeding default VIP plans if empty
        if (DB::table('vip_plans')->count() == 0) {
            DB::table('vip_plans')->insert([
                [
                    'name' => 'Silver Booster 🌟',
                    'price' => 150.00,
                    'duration_days' => 15,
                    'benefits' => 'Gain instant double multipliers on games limit, cloud node hashing capacity speed, and daily rewards!',
                    'extra_mining_income' => 2.00,
                    'faster_mining_speed' => 2.00,
                    'daily_bonus' => 2.00
                ],
                [
                    'name' => 'Gold Booster 👑',
                    'price' => 280.00,
                    'duration_days' => 30,
                    'benefits' => 'Supercharge your mining node! Stack daily income, claim automatic VIP claims and double payout limits!',
                    'extra_mining_income' => 2.00,
                    'faster_mining_speed' => 2.00,
                    'daily_bonus' => 2.00
                ]
            ]);
        }

        // Seed default owner admin credentials
        DB::table('settings')->updateOrInsert(
            ['name' => 'admin_username'],
            ['val' => 'admin']
        );
        DB::table('settings')->updateOrInsert(
            ['name' => 'admin_password_hash'],
            ['val' => Hash::make('admin123')]
        );
    }
};