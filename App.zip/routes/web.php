<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\User\ProfileController;
use App\Http\Controllers\User\WalletController;
use App\Http\Controllers\User\WithdrawController;
use App\Http\Controllers\User\NotificationController;
use App\Http\Controllers\User\TeamController;
use App\Http\Controllers\User\LotteryController;
use App\Http\Controllers\User\ShopController;
use App\Http\Controllers\User\SupportController;
use App\Http\Controllers\User\RewardController;
use App\Http\Controllers\Game\GameEngineController;

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ChatController;
use App\Http\Controllers\Admin\TaskController;
use App\Http\Controllers\Admin\GiftController;
use App\Http\Controllers\Admin\PaymentController;
use App\Http\Controllers\Admin\WithdrawController as AdminWithdrawController;
use App\Http\Controllers\Admin\ShopController as AdminShopController;
use App\Http\Controllers\Admin\LotteryController as AdminLotteryController;
use App\Http\Controllers\Admin\GameController as AdminGameController;
use App\Http\Controllers\Admin\MiningController as AdminMiningController;
use App\Http\Controllers\Admin\VipController as AdminVipController;
use App\Http\Controllers\Admin\AdminController as AdminListController;
use App\Http\Controllers\Admin\MaintenanceController;

// Public Guest Routes
Route::middleware(['rate_limit'])->group(function () {
    Route::get('/login', [LoginController::class, 'showLogin'])->name('login');
    Route::post('/login/google', [LoginController::class, 'googleLogin'])->name('login.google');
    Route::post('/login/telegram', [LoginController::class, 'telegramLogin'])->name('login.telegram');
    Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

    // Admin Auth Gateway
    Route::get('/admin/login', [DashboardController::class, 'showLogin'])->name('admin.login');
    Route::post('/admin/login', [DashboardController::class, 'login'])->name('admin.login.submit');
    Route::get('/admin/logout', [DashboardController::class, 'logout'])->name('admin.logout');
});

// Protected User Routes (user_auth middleware added here)
Route::middleware(['rate_limit', 'user_auth', 'user_banned'])->group(function () {
    Route::get('/', [ProfileController::class, 'index'])->name('home');
    
    // Wallet & Balance Conversions
    Route::get('/wallet', [WalletController::class, 'index'])->name('wallet');
    Route::get('/convert', [WalletController::class, 'showConvert'])->name('convert');
    Route::post('/convert/coin-to-token', [WalletController::class, 'coinToToken'])->name('convert.coin_to_token');
    Route::post('/convert/token-to-dollar', [WalletController::class, 'tokenToDollar'])->name('convert.token_to_dollar');
    Route::get('/payment', [WalletController::class, 'showPayment'])->name('payment');
    Route::post('/payment/proof', [WalletController::class, 'submitProof'])->name('payment.proof');
    Route::get('/history', [WalletController::class, 'history'])->name('history'); // Connected ledger history

    // Withdrawals
    Route::get('/withdraw', [WithdrawController::class, 'index'])->name('withdraw');
    Route::post('/withdraw', [WithdrawController::class, 'requestWithdraw'])->name('withdraw.submit');
    Route::get('/withdraw/live-feed', [WithdrawController::class, 'liveFeed'])->name('withdraw.feed');

    // Team (Referrals)
    Route::get('/reffer', [TeamController::class, 'index'])->name('reffer');

    // Support Chat & Help Center
    Route::get('/support', [SupportController::class, 'index'])->name('support');
    Route::get('/chat', [SupportController::class, 'showChat'])->name('chat');
    Route::get('/chat/fetch', [SupportController::class, 'fetchMessages'])->name('chat.fetch');
    Route::post('/chat/send', [SupportController::class, 'sendMessage'])->name('chat.send');

    // Notifications
    Route::get('/notifications', [NotificationController::class, 'index'])->name('notifications');

    // Profile Settings, KYC & Leaderboard
    Route::get('/profile', [ProfileController::class, 'showProfile'])->name('profile');
    Route::get('/settings', [ProfileController::class, 'showSettings'])->name('settings');
    Route::post('/settings/profile', [ProfileController::class, 'updateProfile'])->name('settings.profile');
    Route::post('/settings/kyc', [ProfileController::class, 'submitKyc'])->name('settings.kyc');
    Route::get('/privacy', [ProfileController::class, 'showPrivacy'])->name('privacy');
    Route::get('/leaderboard', [ProfileController::class, 'leaderboard'])->name('leaderboard'); // Connected leaderboard page

    // Interactive Mining Node
    Route::get('/mining', [RewardController::class, 'showMining'])->name('mining');
    Route::post('/mining/start', [RewardController::class, 'startMining'])->name('mining.start');
    Route::post('/mining/claim', [RewardController::class, 'claimMining'])->name('mining.claim');
    Route::post('/mining/boost/start', [RewardController::class, 'startBoost'])->name('mining.boost.start');
    Route::post('/mining/boost/claim', [RewardController::class, 'claimBoost'])->name('mining.boost.claim');

    // Reward Streak, VIP & Promo Cards
    Route::get('/reward', [RewardController::class, 'showReward'])->name('reward');
    Route::post('/reward/claim', [RewardController::class, 'claimDailyReward'])->name('reward.claim');
    Route::get('/vip', [RewardController::class, 'showVip'])->name('vip');
    Route::post('/vip/buy', [RewardController::class, 'buyVipPlan'])->name('vip.buy');
    Route::get('/gift', [RewardController::class, 'showGift'])->name('gift');
    Route::post('/gift/redeem', [RewardController::class, 'redeemGiftCode'])->name('gift.redeem');
    Route::get('/task', [RewardController::class, 'showTasks'])->name('task');
    Route::get('/task/start', [RewardController::class, 'startTask'])->name('task.start');
    Route::post('/task/claim', [RewardController::class, 'claimTask'])->name('task.claim');

    // E-Store Frontend
    Route::get('/shop', [ShopController::class, 'index'])->name('shop');
    Route::post('/shop/country', [ShopController::class, 'saveCountry'])->name('shop.country');
    Route::get('/shop/product/{id}', [ShopController::class, 'viewProduct'])->name('shop.product');
    Route::post('/shop/checkout', [ShopController::class, 'checkout'])->name('shop.checkout');
    Route::get('/shop/orders', [ShopController::class, 'showOrders'])->name('shop.orders');
    Route::get('/lottery', [LotteryController::class, 'index'])->name('lottery');

    // Game Engine Routes
    Route::get('/games', [GameEngineController::class, 'index'])->name('games');
    Route::prefix('games')->name('games.')->group(function () {
        Route::match(['get', 'post'], '/spin', [GameEngineController::class, 'spin'])->name('spin');
        Route::match(['get', 'post'], '/dice', [GameEngineController::class, 'dice'])->name('dice');
        Route::match(['get', 'post'], '/scratch', [GameEngineController::class, 'scratch'])->name('scratch');
        Route::match(['get', 'post'], '/treasure', [GameEngineController::class, 'treasure'])->name('treasure');
        Route::match(['get', 'post'], '/math', [GameEngineController::class, 'math'])->name('math');
        Route::match(['get', 'post'], '/word', [GameEngineController::class, 'word'])->name('word');
        Route::match(['get', 'post'], '/quiz', [GameEngineController::class, 'quiz'])->name('quiz');
        Route::match(['get', 'post'], '/brain', [GameEngineController::class, 'brain'])->name('brain');
        Route::match(['get', 'post'], '/puzzle', [GameEngineController::class, 'puzzle'])->name('puzzle');
        Route::match(['get', 'post'], '/emoji', [GameEngineController::class, 'emoji'])->name('emoji');
    });
});

// Protected Admin Core Panel
Route::middleware(['rate_limit', 'admin_auth'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // User Directory
    Route::get('/users', [UserController::class, 'index'])->name('users');
    Route::post('/users/update', [UserController::class, 'update'])->name('users.update');

    // Live Support Chat
    Route::get('/chat', [ChatController::class, 'index'])->name('chat');
    Route::get('/chat/list', [ChatController::class, 'listChats'])->name('chat.list');
    Route::get('/chat/messages', [ChatController::class, 'fetchMessages'])->name('chat.messages');
    Route::post('/chat/send', [ChatController::class, 'sendMessage'])->name('chat.send');

    // Missions Configurator
    Route::get('/tasks', [TaskController::class, 'index'])->name('tasks');
    Route::post('/tasks/save', [TaskController::class, 'saveTask'])->name('tasks.save');
    Route::post('/tasks/settings', [TaskController::class, 'saveSettings'])->name('tasks.settings');
    Route::post('/tasks/delete', [TaskController::class, 'deleteTask'])->name('tasks.delete');

    // Promo Gift Code Generator
    Route::get('/gift', [GiftController::class, 'index'])->name('gift');
    Route::post('/gift/create', [GiftController::class, 'create'])->name('gift.create');
    Route::post('/gift/delete', [GiftController::class, 'delete'])->name('gift.delete');

    // Deposits Auditor
    Route::get('/payment', [PaymentController::class, 'index'])->name('payment');
    Route::post('/payment/audit', [PaymentController::class, 'audit'])->name('payment.audit');

    // Vouchers & Withdrawal Auditing
    Route::get('/withdraw', [AdminWithdrawController::class, 'index'])->name('withdraw');
    Route::post('/withdraw/audit', [AdminWithdrawController::class, 'audit'])->name('withdraw.audit');
    Route::get('/withdraw-feed', [AdminWithdrawController::class, 'feedIndex'])->name('withdraw_feed');
    Route::post('/withdraw-feed/generate-fake', [AdminWithdrawController::class, 'generateFake'])->name('withdraw_feed.generate_fake');
    Route::post('/withdraw-feed/settings', [AdminWithdrawController::class, 'saveFeedSettings'])->name('withdraw_feed.settings');

    // Shop Logistics
    Route::get('/shop', [AdminShopController::class, 'shopIndex'])->name('shop');
    Route::get('/products', [AdminShopController::class, 'productIndex'])->name('products');
    Route::post('/products/category/add', [AdminShopController::class, 'addCategory'])->name('products.category.add');
    Route::post('/products/category/delete', [AdminShopController::class, 'deleteCategory'])->name('products.category.delete');
    Route::post('/products/save', [AdminShopController::class, 'saveProduct'])->name('products.save');
    Route::post('/products/delete', [AdminShopController::class, 'deleteProduct'])->name('products.delete');
    Route::get('/orders', [AdminShopController::class, 'ordersIndex'])->name('orders');
    Route::post('/orders/audit', [AdminShopController::class, 'auditOrder'])->name('orders.audit');
    Route::post('/orders/delete', [AdminShopController::class, 'deleteOrder'])->name('orders.delete');

    // Sweepstakes Lottery Core
    Route::get('/lottery', [AdminLotteryController::class, 'index'])->name('lottery');
    Route::post('/lottery/schedule', [AdminLotteryController::class, 'saveSchedule'])->name('lottery.schedule');
    Route::post('/lottery/prizes', [AdminLotteryController::class, 'savePrizes'])->name('lottery.prizes');
    Route::post('/lottery/draw', [AdminLotteryController::class, 'drawLottery'])->name('lottery.draw');

    // Interactive Parameters Config
    Route::get('/game', [AdminGameController::class, 'index'])->name('game');
    Route::post('/game/save', [AdminGameController::class, 'saveGameConfig'])->name('game.save');
    Route::get('/mining', [AdminMiningController::class, 'index'])->name('mining');
    Route::post('/mining/save', [AdminMiningController::class, 'saveMiningConfig'])->name('mining.save');
    Route::get('/vip', [AdminVipController::class, 'index'])->name('vip');
    Route::post('/vip/save', [AdminVipController::class, 'saveVipPlan'])->name('vip.save');
    Route::post('/vip/delete', [AdminVipController::class, 'deletePlan'])->name('vip.delete');

    // Administrative Gatekeepers & Settings
    Route::get('/admin-list', [AdminListController::class, 'index'])->name('admin_list');
    Route::post('/admin-list/action', [AdminListController::class, 'handleAction'])->name('admin_list.action');
    Route::get('/settings', [DashboardController::class, 'showSettings'])->name('settings');
    Route::post('/settings/global', [DashboardController::class, 'saveGlobalSettings'])->name('settings.global');
    Route::post('/settings/slider/add', [DashboardController::class, 'addSlider'])->name('settings.slider.add');
    Route::post('/settings/slider/delete', [DashboardController::class, 'deleteSlider'])->name('settings.slider.delete');
    
    // Maintenance Logs & Storage cleaner
    Route::get('/maintenance', [MaintenanceController::class, 'index'])->name('maintenance');
    Route::post('/maintenance/cleanup', [MaintenanceController::class, 'saveCleanupSettings'])->name('maintenance.cleanup');
    Route::post('/maintenance/clean-orphans', [MaintenanceController::class, 'cleanOrphans'])->name('maintenance.clean_orphans');
});